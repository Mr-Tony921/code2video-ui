# 0.9.3

- Specify jump as a reason string in the compact contract; report all invalid compact shot IDs before expanded-schema errors.
- Normalize explicit jump/cut_reason aliases without inventing a reason, and remove false no-jump flags.
- Permit ID patches to repair fields that previously failed normalization; the compiler remains the validation gate.
- Clarify explicit brief cardinalities and same-job structural draft replacement.
- 0.9.2 remained a mechanically validated candidate; final model comparison uses this frozen release.

# 0.9.2

- Fix false enclosure alarms for open/compound assets whose aggregate center is empty.
- Sample actual component interiors for compound visibility, preserving proportional framing/visibility thresholds; simple primitives retain their seven samples.
- Report blocking object IDs from actual ray hits so repairs can distinguish actor overlap from scenery.
- Full frozen comparison is rerun; earlier failures remain archived rather than rescored.

# 0.9.1

- Pilot-driven DeepSeek patch clarifies bottom-center anchors and support-top arithmetic.
- Object-form events without at use the same explicit end-of-shot default as string-form events, with normalization recorded.
- Removes remaining obsolete140-second reserve prose; the tool reports a duration-aware reserve.
- Resolve uniquely named evidence-page basenames without fabricating review evidence.
- Avoid a redundant critic call when automatic preview checks already fail; repairs still inspect evidence and final review remains mandatory.
- No test-story coordinates, names or layouts added to the skill.

# 0.9.0

- Variable 10–300-second story scope; no compulsory 20 shots or three framing scales.
- Original instruction and renderability define acceptance; aesthetic suggestions cannot create blockers.
- Explicit camera/static-cast constraints and duration-aware export reserve.
- DeepSeek-only high-thinking, output-budget and schema/action/review compensations are a separate model patch.
- Version remains experimental0.x; fresh independent pass@1/pass@3 trials are reported separately from internal repair counts.

# Changelog

## 0.8.3

- Complete context-only camera support: do not duplicate a contextual subject in the primary ray audit or camera scoring. Synthetic partial-view regression confirms one contextual audit per sample.
- Clarify that close shots may omit full bodies and environment when their story role and identity remain clear; downstream acting can motivate a static proxy close-up.

## 0.8.2

- Gather independent scenery and numeric-story diagnostics when compilation fails, without rendering or accepting the diagnostic scene. Unknown environment keys include explicit null-deletion guidance.
- Support establishing/insert shots aimed solely at large context objects while preserving partial-visibility checks and the ban on people/small props as context.
- Reduce directional-shadow acne on flat proxy surfaces.

## 0.8.1

- Separate rotation-angle validation from coordinate limits; valid180°/270° set modules no longer fail. Errors identify module index, field and value.
- Add generic cylindrical column component and clarify total canopy/seat-back dimensions.
- Put executable motion/carry/release and event-time examples before shot prose; story predicates remain unchanged.
- Provider-only fast-mode experiments remain outside this portable skill.

# Release history

## 0.8.0 — 2026-11-16

- Made compact custom-parts semantics explicit: additive by default; parts_mode=replace deliberately supplies a complete custom body. Built-in asset components remain preferred. Older compact plans relying on implicit replacement must opt into replace; explicit scene parts are unchanged.
- Camera assistance can also move closer (0.65–1.6× horizontal distance) to find an open interior view while retaining authored height and movement.
- Separated reviewer inputs: original requirements and actual audited states, instead of treating creative downstream prose as a new contract. Numerical meters are never inferred from thumbnail scale.
- Experiment-only Opus adapter corrected to adaptive/low after the fallback channel rejected old flags; provider routing remains outside the skill.
- 0.7 trials and deliberate batch interruption remain recorded separately, with no success backfill.


## 0.7.0 — 2026-11-16

- Integrated applicable lessons from the supplied legacy-agent handoff: fixed requirements versus creative choices, separate camera/occlusion/crop checks, actual-state determinism samples, strict media verification and immutable presentation copies.
- Added standalone ID-based compact draft patching; same shared deadline and two compile/repair cap.
- Added camera/near-plane primitive collision probes and A–B–A state/pixel reports; no claim of full collision physics or exhaustive determinism.
- Added explicit normalizations for unambiguous nested action fields and optional custom-part defaults; contradictory intent remains an error.
- Rig, IK, wheel physics, repeated full-film preview loops and production platform deployment remain outside this simplified director-stage scope.
- Earlier 0.6 prototype failures are retained as independent trials; measured 0.7 validation lives in experiment reports.


## 0.6.0 — 2026-11-16

- Added general scene modules, finite floors, environment instancing, shadows and reusable actor components. No benchmark story templates are included.
- Replaced elevated distant default views with eye-height, subject-derived camera scales and bounded horizontal assistance preserving height/targets/movement.
- Added large-context visibility, scenic requirements, environment occlusion, and precise absent-subject diagnostics; compatible nested camera input accepted when unambiguous.
- Added full-set Blender adapter parity for component geometry; optional export remains slower and independently measured.
- Expanded scene/depth/photography review and Chinese experiment organization. Keep 0.x until explicit user release approval.
- Previous experiment snapshots remain historical; current validation results are recorded outside the portable package.


## 0.5.1 — 2026-11-16

- Fixed overlapping two-line montage labels and enlarged contextual crops with nearest-neighbor scaling; original projected pixel sizes remain labeled. Enlarging does not add detail.
- Scene planner, review gates, timing and repair limits unchanged from 0.5.0. The independent model test remains recorded as 0.5.0; 0.5.1 uses mechanical regression and fresh-package verification.


## 0.5.0 — 2026-11-16

- Added technical-profile and layered-review contracts: output, coordinates, camera, staging, time/repair budgets, evidence and acceptance scope.
- Added real event-before/exact/after samples, projected prop-size flags and contextual crops; bounded overview, continuity, event, detail and cut pages.
- Snapshots pre-repair preview evidence. Builds shot-ID-aligned before/after comparisons and numerical scene differences.
- Added `review` and `record-review` CLI commands. Export/package require a current review receipt with no declared blockers. Complete receipts cover every event and required evidence page; incomplete visual review stays explicit.
- Locked preview/export profile and job skill source/version; shot manifest carries provenance. Existing jobs use their original release; do not upgrade them in place.
- Renderer/camera planner, numeric event thresholds, 600-second budget and two-repair cap otherwise unchanged.
- Validation: mechanical/regression and independent DeepSeek tests are recorded in the experiment deliverables, not inferred from older model runs. The 30-run model comparison remains frozen at 0.4.0.

## 0.4.1 — 2026-11-16

- Expanded error diagnostics with actual distances, event time, positions and travel. Acceptance thresholds unchanged.
- Two final independent DeepSeek low-reasoning tool-use runs completed 300-second videos in 298.97 s and 239.53 s on software WebGL; earlier failed attempts remain recorded.

## 0.4.0 — 2026-11-16

- Preserved camera and look-target displacement under automatic framing; validated actual endpoints, portrait framing, camera types and pan/orbit directions.
- Derived travel yaw only for people; added stricter event/scene/enclosure checks.
- Frozen 10 cases × 3 models comparison; source snapshot and per-run records retained outside the portable package.

## 0.3.x — development snapshots

- Compact plans, position inheritance, prop carry/release and exact event screenshots; intermediate diagnostics superseded by 0.4.0 camera fixes.

## 0.2.0 — historical baseline

- Explicit scene-coordinate baseline; old auto-framing could erase intended follow/pan. Statistics retained for diagnostics, old movies excluded from final accepted examples.
