#!/usr/bin/env python3
"""Optional Blender Workbench adapter for the same explicit scene JSON."""
import argparse,json,math,time,sys,os,subprocess,hashlib
from pathlib import Path
import bpy
from mathutils import Vector

def run():
 p=argparse.ArgumentParser();p.add_argument('--scene',required=True);p.add_argument('--out',required=True);p.add_argument('--frames',type=int,default=0);p.add_argument('--fps',type=int,default=24);p.add_argument('--width',type=int,default=640);p.add_argument('--height',type=int,default=360);p.add_argument('--timeout',type=float,default=480);p.add_argument('--samples',type=int,default=8);p.add_argument('--video',action='store_true');a=p.parse_args()
 begin=time.monotonic();plan=json.loads(Path(a.scene).read_text());out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 if any(s['camera'].get('auto_frame') for s in plan['shots']):raise ValueError('Use effective-scene.json from the shared preview; Blender does not compile camera assistance')
 bpy.ops.wm.read_factory_settings(use_empty=True);scene=bpy.context.scene;scene.render.engine='BLENDER_WORKBENCH';scene.render.resolution_x=a.width;scene.render.resolution_y=a.height;scene.render.resolution_percentage=100;scene.render.fps=a.fps
 scene.display.render_aa=str(a.samples);sh=scene.display.shading;sh.light='STUDIO';sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='BOTH';sh.background_type='WORLD';scene.world=bpy.data.worlds.new('World');scene.world.color=(.65,.69,.73)
 scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast';scene.view_settings.exposure=0;scene.view_settings.gamma=1
 def coord(p):return (p[0],-p[2],p[1])
 def mat(c):
  m=bpy.data.materials.new(c);rgb=tuple(int(c.lstrip('#')[i:i+2],16)/255 for i in (0,2,4));m.diffuse_color=(*rgb,1);return m
 materials={};geometries={}
 def material(color):
  if color not in materials:materials[color]=mat(color)
  return materials[color]
 def primitive(root,kind,size,at,color,yaw=0):
  key=(kind,color)
  if key not in geometries:
   if kind=='box':bpy.ops.mesh.primitive_cube_add(size=1)
   elif kind=='sphere':bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.5)
   elif kind=='cone':bpy.ops.mesh.primitive_cone_add(vertices=10,radius1=.5,radius2=0,depth=1)
   else:bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=.5,depth=1)
   template=bpy.context.object;template.data.materials.append(material(color));geometries[key]=template.data;bpy.data.objects.remove(template,do_unlink=True)
  obj=bpy.data.objects.new(kind,geometries[key]);scene.collection.objects.link(obj);obj.parent=root;obj.scale=(size[0],size[2],size[1]);obj.location=coord([at[0],at[1]+size[1]/2,at[2]]);obj.rotation_euler.z=math.radians(yaw);return obj
 def group(name):
  root=bpy.data.objects.new(name,None);scene.collection.objects.link(root);return root
 objects={};environments={}
 for e in plan['entities']:
  root=group(e['id']);objects[e['id']]=root;w,h,d=e['size'];color=e.get('color','#dde2e7')
  if e.get('parts'):
   for part in e['parts']:primitive(root,part['kind'],part['size'],part['at'],part['color'],part.get('yaw',0))
  elif e['kind']=='person':
   primitive(root,'cylinder',[w*.92,h*.72,d*.92],[0,0,0],color);primitive(root,'sphere',[w*.78,w*.78,w*.78],[0,h*.85-w*.39,0],color);primitive(root,'box',[w*.32,h*.2,.025],[0,h*.45,w*.43],'#98a1ac')
  else:primitive(root,e['kind'],e['size'],[0,0,0],color)
 for st in plan['sets']:
  root=group('environment_'+st['id']);environments[st['id']]=root;env=st.get('environment',{})
  for part in env.get('parts',[]):primitive(root,part['kind'],part['size'],part['at'],part['color'],part.get('yaw',0))
  floor=env.get('ground',{});size=floor.get('size',[55,55]);primitive(root,'box',[size[0],.01,size[1]],floor.get('at',[0,-.025,0]),floor.get('color','#b8bab6'))
 camera_data=bpy.data.cameras.new('Camera');camera=bpy.data.objects.new('Camera',camera_data);scene.collection.objects.link(camera);scene.camera=camera;camera_data.sensor_fit='VERTICAL';camera_data.sensor_height=32;camera_data.clip_end=250
 def interp(x,y,u):return [v+(w-v)*u for v,w in zip(x,y)]
 def place(id,pos,yaw):
  obj=objects[id];obj.location=coord(pos);obj.rotation_euler.z=math.radians(yaw)
  for c in obj.children:c.hide_render=False
 def frame(s,u):
  for id,root in environments.items():
   for child in root.children:child.hide_render=id!=s['set']
  for obj in objects.values():
   for c in obj.children:c.hide_render=True
  for st in plan['sets']:
   if st['id']==s['set']:
    for o in st['objects']:place(o['id'],o['position'],o.get('yaw',0))
  for v in s['actors']:place(v['id'],interp(v['from'],v['to'],u),v.get('yaw',0)+(v.get('end_yaw',v.get('yaw',0))-v.get('yaw',0))*u)
  c=s['camera'];pos=interp(c['from'],c['to'],u);look=interp(c['look'],c.get('look_to',c['look']),u)
  if c['type']=='orbit':
   aa=Vector(c['from'])-Vector(c['look']);bb=Vector(c['to'])-Vector(c.get('look_to',c['look']));theta=math.atan2(aa.x,aa.z);delta=(math.atan2(bb.x,bb.z)-theta+math.pi)%(2*math.pi)-math.pi;r=math.hypot(aa.x,aa.z)*(1-u)+math.hypot(bb.x,bb.z)*u;pos=[look[0]+r*math.sin(theta+u*delta),pos[1],look[2]+r*math.cos(theta+u*delta)]
  camera.location=coord(pos);camera.rotation_euler=(Vector(coord(look))-camera.location).to_track_quat('-Z','Y').to_euler();camera_data.lens=32/(2*math.tan(math.radians(c['fov'])/2));bpy.context.view_layer.update()
 scene.render.image_settings.file_format='PNG';total=0;timings=[]
 # Sampled benchmark or full sequence. Keep files only until FFmpeg packaging.
 for si,s in enumerate(plan['shots']):
  n=round(s['duration']*a.fps)
  for k in range(n):
   if a.frames and total>=a.frames:break
   if time.monotonic()-begin>a.timeout:raise TimeoutError('Blender rendering budget exhausted')
   t=time.monotonic();frame(s,k/max(1,n-1));scene.render.filepath=str(out/f'{total:06d}.png');bpy.ops.render.render(write_still=True);timings.append(time.monotonic()-t);total+=1
  if a.frames and total>=a.frames:break
 try:
  import gpu
  hardware={name:getattr(gpu.platform,name)() for name in ['renderer_get','vendor_get','version_get','backend_type_get','device_type_get'] if hasattr(gpu.platform,name)}
 except Exception as e:hardware={'query_error':str(e)}
 info={'engine':'Blender Workbench','version':bpy.app.version_string,'hardware':hardware,'frames':total,'seconds':time.monotonic()-begin,'frame_seconds':timings,'fps':a.fps,'resolution':[a.width,a.height],'aa_samples':a.samples,'scene_sha256':hashlib.sha256(Path(a.scene).read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'estimated_7200_frame_seconds':sum(timings[1:])/max(1,len(timings)-1)*7200}
 if a.video:
  t=time.monotonic();proc=subprocess.run(['ffmpeg','-v','error','-y','-framerate',str(a.fps),'-i',str(out/'%06d.png'),'-c:v','libx264','-preset','ultrafast','-crf','22','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'preview.mp4')],capture_output=True,text=True,timeout=max(1,a.timeout-(time.monotonic()-begin)))
  if proc.returncode:raise RuntimeError(proc.stderr[-1000:])
  info['encode_seconds']=time.monotonic()-t;info['seconds']=time.monotonic()-begin
  # Preserve representative final-engine frames; remove successful export's temporary PNG sequence.
  keep=set();cursor=0
  for shot in plan['shots']:keep.add(cursor);cursor+=round(shot['duration']*a.fps)
  for png in out.glob('[0-9][0-9][0-9][0-9][0-9][0-9].png'):
   if int(png.stem) not in keep:png.unlink()
 (out/'render.json').write_text(json.dumps(info,indent=2));print('RESULT '+json.dumps({k:v for k,v in info.items() if k!='frame_seconds'}),flush=True)
if __name__=='__main__':run()
