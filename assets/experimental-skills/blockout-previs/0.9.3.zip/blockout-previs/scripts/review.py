#!/usr/bin/env python3
"""Bounded, indexed visual evidence and revision comparisons; no model dependency."""
import argparse,hashlib,json,math,shutil,textwrap
from pathlib import Path
from PIL import Image,ImageDraw

CATEGORIES=['story','staging','camera','continuity','props','orientation']
def read(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def provenance(skill):
 files={str(p.relative_to(skill)):digest(p) for p in sorted(skill.rglob('*')) if p.is_file() and not {'node_modules','__pycache__'}.intersection(p.parts)}
 return {'version':read(skill/'package.json')['version'],'source_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
def snapshot(job,revision):
 out=job/'output'
 if not (out/'source-scene.json').exists():return
 # Keep only review evidence, never duplicate a five-minute video.
 dest=job/'revisions'/f'r{revision:02d}'
 if dest.exists():return
 dest.mkdir(parents=True)
 for p in out.rglob('*'):
  if p.is_file() and p.suffix in {'.jpg','.json'}:
   target=dest/p.relative_to(out);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)

def sheet(items,dest,cols=3,tile=(320,180)):
 tw,th=tile;cellh=th+42;canvas=Image.new('RGB',(cols*tw,max(1,math.ceil(len(items)/cols))*cellh),'#101828');d=ImageDraw.Draw(canvas)
 for i,(file,label,crop) in enumerate(items):
  x=i%cols*tw;y=i//cols*cellh
  with Image.open(file) as src:
   im=src.convert('RGB')
   if crop:
    im=im.crop(crop);scale=min(tw/im.width,th/im.height)
    im=im.resize((max(1,round(im.width*scale)),max(1,round(im.height*scale))),Image.Resampling.NEAREST if scale>1 else Image.Resampling.LANCZOS)
   else:im.thumbnail((tw,th))
   canvas.paste(im,(x+(tw-im.width)//2,y+(th-im.height)//2))
  # IDs and numeric labels only; full multilingual narrative lives in index.json.
  label=label.encode('ascii','replace').decode()
  lines=label.splitlines() if '\n' in label else textwrap.wrap(label,width=52)
  for row,line in enumerate(lines[:2]):d.text((x+5,y+th+3+row*16),line[:52],fill='white' if row==0 else '#a9bfd8')
 canvas.save(dest,quality=90)

def build(job):
 out=job/'output';scene=job/'scene.json'
 if digest(scene)!=digest(out/'source-scene.json'):raise ValueError('Preview is stale; preview the current scene first')
 plan=read(out/'effective-scene.json');brief=read(job/'brief.json');review=out/'review';review.mkdir(exist_ok=True)
 # Remove obsolete review pages, never other output artifacts.
 for p in review.glob('*'):
  if p.is_file():p.unlink()
 records=[];timing=[];elapsed=0
 def page(name,kind,items,cols=3,tile=(320,180),**meta):
  sheet(items,review/name,cols,tile);records.append({'file':'review/'+name,'kind':kind,**meta})
 for i,s in enumerate(plan['shots']):timing.append({'id':s['id'],'start':elapsed,'end':elapsed+s['duration'],'beat':s.get('beat'),'camera':s['camera']['type']});elapsed+=s['duration']
 mids=[(out/'frames'/f'{i+1:03d}_b.jpg',f"{s['id']} | {timing[i]['start']:g}-{timing[i]['end']:g}s | {s['camera']['type']}",None) for i,s in enumerate(plan['shots'])]
 # Max 20 shots per overview; no unbounded giant canvas.
 for k in range(0,len(mids),20):page(f'overview-{k//20+1:02d}.jpg','overview',mids[k:k+20],4,shots=[s['id'] for s in plan['shots'][k:k+20]])
 for k in range(0,len(plan['shots']),5):
  items=[]
  for i in range(k,min(k+5,len(plan['shots']))):
   s=plan['shots'][i]
   for suffix,u in [('a',0),('b',.5),('c',1)]:items.append((out/'frames'/f'{i+1:03d}_{suffix}.jpg',f"{s['id']} | u={u:g} | T={timing[i]['start']+u*s['duration']:g}s",None))
  page(f'continuity-{k//5+1:02d}.jpg','continuity',items,shots=[s['id'] for s in plan['shots'][k:k+5]])
 cuts=[]
 for i in range(len(plan['shots'])-1):
  for j,suffix in [(i,'c'),(i+1,'a')]:cuts.append((out/'frames'/f'{j+1:03d}_{suffix}.jpg',f"cut {i+1:02d} | {plan['shots'][j]['id']} | {'OUT' if suffix=='c' else 'IN'}",None))
 for k in range(0,len(cuts),10):page(f'cuts-{k//10+1:02d}.jpg','cuts',cuts[k:k+10],2)
 samples=read(out/'review-samples.json');event_ids=[x['event'] for x in samples if x['label']=='exact'];eventitems=[];details=[];flags=[]
 for r in samples:
  s=plan['shots'][r['shot_index']];t=timing[r['shot_index']]['start']+r['u']*s['duration']
  eventitems.append((out/r['file'],f"{r['event']} | {r['shot']} | {r['label']}\nT={t:.2f}s u={r['u']:.3f}",None))
  if r['label']!='exact':continue
  w,h=Image.open(out/r['file']).size
  for subject in r['subjects']:
   box=subject.get('bbox');id=subject['id']
   if not box or not all(math.isfinite(x) for x in box):continue
   bw,bh=box[2]-box[0],box[3]-box[1]
   small=min(bw,bh)<12;occluded=subject.get('visible_fraction',0)<.9
   if small or occluded:flags.append({'event':r['event'],'shot':r['shot'],'subject':id,'bbox_pixels':[round(bw,2),round(bh,2)],'small_projected_extent':small,'sampled_visible_fraction':subject.get('visible_fraction'),'review_required':True})
   # Every event's non-person props, plus any small/occluded person, receive a contextual crop.
   if subject.get('kind')=='person' and not (small or occluded):continue
   pad=max(20,.35*max(bw,bh));crop=(max(0,int(box[0]-pad)),max(0,int(box[1]-pad)),min(w,int(box[2]+pad+1)),min(h,int(box[3]+pad+1)))
   if crop[2]<=crop[0] or crop[3]<=crop[1]:continue
   details.append((out/r['file'],f"{r['event']} | {id} | bbox={bw:.0f}x{bh:.0f}px\nCROP ONLY; no extra image detail",crop))
 for k in range(0,len(eventitems),9):page(f'events-{k//9+1:02d}.jpg','events',eventitems[k:k+9],events=event_ids[k//3:k//3+3])
 for k in range(0,len(details),6):page(f'details-{k//6+1:02d}.jpg','details',details[k:k+6],3,tile=(320,240))
 comparisons=[];revisions=sorted((job/'revisions').glob('r*')) if (job/'revisions').exists() else []
 if revisions:
  before=revisions[-1];old=read(before/'effective-scene.json');byid={s['id']:(i,s) for i,s in enumerate(old['shots'])};changed=[]
  for i,s in enumerate(plan['shots']):
   prior=byid.get(s['id'])
   if not prior:changed.append({'shot':s['id'],'added':True});continue
   oi,ps=prior
   diff={k:{'before':ps.get(k),'after':s.get(k)} for k in set(ps)|set(s) if ps.get(k)!=s.get(k)}
   # Entity/set changes can affect all shots even when shot coordinates are unchanged.
   if not diff and old.get('entities')==plan.get('entities') and old.get('sets')==plan.get('sets'):continue
   changed.append({'shot':s['id'],'fields':diff})
   for suffix,u in [('a',0),('b',.5),('c',1)]:
    comparisons.extend([(before/'frames'/f'{oi+1:03d}_{suffix}.jpg',f"{s['id']} u={u:g} BEFORE",None),(out/'frames'/f'{i+1:03d}_{suffix}.jpg',f"{s['id']} u={u:g} AFTER",None)])
  write(review/'comparison.json',{'before_revision':before.name,'before_scene_sha256':digest(before/'source-scene.json'),'after_scene_sha256':digest(scene),'changed_shots':changed,'entities_changed':old.get('entities')!=plan.get('entities'),'sets_changed':old.get('sets')!=plan.get('sets'),'note':'Aligned by shot ID and normalized time. Read numerical fields; different duration is NOT equal absolute time. Compare affected event times separately.'})
  for k in range(0,len(comparisons),12):page(f'compare-{k//12+1:02d}.jpg','compare',comparisons[k:k+12],2)
 state=read(job/'job.json');index={'skill':state.get('skill'),'scene_sha256':digest(scene),'effective_scene_sha256':digest(out/'effective-scene.json'),'revision':state.get('repairs',0),'pages':records,'shots':timing,'events':brief.get('events',[]),'event_samples':samples,'detail_flags':flags,'comparisons':bool(comparisons),'notes':['Event before/after samples stay inside their shot; at endpoints one sample duplicates exact. Use cuts pages for adjacent shots.','Projected bounding boxes are not silhouettes, occlusion proof, or measured visible pixel area.','Three stills do not certify continuous motion; camera audit and final video remain required.']}
 write(review/'index.json',index)
 return {'index':'review/index.json','scene_sha256':index['scene_sha256'],'pages':records,'detail_flags':flags,'comparison': 'review/comparison.json' if revisions else None}

def normalize_evidence(record,pages):
 """Resolve a bare filename only when it uniquely identifies an actual evidence page."""
 allowed=set(pages);by_name={};notes=[]
 for page in allowed:by_name.setdefault(Path(page).name,[]).append(page)
 def resolve(value):
  if value in allowed:return value
  matches=by_name.get(value,[]) if isinstance(value,str) and '/' not in value and '\\' not in value else []
  if len(matches)==1:notes.append({'from':value,'to':matches[0]});return matches[0]
  return value
 if isinstance(record.get('seen'),list):record['seen']=[resolve(v) for v in record['seen']]
 for collection in ['events','findings','critical_issues','warnings']:
  for item in record.get(collection,[]):
   if isinstance(item.get('evidence'),list):item['evidence']=[resolve(v) for v in item['evidence']]
 if notes:record['evidence_path_normalizations']=notes
 return record

def record(job,path):
 out=job/'output';idx=read(out/'review/index.json');r=read(path)
 r=normalize_evidence(r,[p['file'] for p in idx['pages']])
 if idx['scene_sha256']!=digest(job/'scene.json'):raise ValueError('Stale review pack')
 if r.get('scene_sha256')!=idx['scene_sha256']:raise ValueError('Review must cite the current index scene_sha256')
 if r.get('status') not in ['complete','incomplete']:raise ValueError('status must be complete or incomplete')
 seen=r.get('seen',[]);allowed={p['file'] for p in idx['pages']}
 if not isinstance(seen,list) or any(p not in allowed or not (out/p).exists() for p in seen):raise ValueError('Unknown/missing evidence image')
 if r['status']=='incomplete':
  if not r.get('reason'):raise ValueError('Incomplete review needs a reason')
 else:
  required={p['file'] for p in idx['pages'] if p['kind'] in ['overview','continuity','events','details']}
  if not required.issubset(seen):raise ValueError('Complete review must inspect overview, all continuity/events/details pages')
  if idx['comparisons'] and not any(p.startswith('review/compare-') for p in seen):raise ValueError('A repair needs before/after comparison evidence')
  criteria=r.get('criteria',{})
  if set(criteria)!=set(CATEGORIES) or any(v not in ['pass','warning','blocker'] for v in criteria.values()):raise ValueError('All six review criteria need pass/warning/blocker')
  events=r.get('events',[])
  if len(events)!=len(idx['events']) or {e.get('id') for e in events}!={e['id'] for e in idx['events']}:raise ValueError('Review every required event exactly once')
  for e in events:
   if e.get('verdict') not in ['pass','warning','blocker'] or not e.get('evidence') or any(p not in seen for p in e['evidence']):raise ValueError('Each event requires a verdict and seen image evidence')
  if not isinstance(r.get('findings'),list):raise ValueError('findings must be a list')
 for finding in r.get('findings',[]):
  if finding.get('severity') not in ['warning','blocker'] or not finding.get('description') or not finding.get('evidence') or any(p not in seen for p in finding['evidence']):raise ValueError('Findings require severity, description and seen evidence')
 r['skill']=idx['skill'];r['effective_scene_sha256']=idx['effective_scene_sha256'];r['record_type']='model_or_human_declared_visual_review';r['machine_verified_viewing']=False
 write(out/'visual-review.json',r)
 return gate(job)

def gate(job):
 out=job/'output';r=read(out/'visual-review.json');idx=read(out/'review/index.json')
 if r['scene_sha256']!=digest(job/'scene.json') or r['effective_scene_sha256']!=digest(out/'effective-scene.json'):raise ValueError('Visual review is stale for this scene/camera')
 blocked=any(v=='blocker' for v in r.get('criteria',{}).values()) or any(e.get('verdict')=='blocker' for e in r.get('events',[])) or any(f.get('severity')=='blocker' for f in r.get('findings',[]))
 if blocked:raise ValueError('Unresolved visual blocker; repair within budget or fail')
 return {'visual_review_complete':r['status']=='complete','declared_review_only':True,'warnings':r.get('findings',[]),'reason':r.get('reason')}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('job');a=p.parse_args();print(json.dumps(build(Path(a.job).resolve()),ensure_ascii=False))
