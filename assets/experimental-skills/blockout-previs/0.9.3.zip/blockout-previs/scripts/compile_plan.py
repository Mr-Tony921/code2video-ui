#!/usr/bin/env python3
"""Compile compact director decisions into explicit deterministic renderer data."""
import argparse,copy,json,math
from pathlib import Path
from scenography import component,build_environment

def normalize_draft(draft):
 draft=copy.deepcopy(draft);notes=[]
 for i,s in enumerate(draft.get('shots',[])):
  # Accept only unambiguous declared reason aliases; never invent a jump rationale.
  reason=s.get('cut_reason');jump=s.get('jump')
  if 'jump' in s and (jump is False or jump is None) and not s.get('start'):
   s.pop('jump');notes.append(f"{s.get('id',i)}: jump=false/null normalized to continuous inheritance")
  elif isinstance(reason,str) and reason.strip() and (jump is True or (jump is None and s.get('start'))):
   s['jump']=reason;s.pop('cut_reason');notes.append(f"{s.get('id',i)}: explicit cut_reason normalized to compact jump reason")
  kept=[]
  actions={'move','carry','release','hide','show','start','jump','yaw'}
  for item in s.get('events',[]):
   if isinstance(item,dict) and 'id' not in item:
    if not item or not set(item)<=actions:raise ValueError(f"{s.get('id',i)}: events only accepts IDs or {{id,at}}; move/carry belong at shot root. Invalid item: {item}")
    for key,value in item.items():
     if key in s and isinstance(s[key],dict) and isinstance(value,dict):
      if any(k in s[key] and s[key][k]!=v for k,v in value.items()):raise ValueError('Conflicting nested action '+key)
      s[key].update(value)
     elif key in s and s[key]!=value:raise ValueError('Conflicting nested action '+key)
     else:s[key]=value
    notes.append(f"{s.get('id',i)}: lifted unambiguous shot action fields {list(item)} from events; no event-time or action-order inference")
   else:kept.append(item)
  s['events']=kept
  # Accept the common unambiguous camera object form without asking a model to rewrite the story.
  if isinstance(s.get('camera'),dict):
   notes.append(f"{s.get('id',i)}: flattened unambiguous nested camera")
   spec=s['camera'];s['camera']=spec.get('type','static')
   allowed={'framing','angle','height','distance','lens','fov','focus','context','travel','arc','auto_frame','look_offset'}
   for key,value in spec.items():
    if key=='type':continue
    if key not in allowed:raise ValueError('Unknown nested camera parameter '+key)
    if key in s and s[key]!=value:raise ValueError('Conflicting flat/nested camera parameter '+key)
    s[key]=value
 return draft,notes

def _compile_plan(draft,brief):
 draft,notes=normalize_draft(draft)
 invalid_jumps=[str(s.get('id',i)) for i,s in enumerate(draft.get('shots',[])) if 'jump' in s and (not isinstance(s['jump'],str) or not s['jump'].strip())]
 if invalid_jumps:raise ValueError('Compact draft jump must be a nonempty reason STRING, not a boolean. Fix jump in ALL these shot IDs: '+', '.join(invalid_jumps)+'. Use jump:"explicit time/location ellipsis reason"; keep start when required. Do not patch the expanded cut_reason field.')
 for stage_spec in draft['stages']:
  extra=set(stage_spec.get('environment',{}))-{'description','ground','modules'}
  if extra:raise ValueError(f"Stage {stage_spec['id']} environment has unsupported fields {sorted(extra)}. Remove these keys; in a targeted patch set each unwanted key to null. Supported: description, ground, modules.")
 for e in draft['entities']:
  custom=e.get('parts',[]);mode=e.pop('parts_mode','add')
  if mode not in ['add','replace']:raise ValueError('parts_mode must be add or replace')
  if e.get('asset') and not (custom and mode=='replace'):e['parts']=component(e['asset'],e['size'],{'color':e['color']})+custom
  elif custom and mode=='add':
   w,h,z=e['size'];color=e['color']
   if e['kind']=='person':base=[{'kind':'cylinder','at':[0,0,0],'size':[w*.92,h*.72,z*.92],'color':color},{'kind':'sphere','at':[0,h*.85-w*.39,0],'size':[w*.78,w*.78,w*.78],'color':color},{'kind':'box','at':[0,h*.45,w*.43],'size':[w*.32,h*.2,.025],'color':'#98a1ac'}]
   else:base=[{'kind':e['kind'],'at':[0,0,0],'size':e['size'],'color':color}]
   e['parts']=base+custom
  for part in e.get('parts',[]):part.setdefault('yaw',0);part.setdefault('color',e.get('color','#c8c9c7'))
 entities={e['id']:e for e in draft['entities']}
 if len(entities)!=len(draft['entities']):raise ValueError('Duplicate entity IDs')
 stages={s['id']:s for s in draft['stages']}
 if len(stages)!=len(draft['stages']):raise ValueError('Duplicate stage IDs')
 requirements={e['id']:e for e in brief.get('events',[])}
 if len(draft['shots'])!=brief.get('shot_count',len(draft['shots'])):raise ValueError('Wrong number of shots')
 result={'version':'1.0','title':draft['title'],'normalizations':notes,'duration':brief['duration'],'entities':draft['entities'],'sets':[{'id':s['id'],'label':s.get('label',s['id']),'objects':[],'environment':{**s.get('environment',{}),'parts':build_environment(s.get('environment',{}))}} for s in draft['stages']],'shots':[]}
 states={};headings={};bindings={};stage=None
 def position(v):
  if len(v)!=3 or any(not isinstance(x,(int,float)) or not math.isfinite(x) for x in v):raise ValueError('Position must be three finite numbers')
  return list(v)
 for i,s in enumerate(draft['shots']):
  changed=s['stage']!=stage;stage=s['stage']
  if stage not in stages:raise ValueError('Unknown stage '+stage)
  if changed:states={k:position(v) for k,v in stages[stage]['positions'].items()};bindings={};headings={}
  for k in s.get('hide',[]):states.pop(k,None);bindings.pop(k,None)
  for k,v in s.get('show',{}).items():
   if k in states:raise ValueError('show cannot teleport an already visible entity '+k)
   states[k]=position(v)
  if s.get('start') and not s.get('jump'):raise ValueError('start requires justified jump')
  for k,v in s.get('start',{}).items():states[k]=position(v)
  for k in s.get('release',[]):bindings.pop(k,None)
  start=copy.deepcopy(states);end=copy.deepcopy(states)
  for k,v in s.get('move',{}).items():
   if k not in states:raise ValueError('Move of invisible entity '+k)
   end[k]=position(v)
  bindings.update(s.get('carry',{}))
  visiting=set();done=set()
  def attached(k):
   if k in done:return
   if k in visiting:raise ValueError('Cyclic carry attachment')
   visiting.add(k)
   b=bindings[k];parent=b['parent']
   if k not in states or parent not in states:raise ValueError('Carry subject or parent absent')
   if k in s.get('move',{}):raise ValueError(f'{s.get("id",i)}: {k} is attached to {parent}. Remove its independent move to keep it carried, or add release:["{k}"] before moving/placing it separately.')
   if parent in bindings:attached(parent)
   offset=position(b['offset']);end[k]=[a+b for a,b in zip(end[parent],offset)]
   visiting.remove(k);done.add(k)
  for k in bindings:attached(k)
  for k in states:
   if k not in entities:raise ValueError('Undefined entity '+k)
  events=[{'id':x,'at':1} if isinstance(x,str) else x for x in s.get('events',[])]
  for event in events:
   if isinstance(event,dict) and 'id' in event and 'at' not in event:
    event['at']=1;notes.append(f'{s.get("id",i)}: event {event["id"]} omitted at; normalized to end-of-shot at=1, matching string-event default')
  context=list(s.get('context',[]))
  if any(k not in entities or entities[k]['kind']=='person' or max(entities[k]['size'])<3 for k in context):raise ValueError('Context is only for large non-person subjects (>=3m), never small props/people')
  focus=list(s.get('focus',s.get('move',{}).keys()))
  if not focus:focus=[k for k in states if k in brief.get('cast',{})] or list(states)
  for ev in events:
   if ev['id'] not in requirements:raise ValueError('Unknown event '+ev['id'])
   focus.extend(requirements[ev['id']].get('subjects',[]))
  focus=[k for k in dict.fromkeys(focus) if k not in context]
  if any(k not in states for k in focus):raise ValueError(f"{s.get('id',i)}: required focus/event subjects absent: {[k for k in focus if k not in states]}; visible={list(states)}. Restore with show before the event; do not delete required subjects.")
  if not focus and context:
   focus=context[:];notes.append(f"{s.get('id',i)}: context-only shot aims at large context subjects; partial-visibility audit retained")
  if not focus:raise ValueError(f"{s.get('id',i)}: Empty shot; provide a visible focus or large context subject")
  def center(state):return [sum(state[k][j]+(entities[k]['size'][1]*({'close':.76,'medium':.60}.get(s.get('framing'),.5) if entities[k]['kind']=='person' else .5) if j==1 else 0) for k in focus)/len(focus) for j in range(3)]
  c0=center(start);c1=center(end);mid=[(a+b)/2 for a,b in zip(c0,c1)]
  angle=math.radians(s.get('angle',0));framing=s.get('framing','full');cam=s.get('camera','static')
  if s.get('lens') and 'fov' in s:raise ValueError('Specify lens or fov, not both')
  fov=s.get('fov',50)
  if s.get('lens'):fov=math.degrees(2*math.atan(36/(2*s['lens']*(16/9))))
  coverage={'wide':.32,'full':.58,'medium':.78,'close':1.1,'insert':.72}.get(framing)
  if coverage is None:raise ValueError('framing must be wide/full/medium/close/insert')
  widths=[];heights=[]
  for state in [start,end]:
   widths.append(max(state[k][0]+entities[k]['size'][0]/2 for k in focus)-min(state[k][0]-entities[k]['size'][0]/2 for k in focus))
   heights.append(max(state[k][1]+entities[k]['size'][1] for k in focus)-min(state[k][1] for k in focus))
  dist=s.get('distance',max(1.8,max(widths)/(2*math.tan(math.radians(fov/2))*16/9*.80),max(heights)/(2*math.tan(math.radians(fov/2))*coverage)))
  height=s.get('height',2.3 if framing=='wide' else 1.55)
  if framing=='insert':height=s.get('height',mid[1]+max(.4,dist*.2))
  move=s.get('travel',min(2,dist*.28));lookoffset=s.get('look_offset',[0,0,0])
  c0=[a+b for a,b in zip(c0,lookoffset)];c1=[a+b for a,b in zip(c1,lookoffset)];mid=[(a+b)/2 for a,b in zip(c0,c1)]
  def offset(c,d=dist,da=0):return [c[0]+math.sin(angle+da)*d,height,c[2]+math.cos(angle+da)*d]
  a=offset(mid);b=a[:];look=mid;look_to=mid
  if cam=='push':a=offset(mid,dist+move/2);b=offset(mid,max(.8,dist-move/2))
  elif cam=='pull':a=offset(mid,max(.8,dist-move/2));b=offset(mid,dist+move/2)
  elif cam=='truck':a=[a[0]-move/2*math.cos(angle),a[1],a[2]+move/2*math.sin(angle)];b=[b[0]+move/2*math.cos(angle),b[1],b[2]-move/2*math.sin(angle)]
  elif cam=='orbit':a=offset(mid,dist,-s.get('arc',2*math.asin(min(.9,move/(2*dist))))/2);b=offset(mid,dist,s.get('arc',2*math.asin(min(.9,move/(2*dist))))/2)
  elif cam=='follow':a=offset(c0);b=offset(c1);look=c0;look_to=c1
  elif cam=='pan':look=[mid[0]-math.cos(angle),mid[1],mid[2]+math.sin(angle)];look_to=[mid[0]+math.cos(angle),mid[1],mid[2]-math.sin(angle)]
  elif cam!='static':raise ValueError('Unknown camera '+cam)
  actors=[]
  for k in states:
   delta=[b-a for a,b in zip(start[k],end[k])];yaw=s.get('yaw',{}).get(k,math.degrees(math.atan2(delta[0],delta[2])) if entities[k]['kind']=='person' and math.hypot(delta[0],delta[2])>.01 else headings.get(k,0));headings[k]=yaw
   actors.append({'id':k,'from':start[k],'to':end[k],'yaw':yaw})
  result['shots'].append({'id':s.get('id',f's{i+1:02d}'),'set':stage,'duration':s.get('duration',brief['duration']/len(draft['shots'])),'beat':s['beat'],'description':s['beat'],'video_prompt':s['video_prompt'],'continuity':'time_jump' if changed or s.get('jump') else 'continuous','cut_reason':s.get('jump','Establish stage' if changed else ''),'camera':{'type':cam,'from':a,'to':b,'look':look,'look_to':look_to,'fov':fov,'auto_frame':s.get('auto_frame',True),'framing':framing},'actors':actors,'focus':focus,'context':context,'events':events})
  states=end
 return result

def compile_plan(draft,brief):
 """Compile once; on failure gather independent set and story diagnostics, never render an altered draft."""
 try:return _compile_plan(draft,brief)
 except Exception as original:
  diagnostics=[{'code':'compile','message':str(original)}]
  # Bad scenery should not conceal independent event errors until the next repair.
  try:
   isolated=copy.deepcopy(draft)
   for st in isolated.get('stages',[]):
    env=st.get('environment',{})
    for j,m in enumerate(env.get('modules',[])):
     try:build_environment({'modules':[m]})
     except Exception as e:
      msg=f"stage {st['id']} modules[{j}]: {e}"
      diagnostics.append({'code':'environment_input','message':msg})
    st['environment']={'description':'DIAGNOSTIC ONLY: scenery removed to inspect independent event data','modules':[]}
   diagnostic_scene=_compile_plan(isolated,brief)
   from check import validate
   for issue in validate(diagnostic_scene,brief)['errors']:
    if issue['code']!='unbuilt_set':diagnostics.append(issue)
  except Exception as other:
   if str(other)!=str(original):diagnostics.append({'code':'blocking_input','message':str(other)})
  unique=list({(d['code'],d['message']):d for d in diagnostics}.values())
  raise ValueError(json.dumps({'diagnostics':unique,'note':'No scene was accepted or rendered. Scenery-free numeric inspection is diagnostic only; repair the original draft.'},ensure_ascii=False)) from original

def main():
 p=argparse.ArgumentParser();p.add_argument('draft');p.add_argument('--brief',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 result=compile_plan(json.loads(Path(a.draft).read_text()),json.loads(Path(a.brief).read_text()));Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
