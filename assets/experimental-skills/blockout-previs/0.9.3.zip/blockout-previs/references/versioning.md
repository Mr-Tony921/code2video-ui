# Version maintenance

The authoritative release number is `package.json.version`; keep package-lock root versions, SKILL heading, technical/review contracts and CHANGELOG aligned. `scene.version: "1.0"` is a separate scene schema version, not the skill version.

Stay in **0.x.x until the user explicitly approves a 1.0.0 release**. New functionality increments the minor version; fixes increment the patch. Never infer release approval from a successful benchmark.

Use patch releases for compatible diagnostic/documentation fixes; minor releases for new tools, review behavior or output fields; major releases for incompatible scene grammar/entrypoint redesign. A new mandatory review gate is operationally significant even if scene grammar stays unchanged: 0.5.0 requires adapting older callers to record-review.

Each initialized job stores skill version and a SHA-256 fingerprint of every packaged file (excluding dependencies/caches). Subsequent commands refuse a different source fingerprint. The shot manifest and review index carry this provenance. This prevents a mid-job upgrade from silently changing a result. To resume an older job, use its archived original skill; do not edit job hashes or reset its budget to make a stale run look valid. A new independent experiment gets a new job and fresh measured budget.

For a release:

1. Preserve the previous ZIP plus its per-file/hash manifest in a versioned release directory.
2. Update CHANGELOG with behavior, compatibility and known limits. Separate promised tests from actual recorded results.
3. Run the installation example, deadline/two-repair/stale-output guards, camera invariants and any changed review rules. Test the new workflow with an actual model; mechanical fixtures alone do not prove instruction following.
4. Build a package excluding credentials, provider adapters, model reasoning, environments, node_modules, experiment outputs and failed videos. Record ZIP SHA-256 and per-file hashes. Install the ZIP in a fresh folder and run its short example.
5. Freeze each comparison's skill/config/case/source snapshots before running. Record provider-returned model name, channel, reasoning settings, end-to-end time, repair count, output frame count and failure reason. A later successful retry is a new row, never a replacement for a failure.

## Comparing results fairly

Use the same brief, duration, resolution, fps, predicate thresholds, repair budget and tools. Record GPU queue time, model time and render/decode separately. Distinguish:

- **Workflow completion:** playable validated film and all declared contract checks within the deadline.
- **Narrative quality:** blinded or explicitly nonblinded review of the same events, camera, staging, props and direction. Model self-review strictness is a confound, not a neutral score.
- **Engine comparison:** same effective scene and camera; report render-only cost and different lighting/material settings. It is not another model planning trial.
- **New release validation:** a new tool-call probe of that release. Never label older version timings as new-version measurements.

For visual cross-model comparison, align by required event ID and intended story beat, not arbitrary frame number when plans differ. Show original full event frames side by side, then matched crops for critical props; retain metadata explaining differing event timestamps/cameras. Do not crop away a failure or infer success from a decorative label. Keep coarse narrative failures visible even when numeric checks pass.
