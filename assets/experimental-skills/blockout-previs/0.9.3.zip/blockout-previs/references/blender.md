# Optional Blender Workbench export

This adapter is optional; normal skill usage needs only Three.js. Tested module: bpy 4.2.22 LTS, Python 3.11, Linux. Install once with `python -m pip install -r requirements-blender.txt`.

First use the normal preview tool to produce an audited `effective-scene.json`. Blender requires this actual camera version and rejects unresolved auto_frame requests. Run:

```sh
python scripts/render_blender.py --scene JOB/output/effective-scene.json --out JOB/blender --video --fps 24 --width 640 --height 360 --samples 8 --timeout 480
```

Use a separate output directory. This tool shares the scene geometry, shot durations and camera paths, with Workbench shading/shadows. It writes H.264 `preview.mp4`, render timing/hardware metadata, and representative start-frame PNGs. It removes the temporary PNG sequence after successful encoding. On failure, report failure and remove only that attempt's temporary directory after retaining concise diagnostics.

This script's timeout is a tool timeout, not a fresh film budget. Before calling it, calculate the remaining shared job time and pass no more than that, leaving time for full decoding. For a hard caller deadline, run it under the same process timeout used for other tools. The caller must perform `check.py --video` verification against the scene and brief before accepting the video. A .blend scene with editable keyframe animation, depth/pose exports and downstream video generation are not implemented.

Rendering speed and appearance differ from Three.js. Compare identical effective-scene data and output size/FPS; do not count a previously generated plan as a zero-cost planning phase. Engine comparison artifacts live in the experiment report, outside this portable skill.
