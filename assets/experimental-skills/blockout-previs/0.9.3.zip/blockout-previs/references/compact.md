# Compact director plan · 0.9.3

Return one JSON object with title, entities, stages, shots. Film duration/shot count/events come from the brief. All IDs are stable ASCII identifiers, descriptions and video_prompt in Chinese. No executable code or external asset URLs.

## Executable blocking comes first

Prose does not animate anything. Every required displacement must have `move` on its event shot; every transported prop needs `carry`; detach with `release`. Decide executable fields **before** beat/video_prompt. Use event at=1 unless an earlier instant is required; an at=0 arrival observes the initial position. Compute the checked distance at the selected event time, not just the destination. A visual review cannot supply missing motion.

Independent syntax example (IDs and coordinates are illustrative, never copy them as a story): initial p=[0,0,0], parcel=[0.6,0.8,0]. A shot with `"move":{"p":[3.6,0,0]},"carry":{"parcel":{"parent":"p","offset":[0.6,0.8,0]}},"events":[{"id":"required_event_id","at":1}]` makes p travel3.6m and the parcel follow. A later `"release":["parcel"],"move":{"parcel":[4.3,0.75,0]}` places it independently. Event IDs must come from the actual brief; no automatic event is implied by this example. A travel predicate3m needs a margin; a camera travel predicate requires actual camera movement, not a pan.

## Entities and positions

Entity: `{id,label,kind,size:[width,height,depth],color:"#c8c9c7"}`. kind = person/box/sphere/cylinder. Coordinates in meters, Y up, bottom center anchor. Use kind:person for every human proxy (cylinder body + sphere head); reserve cylinder for nonhuman objects. Person typically [0.65,1.75,0.65]; no face/rig needed. Color can be subtly gray-tinted for identity. Optional `asset` adds reusable detail within the same size: table, bench, chair, doorframe, cup, bag, cart, vehicle, train, console, shelf, tree, fountain. Asset shapes are reusable components, not story templates. train/vehicle length is along X. A large train is not a solid anonymous block once windows/door panels are present. Prefer an existing asset component first. Custom `parts` **add to** the default primitive/asset body; they do not erase it. To intentionally author an entire hollow/composite shape, set `parts_mode:"replace"` and provide every structural part, including its body/support. For windows/details on a box, keep the default additive mode. Custom parts: primitive kind box/sphere/cylinder/cone, local bottom `at`, `size`, `color`, `yaw`.

Stage: `{id,label,positions:{entity_id:[x,y,z]},environment:{description,ground:{size:[width,depth],color},modules:[...]}}`.
All active story objects belong in positions; do not duplicate them as environmental decoration. Stage change loads its initial positions. `jump` is a **nonempty string explaining the time/location ellipsis**, e.g. `"jump":"省略中间行程"`, never a boolean flag. `start` is an entity-ID → [x,y,z] map for the explicitly justified new state. `cut_reason` belongs to the expanded scene, not the preferred compact syntax. A supplied nonempty cut_reason paired with jump:true or start is accepted as an explicit reason alias; no reason is invented. Returning to a stage reinitializes it, so explicitly restore current ownership/positions when needed. Ground bottom height is 0 by default. Build believable scene boundaries around the action's spatial extent, not an infinite floor.

## Scenography modules (read before choosing shots)

Each module: `{kind,at:[x,y,z],size:[width,height,depth],yaw:0,color:"#c8c9c7"}`. Optional `repeat:{count:1..24,step:[dx,dy,dz]}` makes evenly spaced copies in world coordinates. Max 1,800 expanded environment parts/stage; usually 100–500 is sufficient. Default neutral gray; use three or four gray tones for depth/material separation. No grid floor.

Available kinds and their useful meaning:
- box/wall, sphere/cylinder/cone (column is a cylindrical pillar): arbitrary masses, parapets, plinths, planters, barriers; compose new things freely.
- facade: building volume with repeated window recesses, sills and roof edge. Width X, height Y, depth Z; windows on ±Z sides. Use several volumes to define a street/courtyard, not one giant wall across actors.
- window_wall: low opaque base, mullions and horizontal frames; openings remain open so the camera sees depth. Width X; thin depth. Useful for room boundaries, shop windows and large halls.
- doorframe: open doorway, not a filled box. Width X; passage along Z.
- stairs: steps rise from −Z toward +Z; optional steps default8. Model motion must actually rise in Y when ascending.
- rail: posts and two horizontal rails along X. Rotate to outline a terrace or walkway.
- canopy: roof slab + four corner supports, open sides. size[1] is TOTAL clearance/roof height (usually3–4m), not roof thickness. bench/chair size[1] is TOTAL backrest height (usually0.8–1m), not seat height.
- table/bench/chair: separate tops, legs and backs; size is outer dimensions. Table height is top height; person may sit only if story/representation supports it.
- shelf: uprights, shelves and simple contents; optional contents:false. Repeat for libraries, storage, shops and workspaces.
- tree: trunk and faceted crown; lamp: pole and simple shade.
- road: darker strip along Z, dashed center and curb edges; size Y usually0.03. Use ordinary flat boxes for sidewalks/plazas, avoid raising actors accidentally.
- fountain: basin, darker water disk and central column.
- vehicle/train/cart/console/cup/bag also work as static modules when not story actors.

Build the requested place with useful depth cues. Foreground/middle/background layers may help but are not mandatory counts; never add an occluder just to fill a layer. A room needs walls/window frames/openings and furniture; a street needs building edges, road/sidewalk division and depth cues; a plaza needs bounded paths, landscape/architecture and landmarks. Other scenes use the same components creatively. Explain intended geography in environment.description. Do not add scenery solely to meet a part count. Keep camera paths inside open space; no automatic hiding of walls for convenience.

## Shots and continuity

Write strict JSON: quoted keys/strings, numeric arrays, no comments/trailing commas, no markdown. A nested camera object is accepted only when its parameters do not conflict with flat fields. Prefer the flat form shown below.

Shot required: `{id,stage,beat,video_prompt,camera,events:[]}`. Optional duration; default brief.duration/number_of_shots. Positions inherit continuously. `move:{id:[destination]}` changes only endpoints; linear translation is the proxy action. `yaw:{id:degrees}` sets facing (0=+Z,90=+X); moving people otherwise derive travel heading. Vehicle heading does not auto-rotate. Use `start:{id:[x,y,z]}` plus `jump:"reason"` only for actual time/location ellipses, never to hide errors. `jump:false` or `jump:null` without start means no jump and is normalized away.

`carry:{child:{parent,offset:[x,y,z]}}` attaches a prop to its parent endpoint and later translation. Put carried props outside body volume and on real support when applicable. A new binding moves the prop from its current position to the offset; it does not teleport its start. Bound props cannot also have independent move. `release:[id]` detaches before independent move/place. Keep small props readable; closer insert shots are preferable to arbitrary huge scale. `hide:[id]` removes; `show:{id:[position]}` introduces only an absent entity. Do not hide required event subjects.

`focus:[id,...]` names primary readable subjects. Required event subjects are automatically added. For a large non-person object at least3m wide/high/deep, `context:[id]` allows partial contextual visibility instead of forcing its entire volume into frame. Context objects remain in actual rendering, event predicates and occlusion checks. Never put people, small props or a hidden subject in context to evade review. Example principle: a person near a building opening can dominate while part of the building establishes place. An establishing/insert shot may use only large context subjects: their centers supply the aim, while partial-visibility checks remain active. Otherwise focus may not be empty.

## Camera design

camera = static/push/pull/truck/pan/follow/orbit. `framing` = wide/full/medium/close/insert. Execute the camera prompt. Use only the requested number of shots and shot scales; a single static shot or repeated fixed views can be correct. If unspecified, choose simple useful framing that shows the required event. Do not impose three scales, extra movement, or an aesthetic redesign. Explicit camera constraints in the brief are binding.

- angle:0 camera from+Z;90 from+X. Keep a consistent action-axis side for dialogue. Change angle/framing for a reason.
- height: **absolute world camera height**, default1.55m (wide2.3m). Low0.35–0.8, eye1.3–1.8, elevated only for geography. This differs from older releases' relative +6m default.
- distance: optional horizontal stand-off; otherwise derived from primary subject extents and framing. Do not blindly use distance12 for a single person.
- fov: vertical degrees default50, or lens:24/35/50 etc (36mm horizontal sensor,16:9); do not set both. Narrower lenses require more distance.
- travel: world-space movement length for push/pull/truck/orbit; default small, about2m. For a camera_move_min predicate set travel at least threshold+0.3. Orbit optionally arc radians; when arc is given its chord length is 2*distance*sin(arc/2). Follow moves with the focused group's path; pan has no camera translation.
- look_offset:[x,y,z] shifts aim from group center; use cautiously for composition. auto_frame defaults true: bounded adjustment can rotate horizontally up to24° and adjust distance within0.65–1.6×, but cannot lift the camera or erase its displacement. Inspect effective-scene. If it cannot find a readable view, replan that shot within the repair budget.

Events: list required IDs exactly once, in brief order, spread through the film. String ID means at end u=1; `{id,at:0..1}` chooses another time. All event numeric predicates are binding. move_min is travel **within that shot**, distance uses bottom anchors including Y. Use margins (e.g. requirement<=2m, plan1.6m). Don't move far-separated subjects just to make a close shot; use appropriate wide framing and readable silhouettes. Event people must be at least26 pixels high in sampled 640×360 projections; far establishing scenery can be smaller when it is not a required person event.

Beat describes what proxy coordinates genuinely show. video_prompt describes intended final live-action shot, including omitted emotion/acting; it must not falsely claim a proxy already performed hand/face animation. Make environment, lens/height, subject orientation and foreground/background relationships explicit in the shot's Chinese prose.


Minimal syntax illustration (not a complete story):
```json
{"title":"自定义故事","entities":[{"id":"p","label":"人物","kind":"person","size":[0.65,1.75,0.65],"color":"#b3b8b9"}],"stages":[{"id":"room","label":"房间","positions":{"p":[0,0,0]},"environment":{"description":"说明空间边界及其与行动的关系","ground":{"size":[16,16],"color":"#b5b8b7"},"modules":[{"kind":"window_wall","at":[0,0,-4],"size":[12,4,0.15],"color":"#9c9e9f"}]}}],"shots":[{"id":"s01","stage":"room","beat":"人物在空间中停留","video_prompt":"填入最终视频内容","camera":"push","framing":"full","angle":0,"height":1.55,"focus":["p"],"events":[]}]}
```
This syntax fragment is deliberately incomplete; author the actual brief's scenes/events, environment depth, shot count and duration. Never copy its room into unrelated stories.

Before returning JSON, dry-run the ordered events against inherited positions: name the shot carrying each event, ensure its move/carry/release actually changes the required object, calculate checked distances/travel, and verify all event subjects remain visible. Do this internally; output only the final plan. Avoid spending the output budget on long prose: one concise Chinese beat and one concise downstream prompt per shot are enough.


## Targeted repair (same two-round budget)

Prefer editing only affected shot/stage/entity IDs. `patch_draft.py INPUT --patch EDITS --out REVISED` accepts `{shots:[{id,...changed_fields}],stages:[{id,...changed_fields}],entities:[{id,...changed_fields}]}`. Existing IDs only; collection order stays fixed. Nested objects merge, arrays replace, null deletes a field. To remove an old carry binding use `carry:{prop:null}`; to alter environment repetition provide the full modules array. Use this tool then job.py compile; compile consumes the repair round. Keep the successful draft until the revised one passes. A file edit cannot reset time or repair limits.

Example syntax: `{"shots":[{"id":"s03","angle":25,"distance":4.2,"move":{"prop":null}}]}` changes only those fields of an existing shot; it is not a story template. Full draft replacement is still possible when initial JSON was invalid or an intentional structural redesign is required.

Compatibility: an unambiguous action-only object accidentally placed in events is lifted to shot fields and recorded in scene.normalizations. Conflicting endpoints, action timings or unknown actions are rejected; the compiler does not infer a temporal action sequence. Custom parts default yaw=0 and inherit entity color. Prefer correct syntax from the start.

Before adding an environment module, identify its actual action/camera clearance. Keep walls behind or alongside intended cameras, not between camera and required action. A frame may intentionally use a foreground edge, but the relevant person/prop must remain readable throughout. Do not put a full furniture backrest across the core gesture merely because its coordinates are plausible.

## Explicit camera and static-cast requirements

Honor brief.camera_constraints by matching its shot_id, type, framing and optional absolute height range. For lock_camera=true set auto_frame=false. A requested static camera must keep both camera and look-target fixed. Entities listed in brief.static_entities must keep the same position throughout their set; framing them differently does not require moving them. Duration and shot count are independent of the number of optional decorative elements.

Before compiling, cross-check explicit brief counts: duration, shot_count, min_sets (distinct stage IDs actually referenced by shots), and every required event/actor ID. Also preserve supplied camera constraints and static_entities. These are original contract fields, not new artistic goals. If a necessary repair requires new IDs or a missing stage, submit a full corrected compact draft through the same job compile command; it consumes one repair and keeps the original deadline.
