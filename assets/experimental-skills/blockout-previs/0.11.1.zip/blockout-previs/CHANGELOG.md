# Release history

## 0.11.1

- Normalize exact copies of frozen event metadata in compact shot events, avoiding a model repair for redundant description/check/proxy/delegation fields. Reject conflicting copies; never change the original brief.
- Runtime poses and Three.js-only action scope match 0.11.0. Focused model cohort remains attributed to frozen 0.11.0; compiler replays and current tool tests are reported separately.

## 0.11.0

- Make new video briefs blocking-first: retain original events, executable proxy obligations and explicit downstream performance. Carry delegated actions into scene/shot manifests and video prompts; verify they match the frozen brief.
- Add static right-hand handshake and lower-arm embrace presets. Retain legacy combat poses for old projects; new fights use blocking without limb choreography.
- Ship Three.js only; remove alternative renderer, requirements and instructions. Keep prior experimental evidence archived, outside the active package.
- Keep two initial repairs, one scoped follow-up repair and video-first delivery. Director-workspace endpoint remains pending. New focused tests are separate from historical benchmark cohorts.

## 0.10.15

- Document a shared scene-generation/edit core with two delivery targets: implemented default video export and planned 3D director-workspace handoff.
- Keep current optimization and pass@1 evaluation video-oriented; director-specific requirements, test cases and frontend integration are pending.
- Business frontend owns rendering/display/dragging; our future scope is editable data, scoped natural-language changes and lightweight integration validation.
- Documentation and version metadata only. Runtime, schemas, dependencies, model calls and repair budgets are unchanged; prior test/model evidence remains attributed to its measured version.

## 0.10.14

- Clarify event visibility versus offscreen persistent ownership, especially for POV. Do not add unnecessary in-frame carried-prop constraints to a user brief.
- Synchronize brief pose vocabulary. Renderer and motion implementation are unchanged from 0.10.13; no extra model/review loop, gait or Blender route.
- Keep frozen benchmark outcomes unchanged; corrected future contracts are separate from the measured cohorts.

## 0.10.13

- Add explicit backward-lean posture; preserve legacy forward lean. Correct pose/camera lists in compact reference.
- Keep Three.js as default. Optional Blender export remains the same motion adapter; no automatic IK route or extra review loop.
- Separately validate the corrected sparring case; do not overwrite the frozen 0.10.11 first-job cohort.

- Evaluate carried props each frame from the live parent, optional local wrist/body anchor, yaw and pose; bounded pickup, persistent ownership, coherent release.
- Add POV, over-shoulder and chase cameras attached to a named subject; preserve intended self-visibility semantics and check other subjects normally.
- Add generic embrace/guard/punch/kick poses and a lightweight quadruped; detailed characters and gait remain optional.
- Keep two initial-job corrections, one follow-up correction and separate render/quality outcomes.
- Model benchmarks are newly frozen pass@1 action cases; no inherited model quality score or benchmark-specific scene recipe enters the skill.

# 0.10.10

- Split render_success and quality_pass. Export a validated reference even if narrative/visual review blocks quality acceptance; retain the last structurally renderable scene/draft.
- Keep playable imperfect videos as user-adjustable baselines, with explicit basic/advanced instruction findings.
- Follow-up edits may start from a playable uncertified baseline; unchanged unresolved quality is never silently promoted.
- Benchmark interpretation is pass@1 only: initial candidate plus at most two internal corrections; no independent retries. Historical post-hoc exports are labeled separately from original pipeline delivery.

# 0.10.9

- Separate user-edit branch: accepted baseline preserved, frozen field scope, automatic compiled dependency coverage, local comparison pages, one correction maximum.
- Inherit unchanged accepted evidence explicitly; no whole-film semantic re-review or unsolicited modeling polish.
- Factual packet now describes interpolation, endpoint carry pickup and offscreen arrivals; small noncritical overlap is not a new quality gate.
- Claude Code installation guidance only; server integration remains for the user to test.
- 0.10.8 render/compiler behavior is unchanged. 0.10.8 model benchmark numbers are historical evidence, not a claimed 0.10.9 full matrix.

# 0.10.8

- Changes human representation to optional detail: default cylinder/sphere, optional oriented marker or articulated main character; no global face/limb/posture gate.
- Makes pose/facing detail predicates advisory unless the caller explicitly freezes severity:error for a genuinely hard request; preserves travel, ownership, location, camera and visibility checks.
- Updates Three.js and Blender consistently, and factual evidence accurately distinguishes omitted joint poses from rendered ones.
- Keeps the separate literal-facts review, bounded two repairs, soft 600s target, medium/high host settings and portable workflow.

# 0.10.5

- Fixes floating-point false failures at inclusive distance/motion boundaries with1e-6m tolerance, consistent with the existing leads predicate. Meaningful shortfalls remain failures.
- Keeps planning, renderer, camera, visual-review protocol and finite repair policy unchanged.

# 0.10.4

- Clarifies absolute camera height on elevated floors and local versus continuous location coordinates, based on a measured DeepSeek low planning error. Required supports must not be removed to mask a below-floor camera.
- Documentation-only change from 0.10.3; renderer, predicates, review schema and thresholds are unchanged.

# 0.10.3

- Adds a layout-independent leads predicate for explicit leading/following along actual motion.
- Requires event-level observed facts and action/location/order/visibility/props review decisions. An admitted instruction violation cannot remain a warning; noncritical warnings must explain why requirements remain satisfied.
- Makes action-first output ordering explicit and distinguishes critic repair suggestions from original user constraints.
- Keeps soft600s timing, two repairs, persistent worlds, human poses, renderer and camera thresholds unchanged.

# 0.10.2

The camera solver and checker share render-profile.json and the same11 sampling times, frame/visibility fractions and26px event-human criterion. The solver stops at the first passing view; it no longer pulls a valid camera farther back to optimize non-required visibility. Expanded events preserve authoritative subject IDs for exact-time readability checks. Optional prompt-derived remain_after and face_toward checks verify leave-behind state and facing from actual scene data.

# 0.10.1

Shared human joint data for Three.js/Blender; one-knee posture; consistent soft-target references; small/person context subjects are promoted to strict focus rather than consuming a repair for a harmless field choice. Camera collision uses each human mesh’s actual local geometry bounds (prevents treating slender limbs as unit boxes). Visibility diagnostics name exact environment module/copy IDs for targeted repairs. Absent travellers may enter an already active location; enter still rejects relocation of visible actors. Model experiment results are maintained separately against the immutable source fingerprint.

# 0.10.0

Persistent locations and carry bindings; explicit traveller enter; neutral face direction and articulated poses; optional decor cutaways preserving camera; motion-aware default framing; soft 600s target; measured high/low/hybrid caller profiles. This development release does not itself claim a benchmark success rate.

# 0.9.3

- Specify jump as a reason string in the compact contract; report all invalid compact shot IDs before expanded-schema errors.
- Normalize explicit jump/cut_reason aliases without inventing a reason, and remove false no-jump flags.
- Permit ID patches to repair fields that previously failed normalization; the compiler remains the validation gate.
- Clarify explicit brief cardinalities and same-job structural draft replacement.
- 0.9.2 remained a mechanically validated candidate; final model comparison uses this frozen release.

# 0.9.2

- Fix false enclosure alarms for open/compound assets whose aggregate center is empty.
- Sample actual component interiors for compound visibility, preserving proportional framing/visibility thresholds; simple primitives retain their seven samples.
- Report blocking object IDs from actual ray hits so repairs can distinguish actor overlap from scenery.
- Full frozen comparison is rerun; earlier failures remain archived rather than rescored.

# 0.9.1

- Pilot-driven DeepSeek patch clarifies bottom-center anchors and support-top arithmetic.
- Object-form events without at use the same explicit end-of-shot default as string-form events, with normalization recorded.
- Removes remaining obsolete140-second reserve prose; the tool reports a duration-aware reserve.
- Resolve uniquely named evidence-page basenames without fabricating review evidence.
- Avoid a redundant critic call when automatic preview checks already fail; repairs still inspect evidence and final review remains mandatory.
- No test-story coordinates, names or layouts added to the skill.

# 0.9.0

- Variable 10–300-second story scope; no compulsory 20 shots or three framing scales.
- Original instruction and renderability define acceptance; aesthetic suggestions cannot create blockers.
- Explicit camera/static-cast constraints and duration-aware export reserve.
- DeepSeek-only high-thinking, output-budget and schema/action/review compensations are a separate model patch.
- Version remains experimental0.x; fresh independent pass@1/pass@3 trials are reported separately from internal repair counts.

# Changelog

## 0.10.7

- Factual packets annotate endpoint displacement and nearby ground/module support surfaces, with explicit limitations; these are evidence rather than new acceptance thresholds.
- Factual packets now include source-bound built-in person/pose semantics and furniture support formulas. The 0.10.6 pilot exposed missing evidence, so its results were excluded rather than counted as model failures.
- Keep literal motion/place checks separate from image visibility and unrequested detailed contact. Rendering and scene semantics remain unchanged.

## 0.10.6

- Add an opt-in, hash-bound factual review packet and receipt; DeepSeek patch requires it before final export. Original event clauses are checked separately from image visibility, sharing the same two repairs and soft 600-second target.
- Record medium support differences and distinguish first-review-high strategies from first-review-low strategies. No provider adapter or benchmark answers enter the skill.
- Rendering, poses, scene compilation and numeric thresholds are unchanged from 0.10.5. Candidate behavior requires fresh whole-job verification.

## 0.8.3

- Complete context-only camera support: do not duplicate a contextual subject in the primary ray audit or camera scoring. Synthetic partial-view regression confirms one contextual audit per sample.
- Clarify that close shots may omit full bodies and environment when their story role and identity remain clear; downstream acting can motivate a static proxy close-up.

## 0.8.2

- Gather independent scenery and numeric-story diagnostics when compilation fails, without rendering or accepting the diagnostic scene. Unknown environment keys include explicit null-deletion guidance.
- Support establishing/insert shots aimed solely at large context objects while preserving partial-visibility checks and the ban on people/small props as context.
- Reduce directional-shadow acne on flat proxy surfaces.

## 0.8.1

- Separate rotation-angle validation from coordinate limits; valid180°/270° set modules no longer fail. Errors identify module index, field and value.
- Add generic cylindrical column component and clarify total canopy/seat-back dimensions.
- Put executable motion/carry/release and event-time examples before shot prose; story predicates remain unchanged.
- Provider-only fast-mode experiments remain outside this portable skill.

# Release history

## 0.8.0 — 2026-11-16

- Made compact custom-parts semantics explicit: additive by default; parts_mode=replace deliberately supplies a complete custom body. Built-in asset components remain preferred. Older compact plans relying on implicit replacement must opt into replace; explicit scene parts are unchanged.
- Camera assistance can also move closer (0.65–1.6× horizontal distance) to find an open interior view while retaining authored height and movement.
- Separated reviewer inputs: original requirements and actual audited states, instead of treating creative downstream prose as a new contract. Numerical meters are never inferred from thumbnail scale.
- Experiment-only Opus adapter corrected to adaptive/low after the fallback channel rejected old flags; provider routing remains outside the skill.
- 0.7 trials and deliberate batch interruption remain recorded separately, with no success backfill.


## 0.7.0 — 2026-11-16

- Integrated applicable lessons from the supplied legacy-agent handoff: fixed requirements versus creative choices, separate camera/occlusion/crop checks, actual-state determinism samples, strict media verification and immutable presentation copies.
- Added standalone ID-based compact draft patching; same shared deadline and two compile/repair cap.
- Added camera/near-plane primitive collision probes and A–B–A state/pixel reports; no claim of full collision physics or exhaustive determinism.
- Added explicit normalizations for unambiguous nested action fields and optional custom-part defaults; contradictory intent remains an error.
- Rig, IK, wheel physics, repeated full-film preview loops and production platform deployment remain outside this simplified director-stage scope.
- Earlier 0.6 prototype failures are retained as independent trials; measured 0.7 validation lives in experiment reports.


## 0.6.0 — 2026-11-16

- Added general scene modules, finite floors, environment instancing, shadows and reusable actor components. No benchmark story templates are included.
- Replaced elevated distant default views with eye-height, subject-derived camera scales and bounded horizontal assistance preserving height/targets/movement.
- Added large-context visibility, scenic requirements, environment occlusion, and precise absent-subject diagnostics; compatible nested camera input accepted when unambiguous.
- Added full-set Blender adapter parity for component geometry; optional export remains slower and independently measured.
- Expanded scene/depth/photography review and Chinese experiment organization. Keep 0.x until explicit user release approval.
- Previous experiment snapshots remain historical; current validation results are recorded outside the portable package.


## 0.5.1 — 2026-11-16

- Fixed overlapping two-line montage labels and enlarged contextual crops with nearest-neighbor scaling; original projected pixel sizes remain labeled. Enlarging does not add detail.
- Scene planner, review gates, timing and repair limits unchanged from 0.5.0. The independent model test remains recorded as 0.5.0; 0.5.1 uses mechanical regression and fresh-package verification.


## 0.5.0 — 2026-11-16

- Added technical-profile and layered-review contracts: output, coordinates, camera, staging, time/repair budgets, evidence and acceptance scope.
- Added real event-before/exact/after samples, projected prop-size flags and contextual crops; bounded overview, continuity, event, detail and cut pages.
- Snapshots pre-repair preview evidence. Builds shot-ID-aligned before/after comparisons and numerical scene differences.
- Added `review` and `record-review` CLI commands. Export/package require a current review receipt with no declared blockers. Complete receipts cover every event and required evidence page; incomplete visual review stays explicit.
- Locked preview/export profile and job skill source/version; shot manifest carries provenance. Existing jobs use their original release; do not upgrade them in place.
- Renderer/camera planner, numeric event thresholds, 600-second budget and two-repair cap otherwise unchanged.
- Validation: mechanical/regression and independent DeepSeek tests are recorded in the experiment deliverables, not inferred from older model runs. The 30-run model comparison remains frozen at 0.4.0.

## 0.4.1 — 2026-11-16

- Expanded error diagnostics with actual distances, event time, positions and travel. Acceptance thresholds unchanged.
- Two final independent DeepSeek low-reasoning tool-use runs completed 300-second videos in 298.97 s and 239.53 s on software WebGL; earlier failed attempts remain recorded.

## 0.4.0 — 2026-11-16

- Preserved camera and look-target displacement under automatic framing; validated actual endpoints, portrait framing, camera types and pan/orbit directions.
- Derived travel yaw only for people; added stricter event/scene/enclosure checks.
- Frozen 10 cases × 3 models comparison; source snapshot and per-run records retained outside the portable package.

## 0.3.x — development snapshots

- Compact plans, position inheritance, prop carry/release and exact event screenshots; intermediate diagnostics superseded by 0.4.0 camera fixes.

## 0.2.0 — historical baseline

- Explicit scene-coordinate baseline; old auto-framing could erase intended follow/pan. Statistics retained for diagnostics, old movies excluded from final accepted examples.
