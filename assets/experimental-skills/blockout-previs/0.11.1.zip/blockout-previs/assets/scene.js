import * as THREE from '/vendor/three.module.js';
import {actorStates,cameraState} from '/motion.js';
let data, renderer, scene, camera, meshes={}, defs={}, active=-1, cameraOverrides={}, environments={}, environmentColliders={}, componentSamples={},cutaways={};
const lerp=(a,b,t)=>a.map((x,i)=>x+(b[i]-x)*t);
const point=(a)=>new THREE.Vector3(...a);
function makeEntity(d){
 const group=new THREE.Group(),mat=new THREE.MeshStandardMaterial({color:d.color||'#e2e5e8',roughness:1,metalness:0});
 const [w,h,z]=d.size;
 if(d.parts?.length){
  for(const p of d.parts)group.add(partMesh(p));
 } else if(d.kind==='person'){
  if(d.detail==='articulated')buildHuman(group,d,mat);else buildProxy(group,d,mat);
 } else {
  let g=d.kind==='sphere'?new THREE.SphereGeometry(.5,16,12):d.kind==='cylinder'?new THREE.CylinderGeometry(.5,.5,1,16):new THREE.BoxGeometry(1,1,1);
  const m=new THREE.Mesh(g,mat);m.scale.set(w,h,z);m.position.y=h/2;group.add(m);
 }
 group.userData.id=d.id;group.traverse(x=>{x.userData.id=d.id;if(x.isMesh){x.castShadow=true;x.receiveShadow=true;}});return group;
}

// Small deterministic joint poses: no gait cycles, skinning, fingers, or facial acting.
const HUMAN_POSES=await (await fetch('/human-poses.json')).json();
const PROFILE=await (await fetch('/render-profile.json')).json();
function buildProxy(group,d,mat){
 const [w,h,z]=d.size;
 const body=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,1,10),mat);body.scale.set(w*.65,h*.8,z*.65);body.position.y=h*.4;group.add(body);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.5,10,6),mat);head.scale.set(h*.2,h*.2,h*.2);head.position.y=h*.9;group.add(head);
 if(d.detail==='oriented'||d.face_marker){const marker=new THREE.Mesh(new THREE.BoxGeometry(h*.04,h*.035,h*.055),new THREE.MeshStandardMaterial({color:'#59636c',roughness:1}));marker.position.set(0,h*.9,h*.11);group.add(marker);}
 group.userData.simplePerson=true;
}
function humanJoints(p){return HUMAN_POSES[p]||HUMAN_POSES.stand;}
function buildHuman(group,d,mat){
 const bones={},add=(name,r)=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,1,8),mat);group.add(m);bones[name]=m;};
 add('torso',.115*d.size[1]);
 for(const side of ['l','r'])for(const name of ['upperArm','lowerArm','thigh','shin'])add(side+name,(name==='thigh'?.047:.035)*d.size[1]);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.09*d.size[1],12,8),mat);group.add(head);
 if(d.face_marker){
 const faceMat=new THREE.MeshStandardMaterial({color:'#59636c',roughness:1});
 for(const x of [-.031,.031]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.009*d.size[1],6,4),faceMat);eye.position.set(x*d.size[1],.014*d.size[1],.081*d.size[1]);head.add(eye);}
 const nose=new THREE.Mesh(new THREE.BoxGeometry(.025*d.size[1],.025*d.size[1],.045*d.size[1]),faceMat);nose.position.set(0,-.004*d.size[1],.095*d.size[1]);head.add(nose);
 const mouth=new THREE.Mesh(new THREE.BoxGeometry(.035*d.size[1],.006*d.size[1],.009*d.size[1]),faceMat);mouth.position.set(0,-.037*d.size[1],.082*d.size[1]);head.add(mouth);
 }
 group.userData.human={bones,head};applyPose(group,d,'stand','stand',0);
}
function applyPose(group,d,from,to,u){
 const rig=group.userData.human;if(!rig)return;
 const a=humanJoints(from),b=humanJoints(to),j={};for(const k in a)j[k]=point(lerp(a[k],b[k],u)).multiplyScalar(d.size[1]);
 const bone=(name,p,q)=>{const m=rig.bones[name],v=q.clone().sub(p);m.position.copy(p).add(q).multiplyScalar(.5);m.scale.y=v.length();m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),v.normalize());};
 bone('torso',j.hip,j.neck);
 for(const side of ['l','r']){bone(side+'upperArm',j[side+'shoulder'],j[side+'elbow']);bone(side+'lowerArm',j[side+'elbow'],j[side+'wrist']);bone(side+'thigh',j[side+'hip'],j[side+'knee']);bone(side+'shin',j[side+'knee'],j[side+'ankle']);}
 rig.head.position.copy(j.head);group.userData.poseJoints=j;
}

function geometry(kind){return kind==='sphere'?new THREE.IcosahedronGeometry(.5,1):kind==='cone'?new THREE.ConeGeometry(.5,1,10):kind==='cylinder'?new THREE.CylinderGeometry(.5,.5,1,12):new THREE.BoxGeometry(1,1,1);}
function partMesh(p){const mesh=new THREE.Mesh(geometry(p.kind),new THREE.MeshStandardMaterial({color:p.color,roughness:1}));mesh.position.set(p.at[0],p.at[1]+p.size[1]/2,p.at[2]);mesh.scale.set(...p.size);mesh.rotation.y=(p.yaw||0)*Math.PI/180;return mesh;}
function makeEnvironment(st){
 const group=new THREE.Group(),env=st.environment||{},parts=env.parts||[],buckets={};environmentColliders[st.id]=[];
 for(const p of parts)(buckets[p.id+p.kind+p.color]??=[]).push(p);
 for(const ps of Object.values(buckets)){
  const mesh=new THREE.InstancedMesh(geometry(ps[0].kind),new THREE.MeshStandardMaterial({color:ps[0].color,roughness:1}),ps.length),dummy=new THREE.Object3D();
  ps.forEach((p,i)=>{dummy.position.set(p.at[0],p.at[1]+p.size[1]/2,p.at[2]);dummy.scale.set(...p.size);dummy.rotation.set(0,(p.yaw||0)*Math.PI/180,0);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);environmentColliders[st.id].push({id:p.id,removable:!!p.removable,kind:p.kind,inverse:dummy.matrix.clone().invert()});});
  mesh.instanceMatrix.needsUpdate=true;mesh.computeBoundingSphere();mesh.castShadow=true;mesh.receiveShadow=true;mesh.userData.id=ps[0].removable?'decor:'+ps[0].id:'environment:'+ps[0].id;mesh.userData.envId=ps[0].id;group.add(mesh);
 }
 const ground=env.ground||{},size=ground.size||[55,55],floor=new THREE.Mesh(new THREE.PlaneGeometry(...size),new THREE.MeshStandardMaterial({color:ground.color||'#b8bab6',roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.set(...(ground.at||[0,-.025,0]));floor.receiveShadow=true;floor.userData.id='ground';group.add(floor);return group;
}
function occluders(){return [...Object.values(meshes).filter(x=>x.visible),...(environments[data.shots[active]?.set]?.children||[]).filter(x=>x.visible)];}
function cameraContacts(){
 const center=camera.position,forward=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion),right=new THREE.Vector3(1,0,0).applyQuaternion(camera.quaternion),up=new THREE.Vector3(0,1,0).applyQuaternion(camera.quaternion);
 const hh=camera.near*Math.tan(camera.fov*Math.PI/360),hw=hh*camera.aspect;const points=[center.clone()];for(const x of [-1,1])for(const y of [-1,1])points.push(center.clone().addScaledVector(forward,camera.near).addScaledVector(right,x*hw).addScaledVector(up,y*hh));
 const inside=(world,inverse,kind)=>{const p=world.clone().applyMatrix4(inverse);if(kind==='sphere')return p.lengthSq()<.245;if(kind==='cylinder')return Math.abs(p.y)<.495&&p.x*p.x+p.z*p.z<.245;return Math.max(Math.abs(p.x),Math.abs(p.y),Math.abs(p.z))<.495;};
 const hits=[];for(const c of environmentColliders[data.shots[active]?.set]||[])if(!(cutaways[active]||data.shots[active]?.hidden_environment||[]).includes(c.id)&&points.some(p=>inside(p,c.inverse,c.kind))){hits.push(c.removable?'decor:'+c.id:'environment:'+c.id);break;}
 for(const [id,m] of Object.entries(meshes))if(m.visible){let hit=false;m.traverse(child=>{if(!child.isMesh)return;const g=child.geometry;if(!g.boundingBox)g.computeBoundingBox();const inv=child.matrixWorld.clone().invert();if(points.some(world=>{const q=world.clone().applyMatrix4(inv);if(!g.boundingBox.containsPoint(q))return false;if(g.type==='SphereGeometry')return q.lengthSq()<(g.parameters.radius*.99)**2;if(g.type==='CylinderGeometry')return q.x*q.x+q.z*q.z<(Math.max(g.parameters.radiusTop,g.parameters.radiusBottom)*.99)**2;return true;}))hit=true;});if(hit)hits.push(id);}
 return hits;
}
function projected(id){
 const mesh=meshes[id],box=new THREE.Box3().setFromObject(mesh),pts=[];
 for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])pts.push(new THREE.Vector3(x,y,z).project(camera));
 const xs=pts.map(p=>p.x),ys=pts.map(p=>p.y);return {minx:Math.min(...xs),maxx:Math.max(...xs),miny:Math.min(...ys),maxy:Math.max(...ys),depth_ok:pts.some(p=>p.z>=-1&&p.z<=1)};
}
function inspectContext(id){
 if(!meshes[id]?.visible)return {id,in_frame:false,occluded:true,context:true};
 const p=projected(id),l=Math.max(-.92,p.minx),r=Math.min(.92,p.maxx),b=Math.max(-.92,p.miny),t=Math.min(.92,p.maxy);let hits=0;const ray=new THREE.Raycaster();
 if(p.depth_ok&&l<r&&b<t)for(let x=0;x<5;x++)for(let y=0;y<3;y++){ray.setFromCamera(new THREE.Vector2(l+(r-l)*(x+.5)/5,b+(t-b)*(y+.5)/3),camera);const h=ray.intersectObjects(occluders(),true)[0];if(h?.object.userData.id===id)hits++;}
 return {id,in_frame:p.depth_ok&&l<r&&b<t,occluded:hits===0,context:true,visible_fraction:hits/15};
}
window.init=({plan,width,height})=>{
 data=plan;componentSamples={};renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true,alpha:false,powerPreference:'high-performance'});
 renderer.setSize(width,height);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;
 document.body.appendChild(renderer.domElement);scene=new THREE.Scene();scene.background=new THREE.Color('#bfc9cf');scene.fog=new THREE.Fog('#bfc9cf',65,150);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
 scene.add(new THREE.HemisphereLight('#ffffff','#7b807e',2.0));let light=new THREE.DirectionalLight('#fff7e9',2.3);light.position.set(-14,22,13);light.castShadow=true;light.shadow.mapSize.set(1024,1024);light.shadow.camera.left=-38;light.shadow.camera.right=38;light.shadow.camera.top=38;light.shadow.camera.bottom=-38;light.shadow.camera.far=100;light.shadow.normalBias=.08;light.shadow.bias=-.0004;scene.add(light);
 for(const st of data.sets){environments[st.id]=makeEnvironment(st);environments[st.id].visible=false;scene.add(environments[st.id]);}
 for(const d of data.entities){defs[d.id]=d;meshes[d.id]=makeEntity(d);scene.add(meshes[d.id]);}
 camera=new THREE.PerspectiveCamera(50,width/height,.05,250);
 const gl=renderer.getContext(),ext=gl.getExtension('WEBGL_debug_renderer_info');
 const proxy_geometry={};for(const d of data.entities)if(d.kind==='person'){let mesh_count=0;meshes[d.id].traverse(n=>{if(n.isMesh)mesh_count++;});proxy_geometry[d.id]={detail:d.detail||'simple',face_marker:!!d.face_marker,mesh_count};}
 return {renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),three:THREE.REVISION,proxy_geometry};
};
function place(id,pos,yaw=0){const m=meshes[id];m.visible=true;m.position.set(...pos);m.rotation.y=yaw*Math.PI/180;}
window.frame=(index,u,draw=true)=>{
 const s=data.shots[index];
 if(active!==index){for(const [id,g] of Object.entries(environments))g.visible=id===s.set;for(const m of Object.values(meshes))m.visible=false;for(const o of data.sets.find(x=>x.id===s.set).objects)place(o.id,o.position,o.yaw||0);active=index;}
 for(const node of environments[s.set]?.children||[])node.visible=!(cutaways[index]||s.hidden_environment||[]).includes(node.userData.envId);
 const states=actorStates(s,defs,u,HUMAN_POSES);
 for(const a of s.actors){place(a.id,states[a.id].position,states[a.id].yaw);applyPose(meshes[a.id],defs[a.id],a.pose||'stand',a.pose_to||a.pose||'stand',u);}
 const c=cameraOverrides[index]||s.camera;
 if(c.rig?.hide_subject)meshes[c.rig.subject].visible=false;
 const {pos,look}=cameraState({...s,camera:c},defs,u,HUMAN_POSES,states);
 camera.position.set(...pos);camera.fov=c.fov||50;camera.lookAt(...look);camera.updateProjectionMatrix();camera.updateMatrixWorld();scene.updateMatrixWorld(true);
 if(draw)renderer.render(scene,camera);
 return {pos,look};
};
function subjectSamples(m,d){
 if(m.userData.human){const j=m.userData.poseJoints;return ['head','neck','hip','lelbow','relbow','lknee','rknee'].map(k=>m.localToWorld(j[k].clone()));}
 if(!d.parts?.length){const [w,h,z]=d.size;return [[0,h*.55,0],[0,h*.85,0],[0,h*.2,0],[-w*.25,h*.55,0],[w*.25,h*.55,0],[0,h*.55,-z*.25],[0,h*.55,z*.25]].map(p=>m.localToWorld(point(p)));}
 if(!componentSamples[d.id]){
  // Cache actual component interiors in entity-local coordinates; only transforms vary per frame.
  const candidates=[];
  m.traverse(child=>{if(child.isMesh)for(const p of [[0,0,0],[-.24,0,0],[.24,0,0],[0,-.24,0],[0,.24,0],[0,0,-.24],[0,0,.24]])candidates.push(m.worldToLocal(child.localToWorld(point(p))));});
  const chosen=candidates.length<=15?candidates:[candidates[0]],used=new Set([0]);
  // Deterministic farthest-point selection distributes samples across the assembly.
  while(candidates.length>15&&chosen.length<15){let best=-1,score=-1;for(let i=0;i<candidates.length;i++){if(used.has(i))continue;const distance=Math.min(...chosen.map(p=>p.distanceToSquared(candidates[i])));if(distance>score){score=distance;best=i;}}if(best<0)break;used.add(best);chosen.push(candidates[best]);}
  componentSamples[d.id]=chosen;
 }
 return componentSamples[d.id].map(p=>m.localToWorld(p.clone()));
}
function inspectSubject(id){
 const m=meshes[id],d=defs[id];
 if(['pov','shoulder'].includes(data.shots[active].camera.type)&&data.shots[active].camera.rig?.subject===id)return {id,viewpoint_subject:true,in_frame:true,occluded:false,visible_fraction:1,framed_fraction:1,height_px:renderer.domElement.height,kind:d.kind};
 if(!m?.visible)return {id,in_frame:false,occluded:true,visible_fraction:0};
 const [w,h,z]=d.size,worldSamples=subjectSamples(m,d),blocking={};
 const objects=occluders(),ray=new THREE.Raycaster();let framed=0,visible=0;
 for(const world of worldSamples){const ndc=world.clone().project(camera);if(Math.abs(ndc.x)>.96||Math.abs(ndc.y)>.96||ndc.z< -1||ndc.z>1)continue;framed++;
  const dist=world.distanceTo(camera.position);ray.set(camera.position,world.clone().sub(camera.position).normalize());const hit=ray.intersectObjects(objects,true)[0];
  if(!hit||hit.object.userData.id===id||hit.distance>=dist-.05)visible++;else{const key=hit.object.userData.id||'unknown';blocking[key]=(blocking[key]||0)+1;}
 }
 const center=m.localToWorld(new THREE.Vector3(0,h*.55,0)).project(camera);
 const bounds=projected(id);return {id,kind:d.kind,in_frame:framed>=Math.ceil(worldSamples.length*2/7),occluded:visible<Math.ceil(worldSamples.length*3/7),sample_count:worldSamples.length,sampling:d.parts?.length?'component_interiors':'primitive_representatives',blocking_objects:blocking,visible_fraction:visible/worldSamples.length,framed_fraction:framed/worldSamples.length,visible_of_framed:visible/Math.max(1,framed),screen:[center.x,center.y],height_px:Math.min(2,bounds.maxy-bounds.miny)*renderer.domElement.height/2,width_px:Math.min(2,bounds.maxx-bounds.minx)*renderer.domElement.width/2};
}
window.audit=()=>{
 const samples=[];
 for(let i=0;i<data.shots.length;i++){const s=data.shots[i];for(let j=0;j<PROFILE.geometry_time_samples;j++){const u=j/(PROFILE.geometry_time_samples-1);window.frame(i,u,false);samples.push({shot:s.id,u,actor_positions:Object.fromEntries(s.actors.map(a=>[a.id,meshes[a.id].getWorldPosition(new THREE.Vector3()).toArray()])),camera_position:camera.position.toArray(),camera_collisions:cameraContacts(),subjects:[...s.focus.filter(id=>!(s.context||[]).includes(id)).map(inspectSubject),...(s.context||[]).map(inspectContext)]});}}
 return samples;
};
window.jpeg=()=>renderer.domElement.toDataURL('image/jpeg',.85).split(',')[1];
window.exportVideo=async ({url,fps})=>{
 const ws=new WebSocket(url);ws.binaryType='arraybuffer';await new Promise((res,rej)=>{ws.onopen=res;ws.onerror=rej;});
 const gl=renderer.getContext(),w=renderer.domElement.width,h=renderer.domElement.height;
 let resolveAck;ws.onmessage=()=>resolveAck?.();let count=0;
 for(let i=0;i<data.shots.length;i++){
  const shot=data.shots[i],n=Math.round(shot.duration*fps);
  for(let k=0;k<n;k++){
   window.frame(i,n<=1?0:k/(n-1));
   const pixels=new Uint8Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
   await new Promise((resolve,reject)=>{resolveAck=resolve;ws.onerror=reject;ws.onclose=()=>reject(Error('encoder disconnected'));ws.send(pixels);});count++;
  }
 }
 ws.send(JSON.stringify({done:true,frames:count}));return count;
};
window.ready=true;

window.compileCameras=()=>{
 const changes=[],ray=new THREE.Raycaster();
 // Cut away ONLY explicitly removable decor. Story entities/supports are never eligible.
 for(let i=0;i<data.shots.length;i++){
  const s=data.shots[i];cutaways[i]=[...(s.hidden_environment||[])];
  for(let pass=0;pass<3;pass++){
   const found=new Set(),supported=new Set();for(let step=0;step<=10;step++){
    window.frame(i,step/10,false);
    // A decorative label cannot waive structural support: preserve anything under an actor.
    for(const m of Object.values(meshes).filter(m=>m.visible)){
     const down=new THREE.Raycaster(m.position.clone().add(new THREE.Vector3(0,.08,0)),new THREE.Vector3(0,-1,0),0,.18);
     const hit=down.intersectObjects((environments[s.set]?.children||[]).filter(x=>x.visible),true)[0];
     if(hit?.object.userData.id?.startsWith('decor:'))supported.add(hit.object.userData.id.slice(6));
    }
    for(const hit of cameraContacts())if(hit.startsWith('decor:'))found.add(hit.slice(6));
    for(const id of s.focus){const v=inspectSubject(id);if(v.occluded)for(const hit of Object.keys(v.blocking_objects||{}))if(hit.startsWith('decor:'))found.add(hit.slice(6));}
   }
   const fresh=[...found].filter(x=>!cutaways[i].includes(x)&&!supported.has(x));if(!fresh.length)break;cutaways[i].push(...fresh);
  }
 }

 for(let i=0;i<data.shots.length;i++){
  const s=data.shots[i],c=s.camera;if(!c.auto_frame)continue;
  const focus=s.focus.length?s.focus:data.sets.find(x=>x.id===s.set).objects.map(x=>x.id);
  const actorFor=id=>s.actors.find(x=>x.id===id)||(()=>{const o=data.sets.find(x=>x.id===s.set).objects.find(x=>x.id===id);return o?{id,from:o.position,to:o.position}:null;})();
  const cameraMid=point(c.from).add(point(c.to)).multiplyScalar(.5),lookMid=point(c.look).add(point(c.look_to||c.look)).multiplyScalar(.5),centerOffset=cameraMid.clone().sub(lookMid);
  let best=null,bestScore=Infinity;
  // Preserve the authored shot. Bounded assistance cannot silently turn eye-level into a bird's-eye diagram.
  const variants=[];for(const scale of [1,.85,.65,1.15,1.35,1.6])for(const angle of [0,12,-12,24,-24])variants.push([scale,angle]);
  for(const [scale,angle] of variants){
   const rot=new THREE.Matrix4().makeRotationY(THREE.MathUtils.degToRad(angle));
   const offset=centerOffset.clone().applyMatrix4(rot);offset.x*=scale;offset.z*=scale;
   const shift=offset.add(lookMid).sub(cameraMid),from=point(c.from).add(shift),to=point(c.to).add(shift);
   const candidate={...c,from:from.toArray(),to:to.toArray(),auto_frame:false};cameraOverrides[i]=candidate;
   let bad=0,occlusionCost=0;
   const subjects=[...focus.filter(id=>!(s.context||[]).includes(id)),...(s.context||[])],stats=Object.fromEntries(subjects.map(id=>[id,{framed:0,visible:0}]));
   for(let step=0;step<PROFILE.geometry_time_samples;step++){
    const u=step/(PROFILE.geometry_time_samples-1);window.frame(i,u,false);bad+=cameraContacts().length*20;
    for(const id of subjects){const p=(s.context||[]).includes(id)?inspectContext(id):inspectSubject(id);stats[id].framed+=p.in_frame?1:0;stats[id].visible+=p.in_frame&&!p.occluded?1:0;occlusionCost+=1-(p.visible_of_framed??p.visible_fraction??0);}
   }
   for(const id of subjects){if(stats[id].framed/PROFILE.geometry_time_samples<PROFILE.minimum_framed_times_fraction)bad+=3;if(stats[id].visible/PROFILE.geometry_time_samples<PROFILE.minimum_visible_times_fraction)bad+=2;}
   for(const ev of s.events){window.frame(i,ev.at,false);for(const id of ev.subjects||s.focus)if(defs[id]?.kind==='person'&&inspectSubject(id).height_px<PROFILE.event_person_min_height_px)bad+=3;}
   const score=bad*100+occlusionCost*.01+Math.abs(angle)*.003+Math.abs(scale-1)*.15;
   if(score<bestScore){best=candidate;bestScore=score;}
   // Keep the first camera satisfying the actual checks. Do not optimize aesthetics by pulling farther back.
   if(bad===0)break;
  }
  cameraOverrides[i]=best;changes.push({shot:s.id,original:c,effective:best,remaining_sample_penalty:bestScore,note:'Bounded camera-path translation only: <=24 degrees horizontal rotation and 0.65..1.6x horizontal distance, preserving camera height, look targets and endpoint displacement. First satisfying candidate retained; same framing/visibility/readability thresholds as checker. Failure requires a planned repair.'});
 }
 return {cutaways:data.shots.map((s,i)=>({shot:s.id,removed:cutaways[i]||[],camera_unchanged:!cameraOverrides[i]})),adjustments:changes,effective_scene:{...data,shots:data.shots.map((s,i)=>({...s,camera:cameraOverrides[i]||s.camera,hidden_environment:cutaways[i]||[]}))}};
};

window.sceneEndpointAudit=()=>data.shots.map((s,i)=>({shot:s.id,start:window.frame(i,0,false),end:window.frame(i,1,false)}));

// Bounding-box projections for review crops, not an occlusion or silhouette test.
window.reviewSubjects=()=>{
 const w=renderer.domElement.width,h=renderer.domElement.height;
 return [...data.shots[active].focus,...(data.shots[active].context||[])].map(id=>{
  const mesh=meshes[id];if(!mesh?.visible)return {id,visible:false};
  const box=new THREE.Box3().setFromObject(mesh),pts=[];
  for(const x of [box.min.x,box.max.x])for(const y of [box.min.y,box.max.y])for(const z of [box.min.z,box.max.z])pts.push(new THREE.Vector3(x,y,z).project(camera));
  const xs=pts.map(p=>(p.x+1)*w/2),ys=pts.map(p=>(1-p.y)*h/2);
  return {id,kind:defs[id].kind,visible:true,bbox:[Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)],clip_depth_ok:pts.every(p=>p.z>=-1&&p.z<=1),...inspectSubject(id)};
 });
};

window.setAudit=()=>data.sets.map(st=>({set:st.id,description:st.environment?.description||'',parts:st.environment?.parts?.length||0,modules:st.environment?.modules?.map(m=>m.kind)||[]}));

window.stateSnapshot=()=>({camera:camera.position.toArray(),lookDirection:camera.getWorldDirection(new THREE.Vector3()).toArray(),activeSet:data.shots[active].set,visible:Object.fromEntries(Object.entries(meshes).filter(([id,m])=>m.visible).map(([id,m])=>[id,m.matrixWorld.toArray()]))});
