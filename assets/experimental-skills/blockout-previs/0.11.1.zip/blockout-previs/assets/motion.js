// Pure transforms shared by browser rendering and the audit. Python parity: scripts/motion.py.
export const mix=(a,b,u)=>a.map((x,i)=>x+(b[i]-x)*u);
const plus=(a,b)=>a.map((x,i)=>x+b[i]);
export function rotate(p,yaw){const a=yaw*Math.PI/180,c=Math.cos(a),s=Math.sin(a);return [p[0]*c+p[2]*s,p[1],-p[0]*s+p[2]*c]}
export function yawAt(a,u){return (a.yaw||0)+((((a.end_yaw??a.yaw??0)-(a.yaw||0)+180)%360+360)%360-180)*u}
export function localAnchor(entity,actor,anchor,u,poses){
 if(anchor==='root')return [0,0,0];const key={left_hand:'lwrist',right_hand:'rwrist',head:'head',chest:'neck'}[anchor];
 if(entity.detail==='articulated')return mix(poses[actor.pose||'stand'][key],poses[actor.pose_to||actor.pose||'stand'][key],u).map(v=>v*entity.size[1]);
 const h=entity.size[1];return {left_hand:[-.18*h,.65*h,.15*h],right_hand:[.18*h,.65*h,.15*h],head:[0,.9*h,0],chest:[0,.65*h,0]}[anchor];
}
export function actorStates(shot,entities,u,poses){
 const actors=Object.fromEntries(shot.actors.map(a=>[a.id,a])),cache={},visiting=new Set();
 function resolve(k){
  if(cache[k])return cache[k];if(visiting.has(k))throw Error('Cyclic attachment: '+k);if(!actors[k])throw Error('Attachment/camera actor absent: '+k);
  visiting.add(k);const a=actors[k],state={position:mix(a.from,a.to,u),yaw:yawAt(a,u)},b=a.attachment;
  if(b){const parent=resolve(b.parent),local=(b.space||'world')==='local';let offset=b.offset;
   if(local)offset=rotate(plus(localAnchor(entities[b.parent],actors[b.parent],b.anchor||'root',u,poses),offset),parent.yaw);
   const target=plus(parent.position,offset),until=b.pickup_until??1,weight=until>0?Math.min(1,u/until):1;
   state.position=mix(a.from,target,weight);if(local)state.yaw=parent.yaw+(b.yaw_offset||0);
  }
  cache[k]=state;visiting.delete(k);return state;
 }
 for(const k in actors)resolve(k);return cache;
}
export function cameraState(shot,entities,u,poses,states){
 const c=shot.camera,rig=c.rig;states=states||actorStates(shot,entities,u,poses);
 if(rig){const s=states[rig.subject],pos=plus(s.position,rotate(rig.offset,s.yaw));let look;
  if(rig.target)look=plus(states[rig.target].position,[0,entities[rig.target].size[1]*.65,0]);
  else look=plus(s.position,rotate(rig.look_offset,s.yaw));return {pos,look};
 }
 let pos=mix(c.from,c.to,u),look=mix(c.look,c.look_to||c.look,u);
 if(c.type==='orbit'){const a=c.from.map((x,i)=>x-c.look[i]),b=c.to.map((x,i)=>x-(c.look_to||c.look)[i]);let theta=Math.atan2(a[0],a[2]),delta=Math.atan2(b[0],b[2])-theta;
  while(delta>Math.PI)delta-=2*Math.PI;while(delta< -Math.PI)delta+=2*Math.PI;
  const r=Math.hypot(a[0],a[2])*(1-u)+Math.hypot(b[0],b[2])*u;pos=[look[0]+r*Math.sin(theta+u*delta),pos[1],look[2]+r*Math.cos(theta+u*delta)];
 }return {pos,look};
}
