"""Reusable parametric set components. No story/category/case-name dispatch."""
import math
KINDS=['box','column','cylinder','sphere','cone','wall','facade','window_wall','doorframe','stairs','rail','bench','table','chair','tree','lamp','shelf','canopy','road','fountain','vehicle','train','cart','console','cup','bag','quadruped']
def component(kind,size,options=None):
 o=options or {};w,h,d=size;parts=[]
 if kind=='column':kind='cylinder'
 def add(shape,at,scale,color='#c8c9c7',yaw=0):parts.append({'kind':shape,'at':at,'size':scale,'color':color,'yaw':yaw})
 def box(x,y,z,a,b,c,color='#c8c9c7'):add('box',[x,y,z],[a,b,c],color)
 shade=o.get('color','#c8c9c7');dark='#72797c';light='#dedfda'
 if kind in ['box','wall','sphere','cylinder','cone']:add('box' if kind=='wall' else kind,[0,0,0],[w,h,d],shade)
 elif kind=='facade':
  box(0,0,0,w,h,d,shade);cols=min(12,max(2,round(w/2.1)));rows=min(10,max(1,round(h/2.8)))
  for side in [-1,1]:
   for j in range(rows):
    for i in range(cols):
     x=-w/2+(i+.5)*w/cols;y=.45+j*h/rows
     box(x,y,side*(d/2+.025),w/cols*.43,h/rows*.52,.06,dark)
     box(x,y-.10,side*(d/2+.09),w/cols*.58,.10,.18,light)
  box(0,h-.22,0,w+.25,.22,d+.25,light);box(0,0,d/2+.07,w,.20,.18,dark)
 elif kind=='window_wall':
  cols=min(16,max(2,round(w/1.8)));bar=.10
  box(0,0,0,w,h*.18,d,shade)
  for i in range(cols+1):box(-w/2+i*w/cols,0,0,bar,h,d,shade)
  for y in [h*.18,h*.6,h-.1]:box(0,y,0,w,bar,d,shade)
 elif kind=='doorframe':
  t=min(w*.15,.22);box(-w/2+t/2,0,0,t,h,d,shade);box(w/2-t/2,0,0,t,h,d,shade);box(0,h-t,0,w,t,d,shade)
 elif kind=='stairs':
  n=min(20,max(2,int(o.get('steps',8))))
  for i in range(n):box(0,0,-d/2+(i+.5)*d/n,w,h*(i+1)/n,d/n,shade)
 elif kind=='rail':
  n=min(30,max(2,round(w/1.2)))
  for i in range(n+1):box(-w/2+w*i/n,0,0,.07,h,.07,shade)
  box(0,h-.07,0,w,.07,.10,dark);box(0,h*.5,0,w,.055,.055,shade)
 elif kind in ['table','bench','chair']:
  seat=h if kind=='table' else h*.45;thick=min(.12,h*.12)
  box(0,seat-thick,0,w,thick,d,shade)
  for x in [-w*.40,w*.40]:
   for z in [-d*.36,d*.36]:box(x,0,z,.09,seat-thick,.09,dark)
  if kind!='table':
   box(0,seat,-d*.40,w,h-seat,.10,shade)
   if kind=='bench':
    for x in [-w*.46,w*.46]:box(x,seat,.0,.07,h*.2,d*.9,dark)
 elif kind=='tree':
  add('cylinder',[0,0,0],[w*.13,h*.63,d*.13],dark);add('sphere',[0,h*.42,0],[w,h*.58,d],shade)
 elif kind=='lamp':
  add('cylinder',[0,0,0],[w*.13,h*.9,w*.13],dark);add('cone',[0,h*.86,0],[w,h*.14,d],light)
 elif kind=='shelf':
  for x in [-w/2+.06,w/2-.06]:box(x,0,0,.12,h,d,shade)
  levels=min(8,max(2,round(h/.8)))
  for j in range(levels):
   y=j*h/levels;box(0,y,0,w,.09,d,shade)
   if o.get('contents',True):
    for i in range(3):box(-w*.33+i*w*.33,y+.09,0,w*.25,h/levels*.55,d*.70,'#acb0ad')
 elif kind=='canopy':
  box(0,h-.18,0,w,.18,d,shade)
  for x in [-w*.44,w*.44]:
   for z in [-d*.40,d*.40]:box(x,0,z,.18,h,.18,dark)
 elif kind=='road':
  box(0,0,0,w,max(.03,h),d,'#888e90')
  n=min(24,max(2,round(d/3)))
  for i in range(n):box(0,h+.005,-d/2+(i+.5)*d/n,.12,.012,d/n*.42,'#d5d6ce')
  for x in [-w/2,w/2]:box(x,0,0,.35,h+.12,d,light)
 elif kind=='fountain':
  add('cylinder',[0,0,0],[w,h*.28,d],shade);add('cylinder',[0,h*.28,0],[w*.80,.04,d*.80],'#969fa0');add('cylinder',[0,h*.28,0],[w*.12,h*.72,d*.12],light)
 elif kind in ['vehicle','train']:
  box(0,h*.16,0,w,h*.84,d,shade)
  # Length along X. Windows and door rectangles distinguish vehicle from anonymous box.
  n=min(16,max(3,round(w/1.8)))
  for side in [-1,1]:
   for i in range(n):box(-w/2+(i+.5)*w/n,h*.53,side*(d/2+.01),w/n*.62,h*.30,.035,dark)
   box(w*.2,h*.18,side*(d/2+.035),min(1,w*.13),h*.71,.025,'#959c9d')
  for x in [-w*.34,w*.34]:
   for z in [-d*.4,d*.4]:add('sphere',[x,0,z],[h*.3,h*.3,h*.3],dark)
 elif kind=='cart':
  box(0,h*.3,0,w,h*.55,d,shade);box(0,h*.85,0,w*1.05,h*.15,d*1.05,light)
  for x in [-w*.34,w*.34]:
   for z in [-d*.34,d*.34]:add('sphere',[x,0,z],[h*.32,h*.32,h*.32],dark)
 elif kind=='console':
  box(0,0,0,w,h*.65,d,shade);box(0,h*.65,-d*.25,w,h*.35,d*.45,dark)
 elif kind=='cup':
  add('cylinder',[0,0,0],[w*.8,h,d*.8],light);add('cylinder',[0,h-.018,0],[w*.64,.02,d*.64],dark);box(w*.43,h*.24,0,w*.16,h*.5,d*.15,shade)
 elif kind=='quadruped':
  add('sphere',[0,h*.32,0],[w*.85,h*.45,d*.75],shade)
  add('sphere',[0,h*.58,d*.31],[w*.58,h*.38,d*.30],shade)
  add('box',[0,h*.65,d*.47],[w*.30,h*.14,d*.16],dark)
  for x in [-w*.3,w*.3]:
   for z in [-d*.23,d*.23]:add('cylinder',[x,0,z],[w*.16,h*.45,w*.16],shade)
  for x in [-w*.19,w*.19]:add('cone',[x,h*.90,d*.30],[w*.20,h*.14,d*.12],shade)
 elif kind=='bag':
  box(0,0,0,w,h*.84,d,shade);box(0,h*.84,0,w*.5,h*.16,d*.13,dark)
 else:raise ValueError('Unknown component '+kind)
 return parts

def build_environment(env):
 parts=[]
 for j,m in enumerate(env.get('modules',[])):
  kind=m['kind'];size=m['size'];at=m.get('at',[0,0,0]);yaw=m.get('yaw',0);copies=m.get('repeat',{'count':1,'step':[0,0,0]});count=copies.get('count',1);step=copies.get('step',[0,0,0])
  if kind not in KINDS:raise ValueError(f'modules[{j}].kind={kind!r} unsupported; choose from {KINDS}')
  if not isinstance(count,int) or not 1<=count<=24:raise ValueError('repeat.count must be 1..24')
  if len(size)!=3 or any(not isinstance(v,(float,int)) or not math.isfinite(v) or not .01<=v<=100 for v in size):raise ValueError(f'modules[{j}].size={size!r}: need 3 finite dimensions in [0.01,100] meters')
  if len(at)!=3 or len(step)!=3 or any(not isinstance(v,(float,int)) or not math.isfinite(v) or abs(v)>150 for v in [*at,*step]):raise ValueError(f'modules[{j}] at={at!r}, repeat.step={step!r}: need 3 finite coordinates within ±150m')
  if not isinstance(yaw,(int,float)) or not math.isfinite(yaw):raise ValueError(f'modules[{j}].yaw={yaw!r}: need a finite angle in degrees')
  yaw=(yaw+180)%360-180
  for k in range(count):
   a=math.radians(yaw)
   for p in component(kind,size,m):
    x,y,z=p['at'];q={**p,'id':f'env_{j}_{k}','removable':bool(m.get('removable',kind in ['wall','window_wall','facade','tree','lamp'])),'at':[at[0]+step[0]*k+x*math.cos(a)+z*math.sin(a),at[1]+step[1]*k+y,at[2]+step[2]*k-x*math.sin(a)+z*math.cos(a)],'yaw':yaw+p['yaw']};parts.append(q)
  if len(parts)>1800:raise ValueError('Environment exceeds 1800 parts; simplify repeated decoration')
 return parts
