#!/usr/bin/env python3
"""Portable structural, story-contract and geometry checks. No model/provider imports."""
import argparse,json,math,subprocess,sys,time
from pathlib import Path
import jsonschema
from motion import actor_states,camera_state,local_anchor,rotate,plus
from PIL import Image,ImageDraw,ImageStat
ROOT=Path(__file__).resolve().parents[1]
PROFILE=json.loads((ROOT/'assets/render-profile.json').read_text())
# Inclusive physical distance bounds tolerate floating-point arithmetic (one micrometer).
DISTANCE_EPS=1e-6

def visible_entities(plan,shot):
 out={}
 for st in plan['sets']:
  if st['id']==shot['set']:
   for o in st['objects']:out[o['id']]={'id':o['id'],'from':o['position'],'to':o['position'],'yaw':o.get('yaw',0)}
 out.update({a['id']:a for a in shot['actors']})
 return out

def validate(plan,brief=None,geometry=None):
 errors=[];warnings=[]
 def err(code,msg): errors.append({'code':code,'message':msg})
 def warn(code,msg): warnings.append({'code':code,'message':msg})
 def nonfinite(x):
  if isinstance(x,float):return not math.isfinite(x)
  if isinstance(x,dict):return any(nonfinite(v) for v in x.values())
  if isinstance(x,list):return any(nonfinite(v) for v in x)
  return False
 if nonfinite(plan) or (brief and nonfinite(brief)):return {'ok':False,'errors':[{'code':'nonfinite','message':'JSON numbers must be finite'}],'warnings':[]}
 schema=json.loads((ROOT/'references/scene.schema.json').read_text())
 for e in jsonschema.Draft202012Validator(schema).iter_errors(plan):err('schema','/'.join(map(str,e.path))+': '+e.message)
 if errors:return {'ok':False,'errors':errors[:30],'warnings':[]}
 entities={x['id']:x for x in plan['entities']};sets={x['id']:x for x in plan['sets']}
 if len(entities)!=len(plan['entities']):err('duplicate_entity','Entity IDs must be unique')
 if len(sets)!=len(plan['sets']):err('duplicate_set','Set IDs must be unique')
 shotids=[s['id'] for s in plan['shots']]
 if len(set(shotids))!=len(shotids):err('duplicate_shot','Shot IDs must be unique')
 total=sum(s['duration'] for s in plan['shots'])
 if abs(total-plan['duration'])>.001:err('duration',f'Shots total {total}, declared {plan["duration"]}')
 if brief and len({s['set'] for s in plan['shots']})<brief.get('min_sets',1):err('scene_count',f'Need at least {brief["min_sets"]} distinct sets actually used by shots')
 if brief and brief.get('shot_count') and len(plan['shots'])!=brief['shot_count']:err('shot_count',f'Expected {brief["shot_count"]} shots')
 if brief and abs(total-brief.get('duration',300))>.001:err('target_duration',f'Expected {brief.get("duration",300)} seconds, got {total}')
 events={};elapsed=0;previous=None;previous_states={}
 for st in plan['sets']:
  for o in st['objects']:
   if o['id'] not in entities:err('unknown_entity',f'Set {st["id"]} references undefined id {o["id"]}. Add an entity with EXACT id {o["id"]}, or remove this nonessential scenery instance. Numbered IDs do NOT inherit a base entity; defining pillar does not define pillar1.')
 for s in plan['shots']:
  sid=s['id']; actors={a['id']:a for a in s['actors']}
  if s['set'] not in sets:err('unknown_set',sid)
  if len(actors)!=len(s['actors']):err('duplicate_actor',sid)
  actors=visible_entities(plan,s)
  if not actors:err('empty_scene',f'{sid}: no visible entities; define environment for an establishing shot')
  try:
   evaluated={u:actor_states(s,entities,u) for u in [0,.5,1]}
   rig=s['camera'].get('rig')
   if rig and (rig['subject'] not in actors or rig.get('target',rig['subject']) not in actors):raise ValueError('Camera rig subject/target absent')
   if rig and s['camera'].get('auto_frame'):err('camera_rig','Subject-mounted cameras cannot use auto_frame')
  except (ValueError,KeyError) as exc:
   err('motion_reference',f'{sid}: {exc}');continue
  for a in s['actors']:
   if a.get('attachment'):
    if max(math.dist(a['from'],evaluated[0][a['id']]['position']),math.dist(a['to'],evaluated[1][a['id']]['position']))>.001:err('attachment_endpoint',f'{sid}/{a["id"]}: stored endpoints disagree with live binding')
   if a['id'] not in entities:err('unknown_actor',f'{sid}: {a["id"]}')
   speed=math.dist(a['from'],a['to'])/s['duration']
   if speed>12:warn('fast_proxy',f'{sid}/{a["id"]}: {speed:.1f} m/s')
   if min(a['from'][1],a['to'][1])<-.05:err('below_floor',f'{sid}/{a["id"]}')
   if previous and s['continuity']=='continuous' and previous['set']==s['set'] and a['id'] in previous_states:
    if math.dist(previous_states[a['id']],a['from'])>.2:err('teleport',f'{sid}/{a["id"]}: continuous cut changes position')
  for id in s['focus']:
   if id not in actors:err('focus_absent',f'{sid}: focus {id} must be an actor or a visible set object')
  # Diagnose deep enclosure explicitly: camera changes cannot reveal an object inside a solid box.
  for fid in s['focus']:
   if fid not in actors or fid not in entities:continue
   # A compound asset can have empty space at its bounding-box center.
   # Its real components are checked by the render-time ray audit instead.
   if entities[fid].get('parts'):continue
   subject=actors[fid];fh=entities[fid]['size'][1]
   for bid,block in actors.items():
    if bid==fid or bid not in entities or (entities[bid]['kind']!='box' or entities[bid].get('parts')):continue
    w,h,d=entities[bid]['size'];inside=0
    for sample in range(11):
     u=sample/10;actual=actor_states(s,entities,u);p=actual.get(fid,{'position':subject['from']})['position'];q=actual.get(bid,{'position':block['from']})['position'];dx,dz=p[0]-q[0],p[2]-q[2];yaw=math.radians(block.get('yaw',0)+(block.get('end_yaw',block.get('yaw',0))-block.get('yaw',0))*u);lx=dx*math.cos(yaw)-dz*math.sin(yaw);lz=dx*math.sin(yaw)+dz*math.cos(yaw)
     if abs(lx)<w/2-.03 and abs(lz)<d/2-.03 and q[1]+.03<p[1]+fh*.55<q[1]+h-.03:inside+=1
    if inside>=6:err('inside_solid',f'{sid}/{fid}: center is inside solid box {bid} for {inside}/11 samples. Box size {entities[bid]["size"]}, from {block["from"]}, to {block["to"]}; subject from {subject["from"]}, to {subject["to"]}. Move subject beside/outside it or change the staging; camera movement cannot fix enclosure.')
  c=s['camera']
  for u in [i/10 for i in range(11)]:
   sample=camera_state(s,entities,u);p,q=sample['pos'],sample['look']
   if math.dist(p,q)<.2:err('camera_degenerate',sid);break
  if min(c['from'][1],c['to'][1])<.1:err('camera_below_floor',sid)
  if c['type']=='static' and math.dist(c['from'],c['to'])>.05:warn('camera_type',f'{sid}: static camera moves')
  for ev in s['events']:
   if ev['id'] in events:err('duplicate_event',ev['id'])
   events[ev['id']]={'time':elapsed+ev['at']*s['duration'],'shot':s,'u':ev['at']}
  previous=s;previous_states={a['id']:a['to'] for a in s['actors']};elapsed+=s['duration']
 if brief:
  if brief.get('motion_policy')=='blocking_first' and plan.get('motion_policy')!='blocking_first':err('motion_policy','Scene must preserve frozen blocking_first policy')
  required={e['id']:e for e in brief.get('events',[])}
  for shot in plan['shots']:
   expected=[]
   for ev in shot['events']:
    req=required.get(ev['id'],{})
    if req.get('downstream_action'):
     if brief.get('motion_policy')!='blocking_first' or not isinstance(req.get('proxy_action'),str) or not req['proxy_action'].strip():err('action_contract','Deferred actions require an explicit proxy_action under frozen blocking_first policy')
     expected.append({'event_id':ev['id'],'description':req['downstream_action']})
   if shot.get('deferred_actions',[])!=expected:err('deferred_action_contract',shot['id']+': delegated actions must match the frozen brief, not model-selected omissions')
   if any(not isinstance(x['description'],str) or x['description'] not in shot.get('video_prompt','') for x in expected):err('downstream_prompt',shot['id']+': missing delegated action in downstream video prompt')
  last=-1
  for req in brief.get('events',[]):
   ev=events.get(req['id'])
   if not ev:err('missing_event',req['id']);continue
   if ev['time']<=last:err('event_order',req['id'])
   last=ev['time'];s=ev['shot'];actors=visible_entities(plan,s);u=ev['u']
   for id in req.get('subjects',[]):
    if id not in actors:err('event_actor_absent',f'{req["id"]}: {id}')
    elif id not in s['focus']+s.get('context',[]):err('event_focus_absent',f'{req["id"]}: {id} must be a focus subject')
   sampled=actor_states(s,entities,u)
   positions={k:sampled[k]['position'] if k in sampled else list(v['from']) for k,v in actors.items()}
   for p in req.get('checks',[]):
    a,b=p.get('a'),p.get('b');typ=p['type']
    if typ not in ['distance_max','distance_min','move_min','camera_move_min','axis_less','pose_is','human','face_toward','leads','held_by','contact_max']:err('unknown_event_check',f'{req["id"]}: unsupported check {typ}');continue
    if a and a not in positions:err('check_subject_absent',f'{req["id"]}: check subject {a} absent');continue
    if b and b not in positions:err('check_subject_absent',f'{req["id"]}: check subject {b} absent');continue
    if typ=='held_by':
     binding=actors[a].get('attachment',{})
     if binding.get('parent')!=b or u+DISTANCE_EPS<binding.get('pickup_until',1):err('held_by',f'{req["id"]}: {a} must be acquired by {b} by this event, then stay bound until release')
     if p.get('anchor') and binding.get('anchor','root')!=p['anchor']:err('held_anchor',f'{req["id"]}: required carry anchor {p["anchor"]}')
    if typ=='contact_max':
     def contact(k,anchor):
      actor=actors[k];state=sampled.get(k,{'position':actor['from'],'yaw':actor.get('yaw',0)})
      if anchor=='center':return plus(state['position'],[0,entities[k]['size'][1]/2,0])
      return plus(state['position'],rotate(local_anchor(entities[k],actor,anchor,u),state['yaw']))
     try:
      distance=math.dist(contact(a,p.get('anchor','root')),contact(b,p.get('target_anchor','root')))
      if distance>p['value']+DISTANCE_EPS:err('contact_max',f'{req["id"]}: contact distance {distance:.3f}m exceeds {p["value"]}m')
     except (KeyError,ValueError) as exc:err('contact_anchor',str(exc))
    if typ=='leads':
     travel=[v-w for w,v in zip(actors[a]['from'],actors[a]['to'])];length=math.sqrt(sum(v*v for v in travel));minimum=p.get('value',.5)
     if length<1e-6:err('event_lead',f'{req["id"]}: {a} must move to define its leading direction; use a static axis predicate for a stationary arrangement')
     else:
      gap=sum((v-w)*direction/length for v,w,direction in zip(positions[a],positions[b],travel))
      if gap<minimum-DISTANCE_EPS:err('event_lead',f'{req["id"]} in {s["id"]} at={u}: {a} must lead {b} by >= {minimum}m along {a}\'s actual travel direction; projected lead={gap:.3f}m. Side-by-side synchronous motion does not show leading/following. Preserve the required route and original camera.')
    if typ=='face_toward':
     report=err if p.get('severity')=='error' else warn
     actor=actors[a];yaw=actor.get('yaw',0);delta=(actor.get('end_yaw',yaw)-yaw+180)%360-180;yaw=math.radians(yaw+delta*u)
     dx=positions[b][0]-positions[a][0];dz=positions[b][2]-positions[a][2];norm=math.hypot(dx,dz)
     if norm<.001:report('facing_target_overlap',f'{req["id"]}: facing target overlaps {a}')
     elif (math.sin(yaw)*dx+math.cos(yaw)*dz)/norm<math.cos(math.radians(p.get('value',45))):report('facing_requirement',f'{req["id"]}: suggested {a} facing {b} within {p.get("value",45)} degrees')
     if not (entities[a].get('face_marker') or entities[a].get('detail')=='oriented'):report('facing_marker_omitted',f'{req["id"]}/{a}: yaw is metadata; optional face marker is omitted')
    if typ=='human' and entities[a]['kind']!='person':err('human_required',f'{req["id"]}: {a} must be kind person')
    if typ=='pose_is':
     report=err if p.get('severity')=='error' else warn
     if entities[a].get('detail','simple')!='articulated' and p['value']!='stand':report('pose_detail_omitted',f'{req["id"]}/{a}: simple proxy omits optional joint pose {p["value"]}; do not claim the joints were rendered')
     elif (actors[a].get('pose_to',actors[a].get('pose','stand')) if u>=.999 else actors[a].get('pose','stand'))!=p['value']:report('pose_requirement',f'{req["id"]}/{a}: optional suggested pose {p["value"]} is omitted')
    if typ=='distance_max' and math.dist(positions[a],positions[b])>p['value']+DISTANCE_EPS:err('event_geometry',f'{req["id"]} in {s["id"]} at={u}: actual distance {a}-{b}={math.dist(positions[a],positions[b]):.6f}m must <= {p["value"]}m; positions {a}={positions[a]}, {b}={positions[b]}. Check uses this event time, not another midpoint.')
    if typ=='distance_min' and math.dist(positions[a],positions[b])<p['value']-DISTANCE_EPS:err('event_geometry',f'{req["id"]} in {s["id"]} at={u}: actual distance {a}-{b}={math.dist(positions[a],positions[b]):.6f}m must >= {p["value"]}m; positions {a}={positions[a]}, {b}={positions[b]}.')
    if typ=='move_min' and math.dist(actors[a]['from'],actors[a]['to'])<p['value']-DISTANCE_EPS:err('event_motion',f'{req["id"]} in {s["id"]}: actual {a} travel={math.dist(actors[a]["from"],actors[a]["to"]):.6f}m must >= {p["value"]}m in THIS shot; from={actors[a]["from"]}, to={actors[a]["to"]}.')
    if typ=='camera_move_min' and math.dist(s['camera']['from'],s['camera']['to'])<p['value']-DISTANCE_EPS:err('event_camera',f'{req["id"]} in {s["id"]}: actual camera travel={math.dist(s["camera"]["from"],s["camera"]["to"]):.6f}m must >= {p["value"]}m.')
    if typ=='axis_less' and positions[a][p.get('axis',0)]>=positions[b][p.get('axis',0)]:err('event_direction',f'{req["id"]}: {a} must be on negative side of {b}')
 if brief:
  for k in brief.get('human_entities',[]):
   if k not in entities:err('human_required',f'{k} must have a stable proxy entity')
   elif entities[k]['kind']!='person':warn('simple_human_shape',f'{k} is a declared human represented by {entities[k]["kind"]}; optional limbs/face are not required')
 if brief:
  shot_indices={s['id']:i for i,s in enumerate(plan['shots'])}
  for rule in brief.get('state_constraints',[]):
   if rule.get('type')!='remain_after':err('unknown_state_constraint',str(rule));continue
   ev=events.get(rule.get('event'));entity=rule.get('entity');until=events.get(rule.get('until_event')) if rule.get('until_event') else None
   if not ev or (rule.get('until_event') and not until):err('state_event_absent',str(rule));continue
   anchor_shot=ev['shot'];anchor_actor=visible_entities(plan,anchor_shot).get(entity)
   if not anchor_actor:err('state_anchor_absent',str(rule));continue
   position=[a+(b-a)*ev['u'] for a,b in zip(anchor_actor['from'],anchor_actor['to'])]
   stop=shot_indices[until['shot']['id']] if until else len(plan['shots'])
   for shot in plan['shots'][shot_indices[anchor_shot['id']]+1:stop]:
    actor=visible_entities(plan,shot).get(entity)
    if actor:
     if shot['set']!=anchor_shot['set'] or max(math.dist(actor['from'],position),math.dist(actor['to'],position))>.05:err('state_retention',f'{entity} must remain in set {anchor_shot["set"]} at {position} after {rule["event"]}; changed in {shot["id"]}')
    elif shot['set']==anchor_shot['set']:err('state_retention',f'{entity} was left in {shot["set"]} but is absent when it is shown again in {shot["id"]}')
 if brief and brief.get('min_camera_types'):
  moving=set()
  for shot in plan['shots']:
   c=shot['camera'];a=[q-p for q,p in zip(c['look'],c['from'])];b=[q-p for q,p in zip(c.get('look_to',c['look']),c['to'])];na=max(.001,math.sqrt(sum(x*x for x in a)));nb=max(.001,math.sqrt(sum(x*x for x in b)))
   if math.dist(c['from'],c['to'])>.05 or math.dist([x/na for x in a],[x/nb for x in b])>.005:moving.add(c['type'])
  if len(moving)<brief['min_camera_types']:err('camera_variety',f'Need {brief["min_camera_types"]} actual moving camera types, got {sorted(moving)}')
 if brief:
  shotmap={s['id']:s for s in plan['shots']}
  for rule in brief.get('camera_constraints',[]):
   shot=shotmap.get(rule['shot_id'])
   if not shot:err('camera_requirement',f'Required camera shot {rule["shot_id"]} is absent');continue
   c=shot['camera'];sid=shot['id']
   if rule.get('subject') and c.get('rig',{}).get('subject')!=rule['subject']:err('camera_requirement',f'{sid}: must be mounted to {rule["subject"]}')
   for field in ['type','framing']:
    if field in rule and c.get(field)!=rule[field]:err('camera_requirement',f'{sid}: required {field}={rule[field]}, got {c.get(field)}')
   if rule.get('lock_camera') and c.get('auto_frame'):err('camera_requirement',f'{sid}: explicit camera is locked; set auto_frame=false')
   if 'height' in rule and any(not rule['height'][0]-.001<=p[1]<=rule['height'][1]+.001 for p in [c['from'],c['to']]):err('camera_requirement',f'{sid}: camera height must be within {rule["height"]}')
   if rule.get('type')=='static' and (math.dist(c['from'],c['to'])>.001 or math.dist(c['look'],c.get('look_to',c['look']))>.001):err('camera_requirement',f'{sid}: requested static camera must not translate or pan')
  stationary={}
  for s in plan['shots']:
   for actor in s['actors']:
    if actor['id'] not in brief.get('static_entities',[]):continue
    key=(s['set'],actor['id']);anchor=stationary.setdefault(key,actor['from'])
    if max(math.dist(anchor,actor['from']),math.dist(anchor,actor['to']))>.001:err('static_requirement',f'{s["id"]}/{actor["id"]}: original brief requires a stationary proxy in this set')
 if brief and brief.get('visual_standard') in ['situated_previs_v06','instruction_previs_v09']:
  for st in plan['sets']:
   env=st.get('environment',{})
   if not env.get('description') or not env.get('parts'):err('unbuilt_set',f'{st["id"]}: describe and build the requested place; an empty floor has no scene evidence')
  framings={s['camera'].get('framing') for s in plan['shots']}
  if brief.get('min_framings') and len(framings-{None})<brief['min_framings']:err('shot_scale_variety',f'Original brief requires {brief["min_framings"]} planned shot scales')
 if geometry:
  collisions=[{'shot':r['shot'],'u':r['u'],'objects':r.get('camera_collisions')} for r in geometry if r.get('camera_collisions')]
  if collisions:err('camera_collision','Camera/near-plane inside real geometry at samples: '+json.dumps(collisions[:12]))
  for s in plan['shots']:
   rows=[r for r in geometry if r['shot']==s['id']]
   for id in s['focus']+s.get('context',[]):
    points=[p for r in rows for p in r['subjects'] if p['id']==id]
    if points and all(p.get('viewpoint_subject') for p in points):continue
    if not points:err('geometry_missing',f'{s["id"]}/{id}');continue
    framed=sum(bool(p.get('in_frame')) for p in points)/len(points)
    unobscured=sum(bool(p.get('in_frame')) and not p.get('occluded',False) for p in points)/len(points)
    if framed<PROFILE['minimum_framed_times_fraction']:err('out_of_frame',f'{s["id"]}/{id}: representative points in frame {framed:.0%}')
    if unobscured<PROFILE['minimum_visible_times_fraction']:
     blockers={}
     for sample in points:
      for key,count in sample.get('blocking_objects',{}).items():blockers[key]=blockers.get(key,0)+count
     err('occluded',f'{s["id"]}/{id}: visibility audit passed at {unobscured:.0%} of sampled times; blocking ray hits by object: {blockers}')
    elif unobscured<.9:warn('partial_occlusion',f'{s["id"]}/{id}: representative points visible {unobscured:.0%}')
 if geometry and brief and brief.get('visual_standard') in ['situated_previs_v06','instruction_previs_v09']:
  for req in brief.get('events',[]):
   ev=events.get(req['id'])
   if not ev:continue
   rows=[r for r in geometry if r['shot']==ev['shot']['id']];row=min(rows,key=lambda r:abs(r['u']-ev['u'])) if rows else None
   if not row:continue
   for p in row['subjects']:
    if not p.get('viewpoint_subject') and p['id'] in req.get('subjects',[]) and p.get('kind')=='person' and p.get('height_px',0)<PROFILE['event_person_min_height_px']:err('unreadable_event_person',f'{req["id"]}/{p["id"]}: projected height {p.get("height_px",0):.1f}px <{PROFILE["event_person_min_height_px"]}px; choose a readable two-shot or reduce excessive camera distance, not an overhead overview')
 return {'ok':not errors,'status':'FAIL' if errors else ('PASS_WITH_WARNINGS' if warnings else 'PASS'),'errors':errors,'warnings':warnings,'duration':total,'shots':len(plan['shots']),'events_found':len(events),'scope':'Structural checks + explicit event predicates + sampled multi-point focus visibility; not a guarantee of complete story or aesthetic quality.'}

def montage(plan,out):
 out=Path(out);files=[out/'frames'/f'{i+1:03d}_b.jpg' for i in range(len(plan['shots']))]
 w,h=320,210;cols=4;img=Image.new('RGB',(cols*w,math.ceil(len(files)/cols)*h),'#101828');d=ImageDraw.Draw(img)
 for i,p in enumerate(files):
  if not p.exists():continue
  frame=Image.open(p);frame.thumbnail((w,180));x=(i%cols)*w;y=(i//cols)*h;img.paste(frame,(x,y));s=plan['shots'][i]
  d.text((x+8,y+183),f'{s["id"]} | {s["camera"]["type"]} | {s["duration"]}s',fill='white')
 img.save(out/'contact-sheet.jpg',quality=85)
 return str(out/'contact-sheet.jpg')

def event_montage(plan,out):
 out=Path(out);events=[(s,e) for s in plan['shots'] for e in s['events']]
 w,h,cols=400,255,3;img=Image.new('RGB',(w*cols,h*max(1,math.ceil(len(events)/cols))),'#101828');draw=ImageDraw.Draw(img)
 for i,(shot,event) in enumerate(events):
  p=out/'event-frames'/f'{i+1:03d}.jpg'
  if not p.exists():continue
  im=Image.open(p);im.thumbnail((w,225));x=(i%cols)*w;y=(i//cols)*h;img.paste(im,(x,y));draw.text((x+7,y+230),f"{event['id']} | {shot['id']} | at={event['at']}",fill='white')
 img.save(out/'event-sheet.jpg',quality=90)
 contact=Image.open(out/'contact-sheet.jpg');img.thumbnail((contact.width,10000));combined=Image.new('RGB',(contact.width,contact.height+img.height+20),'#101828');combined.paste(contact,(0,0));combined.paste(img,(0,contact.height+20));combined.save(out/'review-sheet.jpg',quality=88)
 return str(out/'review-sheet.jpg')

def verify_video(path,plan,fps,max_seconds=90,width=None,height=None):
 deadline=time.monotonic()+max_seconds
 p=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name,pix_fmt,width,height,nb_frames,r_frame_rate,duration','-of','json',str(path)],capture_output=True,text=True,timeout=max(.1,min(30,deadline-time.monotonic())))
 if p.returncode:return {'ok':False,'error':'ffprobe_failed'}
 streams=json.loads(p.stdout)['streams'];videos=[s for s in streams if s.get('codec_type')=='video'];audio=[s for s in streams if s.get('codec_type')=='audio']
 if len(videos)!=1:return {'ok':False,'error':'expected_one_video_stream'}
 meta=videos[0];expected=sum(round(s['duration']*fps) for s in plan['shots']);num,den=map(int,meta['r_frame_rate'].split('/'))
 decode=subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(path),'-f','null','-'],capture_output=True,text=True,timeout=max(.1,deadline-time.monotonic()))
 checks={'frames':int(meta.get('nb_frames',0))==expected,'duration':abs(float(meta['duration'])-plan['duration'])<=1/fps+.001,'fps':abs(num/den-fps)<1e-6,'codec':meta['codec_name']=='h264','pixel_format':meta.get('pix_fmt')=='yuv420p','no_audio':not audio,'width':width is None or meta['width']==width,'height':height is None or meta['height']==height}
 return {'ok':decode.returncode==0 and all(checks.values()),'checks':checks,'expected_frames':expected,'decode_ok':decode.returncode==0,'metadata':meta}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('scene');ap.add_argument('--brief');ap.add_argument('--out');ap.add_argument('--video');ap.add_argument('--fps',type=int,default=24);a=ap.parse_args()
 plan=json.loads(Path(a.scene).read_text());brief=json.loads(Path(a.brief).read_text()) if a.brief else None
 geometry=json.loads((Path(a.out)/'geometry.json').read_text()) if a.out and (Path(a.out)/'geometry.json').exists() else None
 result=validate(plan,brief,geometry)
 if a.out:
  montage(plan,a.out);Path(a.out,'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 if a.video:
  result['video']=verify_video(a.video,plan,a.fps);result['ok'] &= result['video']['ok']
  if a.out:Path(a.out,'checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['ok'] else 1)
if __name__=='__main__':main()
