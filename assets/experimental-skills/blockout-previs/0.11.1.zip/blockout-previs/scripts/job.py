#!/usr/bin/env python3
"""Budgeted CLI for any model/agent capable of writing JSON and running tools."""
import argparse,hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
from check import validate,montage,event_montage,verify_video
from compile_plan import compile_plan
from review import provenance,snapshot,build as build_review,record as record_review,gate as review_gate
from story_facts import packet as fact_packet,record as record_facts,gate as fact_gate
from edit_scope import is_edit,validate_draft as validate_edit_draft,scope as edit_scope,gate as edit_gate
from reference_video import technical_check,export as export_reference
SKILL=Path(__file__).resolve().parents[1]
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2))
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def export_reserve(brief,profile=None):
 profile=profile or {};scale=profile.get('width',640)*profile.get('height',360)/(640*360)*profile.get('fps',24)/24
 return max(25,30+.3*brief['duration']*scale)
def run(cmd,limit):
 p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=(os.name!='nt'))
 try:
  out,err=p.communicate(timeout=limit)
  if p.returncode:raise RuntimeError(err[-2000:] or out[-2000:])
  return out
 except subprocess.TimeoutExpired:
  if os.name!='nt':os.killpg(p.pid,signal.SIGKILL)
  else:p.kill()
  p.communicate();raise TimeoutError('Tool timed out')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['init','status','check','preview','compile','patch','render','reference','package','review','record-review','facts','record-facts']);ap.add_argument('job');ap.add_argument('--brief');ap.add_argument('--review');ap.add_argument('--patch');ap.add_argument('--draft');ap.add_argument('--budget',type=int,default=600);ap.add_argument('--require-facts',action='store_true');ap.add_argument('--clips',action='store_true');ap.add_argument('--software',action='store_true');ap.add_argument('--width',type=int,default=640);ap.add_argument('--height',type=int,default=360);ap.add_argument('--fps',type=int,default=24);a=ap.parse_args()
 job=Path(a.job).resolve();statefile=job/'job.json'
 if a.command=='init':
  if statefile.exists():raise ValueError('Job already exists; create a different directory for a new film')
  if not a.brief:raise ValueError('--brief is required')
  job.mkdir(parents=True,exist_ok=True);shutil.copyfile(a.brief,job/'brief.json');now=time.time()
  write(statefile,{'started_at':now,'deadline':now+a.budget,'budget_seconds':a.budget,'repairs':0,'max_repairs':2,'budget_policy':'soft_target','require_facts':a.require_facts,'history':[],'skill':provenance(SKILL)});print(json.dumps({'job':str(job),'remaining_seconds':a.budget}));return
 state=read(statefile);remaining=state['deadline']-time.time();brief=read(job/'brief.json');reserve=export_reserve(brief,state.get('preview_profile'))
 if a.command=='status':print(json.dumps({**state,'remaining_seconds':max(0,remaining),'export_reserve_seconds':reserve},indent=2));return
 # Target elapsed time is telemetry, never a quality failure or a tool deadline.
 if state.get('skill')!=provenance(SKILL):raise ValueError('Skill source/version changed during this job; use its original release to continue')
 if is_edit(job) and a.command not in ['compile','status']:
  edit_gate(job)
 if a.command=='reference':
  result=export_reference(job,job/'reference-output',SKILL,a.width,a.height,a.fps,a.software)
  print(json.dumps(result,ensure_ascii=False));return
 scene=job/'scene.json';brief=read(job/'brief.json')
 if a.command=='facts':print(json.dumps(fact_packet(job),ensure_ascii=False));return
 if a.command=='record-facts':
  if not a.review:raise ValueError('--review is required')
  print(json.dumps(record_facts(job,a.review),ensure_ascii=False));return
 if a.command=='record-review':
  if not a.review:raise ValueError('--review is required')
  print(json.dumps(record_review(job,a.review),ensure_ascii=False));return
 if a.command=='review':print(json.dumps(build_review(job),ensure_ascii=False));return
 if a.command=='compile':
  if not a.draft:raise ValueError('--draft is required')
  if state.get('draft_attempts',0):
   if state['repairs']>=state['max_repairs']:raise ValueError('Repair allowance exhausted; preserve the accepted baseline if this is a user edit')

   snapshot(job,state['repairs']);state['repairs']+=1
   if scene.exists():shutil.copyfile(scene,job/f'scene-before-repair-{state["repairs"]}.json')
  state['draft_attempts']=state.get('draft_attempts',0)+1;write(statefile,state)
  draft=read(a.draft)
  if is_edit(job):validate_edit_draft(job,draft)
  plan=compile_plan(draft,brief);write(job/'draft.json',draft);write(scene,plan)
  if technical_check(plan)['ok']:
   shutil.copyfile(scene,job/'last-renderable-scene.json');shutil.copyfile(job/'draft.json',job/'last-renderable-draft.json')
  if is_edit(job):edit_scope(job)
  checked=validate(plan,brief);write(job/'checks.json',checked);print(json.dumps(checked,ensure_ascii=False));sys.exit(0 if checked['ok'] else 1)
 if a.command=='patch':
  if is_edit(job):raise ValueError('Use edit_scope.py apply for a scoped user edit; direct scene patches bypass its compact-draft boundary')
  if state['repairs']>=state['max_repairs']:raise ValueError('Two repair rounds used; stop and report failure or deliver the last accepted version')

  if not a.patch:raise ValueError('--patch is required')
  snapshot(job,state['repairs']);state['repairs']+=1;write(statefile,state);plan=read(scene);patch=read(a.patch)
  shutil.copyfile(scene,job/f'scene-before-repair-{state["repairs"]}.json')
  for k in ('entities','sets'):
   if k in patch:plan[k]=patch[k]
  for s in patch.get('shots',[]):
   hits=[i for i,x in enumerate(plan['shots']) if x['id']==s['id']]
   if not hits:raise ValueError('Unknown shot: '+s['id'])
   plan['shots'][hits[0]]=s
  write(scene,plan);print(json.dumps({'patched':True,'repairs':state['repairs']}));return
 plan=read(scene);checked=validate(plan,brief)
 if not checked['ok'] and not (a.command=='preview' and technical_check(plan)['ok']):write(job/'checks.json',checked);print(json.dumps(checked,ensure_ascii=False));sys.exit(1)
 if a.command=='check':write(job/'checks.json',checked);print(json.dumps(checked,ensure_ascii=False));return
 if a.command in ['preview','render']:
  if a.width<64 or a.height<64 or a.width>1920 or a.height>1920 or a.width%2 or a.height%2 or a.fps<1 or a.fps>60:raise ValueError('Use even dimensions 64..1920 and fps 1..60')
  profile={'width':a.width,'height':a.height,'fps':a.fps,'software':a.software}
  if is_edit(job) and profile!=state['base_profile']:raise ValueError('User micro-edit preserves the baseline preview profile; resolution upgrades are not part of local motion/staging edits')
  if a.command=='render':
   fact_gate(job,state.get('require_facts',False))
   visual=review_gate(job)
   if profile!=state.get('preview_profile'):raise ValueError('Render profile differs from reviewed preview; preview and review this profile first')
  mode='video' if a.command=='render' else 'preview';out=job/'output';limit=600 if mode=='video' else 180
  if limit<5:raise TimeoutError('Insufficient tool budget')
  result=run(['node',str(SKILL/'scripts/render.mjs'),'--scene',str(scene),'--out',str(out),'--mode',mode,'--timeout',str(limit),'--width',str(a.width),'--height',str(a.height),'--fps',str(a.fps),'--software',str(a.software).lower()],limit+2)
  checked=validate(plan,brief,read(out/'geometry.json'));montage(plan,out);event_montage(plan,out);checked['scene_sha256']=digest(scene)
  if mode=='preview':
   state['preview_profile']=profile;write(statefile,state);checked['review_pack']=build_review(job)
  if mode=='video':
   checked['factual_review']=fact_gate(job,state.get('require_facts',False))
   checked['visual_review']=review_gate(job)
   checked['video']=verify_video(out/'preview.mp4',plan,a.fps,max_seconds=120,width=a.width,height=a.height);checked['ok'] &= checked['video']['ok']
   checked['elapsed_seconds']=time.time()-state['started_at']
   checked['within_target']=checked['elapsed_seconds']<=state['budget_seconds'];checked['over_target_seconds']=max(0,checked['elapsed_seconds']-state['budget_seconds'])
   # Automated checks alone never certify full narrative quality.
   checked['visual_review_required']=not checked['visual_review']['visual_review_complete']
   checked['status']='PASS_WITH_WARNINGS' if checked['ok'] else 'FAIL'
   checked['render_success']=bool(checked['video']['ok']);checked['quality_pass']=bool(checked['ok'] and checked['visual_review']['visual_review_complete'] and state.get('base_quality_pass',True))
   if checked['render_success'] and not checked['quality_pass']:checked['status']='RENDERED_FOR_ADJUSTMENT'
   if checked['quality_pass']:shutil.copyfile(scene,job/'last-accepted-scene.json')
  write(out/'checks.json',checked);state['history'].append({'command':a.command,'seconds_remaining':max(0,state['deadline']-time.time()),'ok':checked['ok']});write(statefile,state)
  print(json.dumps(checked,ensure_ascii=False));sys.exit(0 if checked['ok'] else 1)
 if a.command=='package':
  fact_gate(job,state.get('require_facts',False))
  out=job/'output';checked=read(out/'checks.json');visual=review_gate(job)
  if not checked.get('ok') or checked.get('scene_sha256')!=digest(scene) or not checked.get('video',{}).get('ok'):raise ValueError('A fully validated current video is required; package refuses stale/failed renders')
  plan=read(out/'effective-scene.json');t=0;shots=[];clips=out/'clips'
  if a.clips:clips.mkdir(exist_ok=True)
  for s in plan['shots']:
   item={**s,'start':t,'end':t+s['duration']};shots.append(item)
   if a.clips:
    limit=60
    if limit<=0:raise TimeoutError('Clip packaging deadline exceeded')
    run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(out/'preview.mp4'),'-t',str(s['duration']),'-c:v','libx264','-preset','ultrafast','-crf','22','-an',str(clips/(s['id']+'.mp4'))],limit)
   t+=s['duration']
  manifest={'skill':state['skill'],'profile':state.get('preview_profile'),'scene_sha256':digest(scene),'duration':t,'shots':shots}
  if is_edit(job):manifest['user_edit']={**edit_gate(job),'base_video':state['base_video'],'base_video_sha256':state['base_video_sha256'],'user_request':read(job/'edit-request.json')['user_request']}
  write(out/'shot-manifest.json',manifest);print(json.dumps({'status':checked['status'],'video':str(out/'preview.mp4'),'manifest':str(out/'shot-manifest.json'),'visual_review_required':not visual['visual_review_complete']}));return
if __name__=='__main__':
 try:main()
 except Exception as e:print(json.dumps({'ok':False,'error':type(e).__name__,'message':str(e)},ensure_ascii=False));sys.exit(1)
