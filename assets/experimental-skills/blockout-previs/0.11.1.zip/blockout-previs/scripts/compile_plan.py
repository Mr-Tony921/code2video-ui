#!/usr/bin/env python3
"""Compile compact director decisions into explicit deterministic renderer data."""
import argparse,copy,json,math
from pathlib import Path
from scenography import component,build_environment
from motion import actor_states,camera_state,local_anchor,rotate,plus,POSES

def normalize_draft(draft):
 draft=copy.deepcopy(draft);notes=[]
 for i,s in enumerate(draft.get('shots',[])):
  # Accept only unambiguous declared reason aliases; never invent a jump rationale.
  reason=s.get('cut_reason');jump=s.get('jump')
  if 'jump' in s and (jump is False or jump is None) and not s.get('start'):
   s.pop('jump');notes.append(f"{s.get('id',i)}: jump=false/null normalized to continuous inheritance")
  elif isinstance(reason,str) and reason.strip() and (jump is True or (jump is None and s.get('start'))):
   s['jump']=reason;s.pop('cut_reason');notes.append(f"{s.get('id',i)}: explicit cut_reason normalized to compact jump reason")
  kept=[]
  actions={'move','carry','release','hide','show','start','jump','yaw','end_yaw','pose','pose_to','enter'}
  for item in s.get('events',[]):
   if isinstance(item,dict) and 'id' not in item:
    if not item or not set(item)<=actions:raise ValueError(f"{s.get('id',i)}: events only accepts IDs or {{id,at}}; move/carry belong at shot root. Invalid item: {item}")
    for key,value in item.items():
     if key in s and isinstance(s[key],dict) and isinstance(value,dict):
      if any(k in s[key] and s[key][k]!=v for k,v in value.items()):raise ValueError('Conflicting nested action '+key)
      s[key].update(value)
     elif key in s and s[key]!=value:raise ValueError('Conflicting nested action '+key)
     else:s[key]=value
    notes.append(f"{s.get('id',i)}: lifted unambiguous shot action fields {list(item)} from events; no event-time or action-order inference")
   else:kept.append(item)
  s['events']=kept
  # Accept the common unambiguous camera object form without asking a model to rewrite the story.
  if isinstance(s.get('camera'),dict):
   notes.append(f"{s.get('id',i)}: flattened unambiguous nested camera")
   spec=s['camera'];s['camera']=spec.get('type','static')
   allowed={'framing','angle','height','distance','lens','fov','focus','context','travel','arc','auto_frame','look_offset','camera_subject','camera_target','camera_offset','camera_look_offset'}
   for key,value in spec.items():
    if key=='type':continue
    if key not in allowed:raise ValueError('Unknown nested camera parameter '+key)
    if key in s and s[key]!=value:raise ValueError('Conflicting flat/nested camera parameter '+key)
    s[key]=value
 return draft,notes

def _compile_plan(draft,brief):
 draft,notes=normalize_draft(draft)
 invalid_jumps=[str(s.get('id',i)) for i,s in enumerate(draft.get('shots',[])) if 'jump' in s and (not isinstance(s['jump'],str) or not s['jump'].strip())]
 if invalid_jumps:raise ValueError('Compact draft jump must be a nonempty reason STRING, not a boolean. Fix jump in ALL these shot IDs: '+', '.join(invalid_jumps)+'. Use jump:"explicit time/location ellipsis reason"; keep start when required. Do not patch the expanded cut_reason field.')
 for stage_spec in draft['stages']:
  extra=set(stage_spec.get('environment',{}))-{'description','ground','modules'}
  if extra:raise ValueError(f"Stage {stage_spec['id']} environment has unsupported fields {sorted(extra)}. Remove these keys; in a targeted patch set each unwanted key to null. Supported: description, ground, modules.")
 requested_pose_ids={k for shot in draft['shots'] for field in ['pose','pose_to'] for k,v in shot.get(field,{}).items() if v!='stand'}
 for e in draft['entities']:
  if e['kind']=='person' and 'detail' not in e and e['id'] in requested_pose_ids:
   e['detail']='articulated';notes.append(e['id']+': explicit non-standing pose selects lightweight articulated proxy; explicit simple detail remains respected')
  custom=e.get('parts',[]);mode=e.pop('parts_mode','add')
  if e['kind']=='person' and (custom or e.get('asset')):raise ValueError('Person uses a built-in proxy; remove asset/custom parts and select optional detail simple/oriented/articulated')
  if e['kind']=='person':e.setdefault('detail','simple')
  if mode not in ['add','replace']:raise ValueError('parts_mode must be add or replace')
  if e.get('asset') and not (custom and mode=='replace'):e['parts']=component(e['asset'],e['size'],{'color':e['color']})+custom
  elif custom and mode=='add':
   w,h,z=e['size'];color=e['color']
   if e['kind']=='person':base=[{'kind':'cylinder','at':[0,0,0],'size':[w*.92,h*.72,z*.92],'color':color},{'kind':'sphere','at':[0,h*.85-w*.39,0],'size':[w*.78,w*.78,w*.78],'color':color},{'kind':'box','at':[0,h*.45,w*.43],'size':[w*.32,h*.2,.025],'color':'#98a1ac'}]
   else:base=[{'kind':e['kind'],'at':[0,0,0],'size':e['size'],'color':color}]
   e['parts']=base+custom
  for part in e.get('parts',[]):part.setdefault('yaw',0);part.setdefault('color',e.get('color','#c8c9c7'))
 entities={e['id']:e for e in draft['entities']}
 if len(entities)!=len(draft['entities']):raise ValueError('Duplicate entity IDs')
 stages={s['id']:s for s in draft['stages']}
 if len(stages)!=len(draft['stages']):raise ValueError('Duplicate stage IDs')
 requirements={e['id']:e for e in brief.get('events',[])}
 if len(draft['shots'])!=brief.get('shot_count',len(draft['shots'])):raise ValueError('Wrong number of shots')
 result={'version':'1.0','title':draft['title'],'normalizations':notes,'duration':brief['duration'],'entities':draft['entities'],'sets':[{'id':s['id'],'label':s.get('label',s['id']),'objects':[],'environment':{**s.get('environment',{}),'parts':build_environment(s.get('environment',{}))}} for s in draft['stages']],'shots':[]}
 if brief.get('motion_policy')=='blocking_first':result['motion_policy']='blocking_first'
 states={};headings={};poses={};bindings={};stage=None;world={};locations={};result['continuity_log']=[]
 def position(v):
  if len(v)!=3 or any(not isinstance(x,(int,float)) or not math.isfinite(x) for x in v):raise ValueError('Position must be three finite numbers')
  return list(v)
 for i,s in enumerate(draft['shots']):
  prior_bindings=copy.deepcopy(bindings)
  changed=s['stage']!=stage;stage=s['stage']
  if stage not in stages:raise ValueError('Unknown stage '+stage)
  for k in s.get('release',[]):bindings.pop(k,None)
  if stage not in world:
   world[stage]={}
   for k,v in stages[stage]['positions'].items():
    if k not in locations:world[stage][k]=position(v);locations[k]=stage
  states=copy.deepcopy(world[stage])
  arrivals=copy.deepcopy(s.get('enter',{}))
  if not changed and any(k in states for k in arrivals):raise ValueError('enter cannot relocate an already visible actor within the same stage; use move. Offscreen travellers may enter from another location.')
  if changed:arrivals.update(s.get('start',{}))
  def transfer(k,v):
   if k not in entities:raise ValueError('Unknown arriving entity '+k)
   old=locations.get(k)
   if old in world:world[old].pop(k,None)
   states[k]=position(v);locations[k]=stage
  for k,v in arrivals.items():transfer(k,v)
  # Persistent attachments cross locations with their parent, recursively. Never reset released props.
  transferred=set(arrivals)
  for _ in range(len(bindings)):
   for child,b in bindings.items():
    if b['parent'] in transferred and child not in transferred:
     transfer(child,[a+c for a,c in zip(states[b['parent']],position(b['offset']))]);transferred.add(child)
  for _ in range(len(bindings)):
   for child,b in bindings.items():
    if child in transferred and b.get('space','world')=='local':
     parent=b['parent'];a={'pose':s.get('pose',{}).get(parent,poses.get(parent,'stand'))}
     offset=rotate(plus(local_anchor(entities[parent],a,b.get('anchor','root'),0),b['offset']),s.get('yaw',{}).get(parent,headings.get(parent,0)))
     states[child]=plus(states[parent],offset)
  for k in transferred:
   if k in bindings:
    b=bindings[k]
    if b['parent'] not in states:raise ValueError('Arrival of attached child requires its parent; release first: '+k)
    expected=states[k] if b.get('space','world')=='local' else [a+c for a,c in zip(states[b['parent']],position(b['offset']))]
    if math.dist(states[k],expected)>.001:raise ValueError('Attached arrival offset conflict: '+k)
  for k in s.get('hide',[]):
   if k in bindings:bindings.pop(k)
   states.pop(k,None)
  # Other stages retain their last end state even when this stage is rendered out of order.
  for k in s.get('hide',[]):states.pop(k,None);bindings.pop(k,None)
  for k,v in s.get('show',{}).items():
   if k in states:raise ValueError('show cannot teleport an already visible entity '+k)
   if k in locations and locations[k]!=stage:raise ValueError('show cannot copy an entity from another stage; use enter on stage change: '+k)
   states[k]=position(v);locations[k]=stage
  if s.get('start') and not s.get('jump'):raise ValueError('start requires justified jump')
  for k,v in s.get('start',{}).items():states[k]=position(v)
  for k in s.get('release',[]):bindings.pop(k,None)
  start=copy.deepcopy(states);end=copy.deepcopy(states)
  for k,v in s.get('move',{}).items():
   if k not in states:raise ValueError('Move of invisible entity '+k)
   end[k]=position(v)
  bindings.update(s.get('carry',{}))
  pickup={}
  for child,b in bindings.items():
   unknown=set(b)-{'parent','offset','space','anchor','pickup_until','yaw_offset'}
   if unknown:raise ValueError('Unsupported carry fields: '+str(sorted(unknown)))
   b.setdefault('offset',[0,0,0]);b.setdefault('space','world');b.setdefault('anchor','root')
   if b['space'] not in ['local','world']:raise ValueError('carry space must be local or world')
   if b['anchor'] not in ['root','left_hand','right_hand','chest','head']:raise ValueError('Unknown carry anchor')
   if b['anchor']!='root' and b['space']!='local':raise ValueError('A named body anchor requires space:local')
   previous=prior_bindings.get(child)
   same=previous and child not in s.get('release',[]) and all(previous.get(k,default)==b.get(k,default) for k,default in [('parent',None),('offset',[0,0,0]),('space','world'),('anchor','root'),('yaw_offset',0)])
   pickup[child]=0 if same else b.get('pickup_until',.25 if b['space']=='local' else 1)
   if not isinstance(pickup[child],(int,float)) or not 0<=pickup[child]<=1:raise ValueError('pickup_until must be a fraction from 0 to 1')
  visiting=set();done=set()
  def attached(k):
   if k in done:return
   if k in visiting:raise ValueError('Cyclic carry attachment')
   visiting.add(k)
   b=bindings[k];parent=b['parent']
   if k not in states or parent not in states:raise ValueError('Carry subject or parent absent')
   if k in s.get('move',{}):raise ValueError(f'{s.get("id",i)}: {k} is attached to {parent}. Remove its independent move to keep it carried, or add release:["{k}"] before moving/placing it separately.')
   if parent in bindings:attached(parent)
   offset=position(b['offset']);end[k]=[a+b for a,b in zip(end[parent],offset)]
   visiting.remove(k);done.add(k)
  for k in bindings:
   if k in states or bindings[k]['parent'] in states:attached(k)
  for k in states:
   if k not in entities:raise ValueError('Undefined entity '+k)
  events=[{'id':x,'at':1} if isinstance(x,str) else x for x in s.get('events',[])]
  for event in events:
   if isinstance(event,dict) and 'id' in event and 'at' not in event:
    event['at']=1;notes.append(f'{s.get("id",i)}: event {event["id"]} omitted at; normalized to end-of-shot at=1, matching string-event default')
  context=list(s.get('context',[]))
  if any(k not in entities for k in context):raise ValueError('Unknown context entity')
  strict=[k for k in context if entities[k]['kind']=='person' or max(entities[k]['size'])<3]
  context=[k for k in context if k not in strict]
  if strict:notes.append(f'{s.get("id",i)}: promoted small/person context subjects to strict focus: {strict}; no subject or visibility requirement removed')
  focus=list(dict.fromkeys([*s.get('focus',s.get('move',{}).keys()),*strict]))
  if not focus:focus=[k for k in states if k in brief.get('cast',{})] or list(states)
  for ev in events:
   if ev['id'] not in requirements:raise ValueError('Unknown event '+ev['id'])
   req=requirements[ev['id']]
   repeated=[]
   for field in ['description','proxy_action','downstream_action','checks','subjects']:
    if field in ev:
     if ev[field]!=req.get(field):raise ValueError('Event '+ev['id']+' repeats conflicting frozen '+field+'; edit the draft, not the original brief')
     ev.pop(field);repeated.append(field)
   if repeated:notes.append(ev['id']+': removed exact repeated frozen event metadata '+','.join(repeated)+'; semantics remain in brief/deferred_actions')
   ev['subjects']=list(requirements[ev['id']].get('subjects',[]))
   focus.extend(ev['subjects'])
  focus=[k for k in dict.fromkeys(focus) if k not in context]
  if any(k not in states for k in focus):raise ValueError(f"{s.get('id',i)}: required focus/event subjects absent: {[k for k in focus if k not in states]}; visible={list(states)}. Restore with show before the event; do not delete required subjects.")
  if not focus and context:
   focus=context[:];notes.append(f"{s.get('id',i)}: context-only shot aims at large context subjects; partial-visibility audit retained")
  if not focus:raise ValueError(f"{s.get('id',i)}: Empty shot; provide a visible focus or large context subject")
  def center(state):return [sum(state[k][j]+(entities[k]['size'][1]*({'close':.76,'medium':.60}.get(s.get('framing'),.5) if entities[k]['kind']=='person' else .5) if j==1 else 0) for k in focus)/len(focus) for j in range(3)]
  c0=center(start);c1=center(end);mid=[(a+b)/2 for a,b in zip(c0,c1)]
  angle=math.radians(s.get('angle',0));framing=s.get('framing','full');cam=s.get('camera','static')
  if s.get('lens') and 'fov' in s:raise ValueError('Specify lens or fov, not both')
  fov=s.get('fov',50)
  if s.get('lens'):fov=math.degrees(2*math.atan(36/(2*s['lens']*(16/9))))
  coverage={'wide':.32,'full':.58,'medium':.78,'close':1.1,'insert':.72}.get(framing)
  if coverage is None:raise ValueError('framing must be wide/full/medium/close/insert')
  widths=[];heights=[]
  for state in [start,end]:
   widths.append(max(state[k][0]+entities[k]['size'][0]/2 for k in focus)-min(state[k][0]-entities[k]['size'][0]/2 for k in focus))
   heights.append(max(state[k][1]+entities[k]['size'][1] for k in focus)-min(state[k][1] for k in focus))
  dist=s.get('distance',max(1.8,max(widths)/(2*math.tan(math.radians(fov/2))*16/9*.80),max(heights)/(2*math.tan(math.radians(fov/2))*coverage)))
  if 'distance' not in s:
   lateral=0;front=0
   for state,origin in [(start,c0 if cam=='follow' else mid),(end,c1 if cam=='follow' else mid)]:
    for k in focus:
     w,h,z=entities[k]['size'];dx=state[k][0]-origin[0];dz=state[k][2]-origin[2]
     lateral=max(lateral,abs(dx*math.cos(angle)-dz*math.sin(angle))+abs(w*math.cos(angle)/2)+abs(z*math.sin(angle)/2))
     front=max(front,dx*math.sin(angle)+dz*math.cos(angle)+abs(w*math.sin(angle)/2)+abs(z*math.cos(angle)/2))
   dist=max(dist,lateral/(math.tan(math.radians(fov/2))*16/9*.82))+front+.25
  height=s.get('height',2.3 if framing=='wide' else 1.55)
  if framing=='insert':height=s.get('height',mid[1]+max(.4,dist*.2))
  move=s.get('travel',min(2,dist*.28));lookoffset=s.get('look_offset',[0,0,0])
  c0=[a+b for a,b in zip(c0,lookoffset)];c1=[a+b for a,b in zip(c1,lookoffset)];mid=[(a+b)/2 for a,b in zip(c0,c1)]
  def offset(c,d=dist,da=0):return [c[0]+math.sin(angle+da)*d,height,c[2]+math.cos(angle+da)*d]
  a=offset(mid);b=a[:];look=mid;look_to=mid
  if cam=='push':a=offset(mid,dist+move/2);b=offset(mid,max(.8,dist-move/2))
  elif cam=='pull':a=offset(mid,max(.8,dist-move/2));b=offset(mid,dist+move/2)
  elif cam=='truck':a=[a[0]-move/2*math.cos(angle),a[1],a[2]+move/2*math.sin(angle)];b=[b[0]+move/2*math.cos(angle),b[1],b[2]-move/2*math.sin(angle)]
  elif cam=='orbit':a=offset(mid,dist,-s.get('arc',2*math.asin(min(.9,move/(2*dist))))/2);b=offset(mid,dist,s.get('arc',2*math.asin(min(.9,move/(2*dist))))/2)
  elif cam=='follow':a=offset(c0);b=offset(c1);look=c0;look_to=c1
  elif cam=='pan':look=[mid[0]-math.cos(angle),mid[1],mid[2]+math.sin(angle)];look_to=[mid[0]+math.cos(angle),mid[1],mid[2]-math.sin(angle)]
  elif cam not in ['static','pov','shoulder','chase']:raise ValueError('Unknown camera '+cam)
  actors=[]
  for k in states:
   delta=[b-a for a,b in zip(start[k],end[k])];yaw=s.get('yaw',{}).get(k,math.degrees(math.atan2(delta[0],delta[2])) if entities[k]['kind']=='person' and math.hypot(delta[0],delta[2])>.01 else headings.get(k,0));headings[k]=yaw
   actor={'id':k,'from':start[k],'to':end[k],'yaw':yaw}
   if k in s.get('end_yaw',{}):actor['end_yaw']=s['end_yaw'][k];headings[k]=actor['end_yaw']
   if entities[k]['kind']=='person':
    pose=s.get('pose',{}).get(k,poses.get(k,'stand'));target=s.get('pose_to',{}).get(k,pose)
    allowed=list(POSES)
    if pose not in allowed or target not in allowed:raise ValueError('Unsupported human pose; use '+','.join(allowed))
    actor.update({'pose':pose,'pose_to':target});poses[k]=target
   if k in bindings:actor['attachment']={**copy.deepcopy(bindings[k]),'pickup_until':pickup[k]}
   actors.append(actor)
  # Recompute stored endpoints from the same live attachment evaluator as the Three.js renderer and Python checks.
  temporary={'actors':actors}
  endpoints=actor_states(temporary,entities,1)
  for actor in actors:
   if actor.get('attachment'):
    actor['to']=end[actor['id']]=endpoints[actor['id']]['position']
    if actor['attachment'].get('pickup_until')==0:
     initial=actor_states(temporary,entities,0)[actor['id']]
     actor['from']=start[actor['id']]=initial['position']
    if actor['attachment'].get('space')=='local':
     actor['yaw']=actor_states(temporary,entities,0)[actor['id']]['yaw'];actor['end_yaw']=endpoints[actor['id']]['yaw']
  shot={'id':s.get('id',f's{i+1:02d}'),'set':stage,'duration':s.get('duration',brief['duration']/len(draft['shots'])),'beat':s['beat'],'description':s['beat'],'video_prompt':s['video_prompt'],'continuity':'time_jump' if changed or s.get('jump') else 'continuous','cut_reason':s.get('jump','Establish stage' if changed else ''),'camera':{'type':cam,'from':a,'to':b,'look':look,'look_to':look_to,'fov':fov,'auto_frame':False if any(c.get('shot_id')==s.get('id',f's{i+1:02d}') and c.get('lock_camera') for c in brief.get('camera_constraints',[])) else s.get('auto_frame',True),'framing':framing},'actors':actors,'focus':focus,'context':context,'events':events}
  if cam in ['pov','shoulder','chase']:
   subject=s.get('camera_subject')
   if subject not in states:raise ValueError('Subject-mounted camera requires visible camera_subject')
   h=entities[subject]['size'][1]
   defaults={'pov':[0,h*.90,.12],'shoulder':[.55,h*.88,-1.2],'chase':[0,h*1.1,-3.2]}
   rig={'subject':subject,'offset':position(s.get('camera_offset',defaults[cam])),'look_offset':position(s.get('camera_look_offset',[0,h*.85,3])),'hide_subject':cam=='pov'}
   if s.get('camera_target'):
    if s['camera_target']==subject or s['camera_target'] not in states:raise ValueError('camera_target must be another visible actor')
    rig['target']=s['camera_target']
   shot['camera'].update({'rig':rig,'auto_frame':False})
   first=camera_state(shot,entities,0);last=camera_state(shot,entities,1)
   shot['camera'].update({'from':first['pos'],'to':last['pos'],'look':first['look'],'look_to':last['look']})
  deferred=[]
  for ev in events:
   req=requirements[ev['id']]
   if req.get('downstream_action'):
    if brief.get('motion_policy')!='blocking_first' or not isinstance(req.get('proxy_action'),str) or not req['proxy_action'].strip():
     raise ValueError('Deferred action requires frozen blocking_first policy and nonempty proxy_action: '+ev['id'])
    if not isinstance(req['downstream_action'],str):raise ValueError('downstream_action must be a string')
    deferred.append({'event_id':ev['id'],'description':req['downstream_action']})
  if deferred:
   shot['deferred_actions']=deferred
   shot['video_prompt']+='\n生成模型补充动作：'+'；'.join(x['description'] for x in deferred)
  result['shots'].append(shot)
  states=end;world[stage]=copy.deepcopy(end)
  result['continuity_log'].append({'shot':s.get('id',f's{i+1:02d}'),'stage':stage,'arrivals':sorted(transferred),'bindings':copy.deepcopy(bindings),'world':copy.deepcopy(world)})
 return result

def presence_diagnostics(draft,brief):
 """ID-only dry run of all shots; collects missing actors without inventing positions."""
 stages={x['id']:x for x in draft.get('stages',[])};required={x['id']:x.get('subjects',[]) for x in brief.get('events',[])}
 world={};location={};bindings={};missing={}
 for i,shot in enumerate(draft.get('shots',[])):
  stage=shot.get('stage');sid=shot.get('id',f's{i+1:02d}')
  if stage not in stages:continue
  if stage not in world:
   world[stage]={k for k in stages[stage].get('positions',{}) if k not in location}
   location.update({k:stage for k in world[stage]})
  state=world[stage]
  for k in shot.get('release',[]):bindings.pop(k,None)
  arrivals=set(shot.get('enter',{}))|set(shot.get('start',{}))
  for _ in range(len(bindings)+1):arrivals|={k for k,b in bindings.items() if b.get('parent') in arrivals}
  for k in arrivals:
   if location.get(k) in world:world[location[k]].discard(k)
   state.add(k);location[k]=stage
  for k in shot.get('hide',[]):state.discard(k);bindings.pop(k,None)
  state.update(shot.get('show',{}));location.update({k:stage for k in shot.get('show',{})})
  bindings.update(shot.get('carry',{}))
  needs=set(shot.get('focus',[]))|set(shot.get('context',[]))|set(shot.get('move',{}))
  for event in shot.get('events',[]):
   eid=event if isinstance(event,str) else event.get('id') if isinstance(event,dict) else None
   needs.update(required.get(eid,[]))
  for child,b in bindings.items():
   if child in state or b.get('parent') in state:needs.update([child,b.get('parent')])
  for k in needs-state:missing.setdefault((stage,k),[]).append(sid)
 return [{'code':'missing_presence','message':f"Entity {k} is absent in stage {stage}, needed by shots {','.join(shots)}. Add its actual initial location or legitimate enter/show; preserve ownership and do not delete event subjects."} for (stage,k),shots in missing.items()]

def compile_plan(draft,brief):
 """Compile once; on failure gather independent set and story diagnostics, never render an altered draft."""
 try:return _compile_plan(draft,brief)
 except Exception as original:
  diagnostics=[{'code':'compile','message':str(original)}]
  try:diagnostics.extend(presence_diagnostics(normalize_draft(draft)[0],brief))
  except Exception:pass
  # Bad scenery should not conceal independent event errors until the next repair.
  try:
   isolated=copy.deepcopy(draft)
   for st in isolated.get('stages',[]):
    env=st.get('environment',{})
    for j,m in enumerate(env.get('modules',[])):
     try:build_environment({'modules':[m]})
     except Exception as e:
      msg=f"stage {st['id']} modules[{j}]: {e}"
      diagnostics.append({'code':'environment_input','message':msg})
    st['environment']={'description':'DIAGNOSTIC ONLY: scenery removed to inspect independent event data','modules':[]}
   diagnostic_scene=_compile_plan(isolated,brief)
   from check import validate
   for issue in validate(diagnostic_scene,brief)['errors']:
    if issue['code']!='unbuilt_set':diagnostics.append(issue)
  except Exception as other:
   if str(other)!=str(original):diagnostics.append({'code':'blocking_input','message':str(other)})
  unique=list({(d['code'],d['message']):d for d in diagnostics}.values())
  raise ValueError(json.dumps({'diagnostics':unique,'note':'No scene was accepted or rendered. Scenery-free numeric inspection is diagnostic only; repair the original draft.'},ensure_ascii=False)) from original

def main():
 p=argparse.ArgumentParser();p.add_argument('draft');p.add_argument('--brief',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 result=compile_plan(json.loads(Path(a.draft).read_text()),json.loads(Path(a.brief).read_text()));Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
