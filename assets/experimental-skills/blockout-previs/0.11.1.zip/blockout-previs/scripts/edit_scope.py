"""Bounded user edits. Scope declarations are auditable, not semantic authorization."""
import copy
import hashlib
import json
import shutil
import time
from pathlib import Path


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def diff_paths(before, after, path=''):
    """ID-index the three compact collections; treat coordinate arrays atomically."""
    if before == after:
        return []
    if path in ['/shots', '/stages', '/entities']:
        before = {x['id']: x for x in before}
        after = {x['id']: x for x in after}
    if isinstance(before, dict) and isinstance(after, dict):
        result = []
        for key in sorted(set(before) | set(after)):
            part = str(key).replace('~', '~0').replace('/', '~1')
            if key not in before or key not in after:
                result.append(path + '/' + part)
            else:
                result.extend(diff_paths(before[key], after[key], path + '/' + part))
        return result
    return [path]


def is_edit(job):
    return read(job / 'job.json').get('mode') == 'user_edit'


def frozen(job):
    state = read(job / 'job.json')
    for relative, expected in state['edit_files'].items():
        if digest(job / relative) != expected:
            raise ValueError('User-edit baseline/request/brief was modified: ' + relative)
    return state, read(job / 'edit-request.json')


def start(job, base, request_path, skill, base_skill=None):
    from review import provenance, gate as visual_gate
    from story_facts import gate as facts_gate
    if job.exists():
        raise ValueError('Use a fresh user-edit folder; never overwrite an accepted film')
    if job == base or base in job.parents:
        raise ValueError('Edit folder must be outside the accepted base job')
    state = read(base / 'job.json')
    base_skill = base_skill or skill
    if state['skill'] != provenance(base_skill):
        raise ValueError('Provide the exact original base skill via --base-skill')
    # Receipt reuse across patch releases requires identical render/compile behavior.
    behavior = ['assets/motion.js', 'scripts/motion.py', 'assets/scene.js', 'assets/renderer.html', 'assets/human-poses.json',
                'scripts/render.mjs', 'scripts/compile_plan.py', 'scripts/scenography.py',
                'scripts/check.py', 'references/scene.schema.json', 'package-lock.json']
    # package-lock has a version-only difference; compare dependency lock contents.
    for relative in behavior[:-1]:
        if digest(skill / relative) != digest(base_skill / relative):
            raise ValueError('Baseline renderer/compiler differs; scoped acceptance cannot be inherited: ' + relative)
    a, b = read(skill / behavior[-1]), read(base_skill / behavior[-1])
    for obj in [a, b]:
        obj.pop('version', None)
        obj.get('packages', {}).get('', {}).pop('version', None)
    if a != b:
        raise ValueError('Baseline dependency lock differs; cannot reuse acceptance')
    base_output=base/'output';base_scene=base/'scene.json';base_draft=base/'draft.json'
    checks=read(base_output/'checks.json') if (base_output/'checks.json').exists() else {}
    accepted=bool(checks.get('ok') and checks.get('video',{}).get('decode_ok') and checks.get('scene_sha256')==digest(base_scene))
    if accepted:
        accepted=bool(visual_gate(base)['visual_review_complete'])
        facts_gate(base,state.get('require_facts',False))
    if not accepted:
        base_output=base/'reference-output'
        rendered=read(base_output/'reference-result.json')
        if not rendered.get('render_success') or not rendered.get('video',{}).get('decode_ok'):
            raise ValueError('Baseline needs a validated playable reference or an accepted video')
        source=Path(rendered['provenance']['source'])
        if source not in [base/'scene.json',base/'last-renderable-scene.json'] or digest(source)!=rendered['provenance']['source_sha256']:
            raise ValueError('Reference source changed or is not a local retained candidate')
        base_scene=source;base_draft=base/('last-renderable-draft.json' if source.name.startswith('last-') else 'draft.json')
    if not (base_output/'preview.mp4').is_file():raise ValueError('Baseline video is missing')
    request = read(request_path)
    if not isinstance(request.get('user_request'), str) or not request['user_request'].strip():
        raise ValueError('Preserve the actual user_request text')
    if not isinstance(request.get('targets'), list) or not request['targets']:
        raise ValueError('Declare specific requested target paths')
    for item in request['targets'] + request.get('dependencies', []):
        parts = item.get('path', '').split('/')
        if len(parts) < 4 or parts[1] not in ['shots', 'stages', 'entities'] or not item.get('reason'):
            raise ValueError('Each scoped target/dependency needs /collection/id/field and a reason')
    brief = read(base / 'brief.json')
    changes = request.get('brief_patch', {})
    if set(changes) - {'events'} and not request.get('changed_event_ids'):
        raise ValueError('A general brief change must declare the directly affected changed_event_ids')
    if set(changes) - {'story', 'requirements', 'events', 'camera_constraints', 'state_constraints'}:
        raise ValueError('Micro-edit preserves duration, cast, event IDs and shot count; larger restructuring is a separate user-authorized job')
    for key, value in changes.items():
        if key == 'events':
            events = {e['id']: e for e in brief['events']}
            for event in value:
                if event.get('id') not in events:
                    raise ValueError('Micro-edit must retain event IDs')
                events[event['id']].update(event)
        else:
            brief[key] = value
    job.mkdir(parents=True)
    # Copy receipts and stills, never duplicate or mutate the accepted movie.
    baseline = job / 'baseline'
    for relative in ['brief.json', 'draft.json', 'scene.json', 'job.json']:
        target = baseline / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(base_scene if relative=='scene.json' else base_draft if relative=='draft.json' else base/relative,target)
    for path in base_output.rglob('*'):
        if path.is_file() and path.suffix in ['.json', '.jpg']:
            target = baseline / 'output' / path.relative_to(base_output)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
    write(job / 'edit-request.json', request)
    write(job / 'brief.json', brief)
    shutil.copy2(base_draft, job / 'draft.json')
    shutil.copy2(base_scene, job / 'scene.json')
    files = {str(p.relative_to(job)): digest(p) for p in baseline.rglob('*') if p.is_file()}
    for relative in ['edit-request.json', 'brief.json']:
        files[relative] = digest(job / relative)
    now = time.time()
    write(job / 'job.json', {'mode': 'user_edit', 'started_at': now, 'deadline': now + 600,
          'budget_seconds': 600, 'budget_policy': 'soft_target', 'repairs': 0, 'max_repairs': 1,
          'history': [], 'require_facts': state.get('require_facts', False), 'skill': provenance(skill),
          'base_job': str(base), 'base_video': str(base_output/'preview.mp4'),
          'base_quality_pass':accepted,'base_profile':state.get('preview_profile') if accepted else rendered['profile'],
          'base_video_sha256': digest(base_output/'preview.mp4'), 'edit_files': files})
    return {'job': str(job), 'mode': 'user_edit', 'max_candidates': 2, 'max_repairs': 1,
            'baseline_preserved': str(base_output/'preview.mp4'),'base_quality_pass':accepted}


def validate_draft(job, draft):
    from compile_plan import normalize_draft
    _, request = frozen(job)
    before = normalize_draft(read(job / 'baseline/draft.json'))[0]
    after = normalize_draft(draft)[0]
    for key in ['shots', 'entities', 'stages']:
        if [x['id'] for x in before[key]] != [x['id'] for x in after[key]]:
            raise ValueError('User micro-edit cannot add/delete/reorder ' + key)
    paths = diff_paths(before, after)
    allowed = [item['path'] for item in request['targets'] + request.get('dependencies', [])]
    violations = [p for p in paths if not any(p == a or p.startswith(a + '/') for a in allowed)]
    if violations:
        raise ValueError('Edit exceeded frozen requested/dependency scope: ' + ', '.join(violations))
    if not paths:
        raise ValueError('No scene changes; do not rerender an unchanged accepted film')
    return paths


def scope(job, scene=None):
    frozen(job)
    scene = scene or read(job / 'scene.json')
    before = read(job / 'baseline/scene.json')
    old = {s['id']: s for s in before['shots']}
    changed_entities = {e['id'] for e in scene['entities'] if e != next((x for x in before['entities'] if x['id'] == e['id']), None)}
    changed_sets = {s['id'] for s in scene['sets'] if s != next((x for x in before['sets'] if x['id'] == s['id']), None)}
    changed = set()
    for shot in scene['shots']:
        if (shot != old.get(shot['id']) or shot['set'] in changed_sets
                or changed_entities.intersection(a['id'] for a in shot['actors'])):
            changed.add(shot['id'])
    original_brief = read(job / 'baseline/brief.json')
    brief = read(job / 'brief.json')
    changed_events = {e['id'] for e in brief['events'] if e != next((x for x in original_brief['events'] if x['id'] == e['id']), None)}
    changed_events.update(read(job / 'edit-request.json').get('changed_event_ids', []))
    if not changed_events.issubset({e['id'] for e in brief['events']}):
        raise ValueError('Unknown changed_event_ids')
    for shot in scene['shots']:
        if changed_events.intersection(e['id'] for e in shot.get('events', [])):
            changed.add(shot['id'])
    ordered = [s['id'] for s in scene['shots']]
    affected = set(changed)
    for i, shot_id in enumerate(ordered):
        if shot_id in changed:
            affected.update(ordered[max(0, i-1):i+2])
    event_ids = {e['id'] for s in scene['shots'] if s['id'] in affected for e in s.get('events', [])}
    result = {'mode': 'user_edit', 'changed_shots': [x for x in ordered if x in changed],
              'review_shots': [x for x in ordered if x in affected],
              'review_events': [e['id'] for e in brief['events'] if e['id'] in event_ids],
              'inherited_events': [e['id'] for e in brief['events'] if e['id'] not in event_ids],
              'base_scene_sha256': digest(job / 'baseline/scene.json'),
              'scene_sha256': digest(job / 'scene.json') if scene == read(job / 'scene.json') else None,
              'baseline_quality_pass':read(job/'job.json').get('base_quality_pass',False),
              'note': 'Actual compiled changes include propagated actor/prop/camera state; adjacent cuts are added. Unchanged events retain their archived review status, including unresolved quality, not a fresh model verdict.'}
    write(job / 'output/edit-scope.json', result)
    return result


def gate(job):
    state, _ = frozen(job)
    if not 1 <= state.get('draft_attempts', 0) <= 2 or state['repairs'] > 1:
        raise ValueError('A user edit permits one candidate plus at most one correction')
    paths = validate_draft(job, read(job / 'draft.json'))
    from compile_plan import compile_plan
    if compile_plan(read(job / 'draft.json'), read(job / 'brief.json')) != read(job / 'scene.json'):
        raise ValueError('Scene no longer matches the scoped compact edit')
    return {**scope(job), 'edited_paths': paths, 'repairs': state['repairs']}


def main():
    import argparse
    import subprocess
    import sys
    from patch_draft import patch_draft
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['start', 'apply', 'status'])
    parser.add_argument('job')
    parser.add_argument('--base')
    parser.add_argument('--base-skill')
    parser.add_argument('--request')
    parser.add_argument('--patch')
    args = parser.parse_args()
    job = Path(args.job).resolve()
    skill = Path(__file__).resolve().parents[1]
    if args.command == 'start':
        if not args.base or not args.request:
            raise ValueError('start requires --base and --request')
        result = start(job, Path(args.base).resolve(), Path(args.request), skill,
                       Path(args.base_skill).resolve() if args.base_skill else None)
    elif args.command == 'apply':
        if not args.patch:
            raise ValueError('apply requires --patch')
        state, _ = frozen(job)
        if state.get('draft_attempts', 0) >= 2:
            raise ValueError('Edit exhausted: preserve the accepted baseline and report unresolved scope')
        try:
            draft = patch_draft(read(job / 'draft.json'), read(args.patch))
        except Exception:
            state['draft_attempts'] = state.get('draft_attempts', 0) + 1
            state['repairs'] = max(0, state['draft_attempts'] - 1)
            write(job / 'job.json', state)
            raise
        write(job / 'edit-candidate.json', draft)
        # job.py enforces scope and charges invalid candidate attempts too.
        raise SystemExit(subprocess.call([sys.executable, str(skill / 'scripts/job.py'), 'compile',
                                          str(job), '--draft', str(job / 'edit-candidate.json')]))
    else:
        state, request = frozen(job)
        result = {'state': state, 'request': request, 'scope': scope(job)}
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(json.dumps({'ok': False, 'error': type(exc).__name__, 'message': str(exc)}, ensure_ascii=False))
        raise SystemExit(1)
