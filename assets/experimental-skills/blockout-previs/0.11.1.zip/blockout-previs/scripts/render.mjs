#!/usr/bin/env node
import fs from 'node:fs';import path from 'node:path';import http from 'node:http';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';import {once} from 'node:events';
import puppeteer from 'puppeteer-core';import {WebSocketServer} from 'ws';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const args={};for(let i=2;i<process.argv.length;i+=2)args[process.argv[i].replace(/^--/,'')]=process.argv[i+1];
if(!args.scene||!args.out){console.error('Usage: node scripts/render.mjs --scene scene.json --out output --mode preview|video --width 640 --height 360 --fps 24 --timeout 240');process.exit(2);}
const data=JSON.parse(fs.readFileSync(args.scene)),out=path.resolve(args.out);fs.mkdirSync(out,{recursive:true});
const width=+(args.width||640),height=+(args.height||360),fps=+(args.fps||24),mode=args.mode||'preview',t0=performance.now();
let browser,server,wss,encoder,timer,profileDir;const errors=[];let encoderLog='';
async function cleanup(){clearTimeout(timer);if(encoder?.exitCode===null)encoder.kill('SIGKILL');if(wss){for(const c of wss.clients)c.terminate();wss.close();}if(browser)await browser.close().catch(()=>{});server?.close();if(profileDir)fs.rmSync(profileDir,{recursive:true,force:true});}
process.on('SIGTERM',()=>{cleanup().finally(()=>process.exit(124));});
try{
 timer=setTimeout(()=>{console.error('Rendering deadline exceeded');cleanup().finally(()=>process.exit(124));},1000*+(args.timeout||240));
 const allowed={'/':ROOT+'/assets/renderer.html','/scene.js':ROOT+'/assets/scene.js','/motion.js':ROOT+'/assets/motion.js','/human-poses.json':ROOT+'/assets/human-poses.json','/render-profile.json':ROOT+'/assets/render-profile.json','/vendor/three.module.js':ROOT+'/node_modules/three/build/three.module.js','/vendor/three.core.js':ROOT+'/node_modules/three/build/three.core.js'};
 server=http.createServer((req,res)=>{const f=allowed[req.url];if(!f){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':'text/html');fs.createReadStream(f).pipe(res);});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 const chromeArgs=['--no-sandbox','--disable-dev-shm-usage','--ignore-gpu-blocklist','--use-gl=angle','--use-angle=gl','--enable-webgl','--disable-background-timer-throttling'];
 if(args.software==='true'){chromeArgs.splice(chromeArgs.indexOf('--use-angle=gl'),1,'--use-angle=swiftshader','--enable-unsafe-swiftshader');}
 profileDir=fs.mkdtempSync(path.join(out,'.browser-'));
 browser=await puppeteer.launch({executablePath:process.env.CHROME_PATH||'/usr/bin/google-chrome',userDataDir:profileDir,headless:true,args:chromeArgs,protocolTimeout:1000*+(args.timeout||240)});
 const page=await browser.newPage();await page.setViewport({width,height,deviceScaleFactor:1});page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${port}`);await page.waitForFunction('window.ready === true');
 const hardware=await page.evaluate((opts)=>window.init(opts),{plan:data,width,height});
 const compiled=await page.evaluate(()=>window.compileCameras());fs.writeFileSync(path.join(out,'cutaway-adjustments.json'),JSON.stringify(compiled.cutaways,null,2));fs.writeFileSync(path.join(out,'camera-adjustments.json'),JSON.stringify(compiled.adjustments,null,2));fs.writeFileSync(path.join(out,'effective-scene.json'),JSON.stringify(compiled.effective_scene,null,2));
 const determinism=[];
 for(const index of [...new Set([0,Math.floor(data.shots.length/2),data.shots.length-1])]){
  const result=await page.evaluate(({index,last})=>{window.frame(index,.37);const a=JSON.stringify(window.stateSnapshot()),pixels=window.jpeg();window.frame(last,.83);window.frame(index,.37);return {shot:index,state_equal:a===JSON.stringify(window.stateSnapshot()),pixels_equal:pixels===window.jpeg()};},{index,last:data.shots.length-1-index});determinism.push(result);
 }
 fs.writeFileSync(path.join(out,'determinism-validation.json'),JSON.stringify({scope:'Three A-B-A samples on actual rendered nodes and JPEGs, not exhaustive timeline proof',samples:determinism},null,2));
 if(determinism.some(r=>!r.state_equal))throw Error('Non-deterministic world/camera state');
 const endpoints=await page.evaluate(()=>window.sceneEndpointAudit());
 const motionChecks=compiled.effective_scene.shots.map((shot,i)=>{
  const original=data.shots[i].camera,actual=shot.camera,delta=(a,b)=>b.map((x,k)=>x-a[k]);
  const error=(a,b)=>Math.hypot(...a.map((x,k)=>x-b[k]));
  return {shot:shot.id,type:actual.type,camera_displacement_error:error(delta(original.from,original.to),delta(actual.from,actual.to)),look_displacement_error:error(delta(original.look,original.look_to||original.look),delta(actual.look,actual.look_to||actual.look)),camera_endpoint_error:Math.max(error(endpoints[i].start.pos,actual.from),error(endpoints[i].end.pos,actual.to)),look_endpoint_error:Math.max(error(endpoints[i].start.look,actual.look),error(endpoints[i].end.look,actual.look_to||actual.look))};
 });
 fs.writeFileSync(path.join(out,'camera-motion-validation.json'),JSON.stringify(motionChecks,null,2));
 if(motionChecks.some(r=>r.camera_displacement_error>1e-6||r.look_displacement_error>1e-6||r.camera_endpoint_error>1e-6||r.look_endpoint_error>1e-6))throw Error('Automatic framing changed authored camera or target displacement');
 const sets=await page.evaluate(()=>window.setAudit());fs.writeFileSync(path.join(out,'set-audit.json'),JSON.stringify(sets,null,2));
 const geometry=await page.evaluate(()=>window.audit());fs.writeFileSync(path.join(out,'geometry.json'),JSON.stringify(geometry,null,2));
 fs.mkdirSync(path.join(out,'frames'),{recursive:true});
 for(let i=0;i<data.shots.length;i++)for(const [suffix,u]of [['a',0],['b',.5],['c',1]]){
  const b64=await page.evaluate(({i,u})=>{window.frame(i,u);return window.jpeg();},{i,u});
  fs.writeFileSync(path.join(out,'frames',`${String(i+1).padStart(3,'0')}_${suffix}.jpg`),Buffer.from(b64,'base64'));
 }
 fs.mkdirSync(path.join(out,'event-frames'),{recursive:true});
 const reviewSamples=[];
 for(let i=0;i<data.shots.length;i++)for(const ev of data.shots[i].events){
  const eventIndex=data.shots.slice(0,i).reduce((n,s)=>n+s.events.length,0)+data.shots[i].events.indexOf(ev);
  const delta=Math.min(1/data.shots[i].duration,.1),stem=String(eventIndex+1).padStart(3,'0');
  for(const [label,u]of [['before',Math.max(0,ev.at-delta)],['exact',ev.at],['after',Math.min(1,ev.at+delta)]]){
   const sample=await page.evaluate(({i,u})=>{window.frame(i,u);return {b64:window.jpeg(),subjects:window.reviewSubjects()};},{i,u});
   const file=`event-frames/${stem}${label==='exact'?'':'_'+label}.jpg`;
   fs.writeFileSync(path.join(out,file),Buffer.from(sample.b64,'base64'));
   reviewSamples.push({event:ev.id,shot:data.shots[i].id,shot_index:i,label,u,file,subjects:sample.subjects});
  }
 }
 fs.writeFileSync(path.join(out,'review-samples.json'),JSON.stringify(reviewSamples,null,2));
 fs.copyFileSync(args.scene,path.join(out,'source-scene.json'));
 const previewSeconds=(performance.now()-t0)/1000;let frames=0;
 if(mode==='video'){
  const dest=path.join(out,'preview.mp4'),temp=path.join(out,'preview.partial.mp4');
  encoder=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size',`${width}x${height}`,'-framerate',String(fps),'-i','pipe:0','-vf','vflip','-c:v','libx264','-preset','ultrafast','-crf','22','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',temp],{stdio:['pipe','ignore','pipe']});
  encoder.stderr.on('data',b=>{encoderLog+=b.toString();});encoder.stdin.on('error',()=>{});const ended=once(encoder,'close');
  wss=new WebSocketServer({server,maxPayload:width*height*4+1000});
  wss.on('connection',ws=>{ws.on('message',(buffer,binary)=>{
   if(binary){if(buffer.length!==width*height*4){ws.close();return;}const ok=encoder.stdin.write(buffer);if(ok)ws.send('ok');else encoder.stdin.once('drain',()=>{if(ws.readyState===1)ws.send('ok');});}
   else{const msg=JSON.parse(buffer.toString());if(msg.done)encoder.stdin.end();}
  });});
  frames=await page.evaluate(opts=>window.exportVideo(opts),{url:`ws://127.0.0.1:${port}`,fps});
  const [code]=await ended;if(code!==0)throw Error('FFmpeg failed: '+encoderLog);fs.renameSync(temp,dest);
 }
 if(errors.length)throw Error(errors.join(';'));
 const result={ok:true,mode,width,height,fps,frames,duration:data.shots.reduce((s,x)=>s+x.duration,0),preview_seconds:previewSeconds,total_seconds:(performance.now()-t0)/1000,hardware};
 fs.writeFileSync(path.join(out,mode==='video'?'render.json':'preview-render.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 await cleanup();
}catch(e){console.error(e.message);await cleanup();process.exit(1);}
