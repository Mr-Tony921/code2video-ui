#!/usr/bin/env python3
"""Apply bounded ID-based compact-plan edits; compilation consumes the repair round."""
import argparse,copy,json
from pathlib import Path
from compile_plan import normalize_draft

def merge(base,patch):
 if not isinstance(patch,dict):return copy.deepcopy(patch)
 result=copy.deepcopy(base) if isinstance(base,dict) else {}
 for k,v in patch.items():
  if v is None:result.pop(k,None)
  else:result[k]=merge(result.get(k),v)
 return result

def patch_draft(draft,patch):
 if not isinstance(patch,dict) or not patch:raise ValueError('Repair patch must be a nonempty object')
 if set(patch)-{'title','shots','stages','entities'}:raise ValueError('Allowed patch fields: title, shots, stages, entities')
 # An invalid normalization must not prevent a patch from fixing that very field.
 try:out=normalize_draft(draft)[0]
 except ValueError:out=copy.deepcopy(draft)
 # The normal compiler still validates the patched result before any rendering.
 for collection in ['shots','stages','entities']:
  if collection not in patch:continue
  edits=patch[collection]
  if not isinstance(edits,list):raise ValueError(collection+' patch must be a list of objects with existing IDs')
  existing={item['id']:i for i,item in enumerate(out[collection])};seen=set()
  for edit in edits:
   if not isinstance(edit,dict) or edit.get('id') not in existing:raise ValueError('Unknown '+collection+' ID in repair; use full draft only for an intentional structural redesign')
   if edit['id'] in seen:raise ValueError('Duplicate patch ID '+edit['id'])
   seen.add(edit['id']);i=existing[edit['id']];out[collection][i]=merge(out[collection][i],edit)
 if 'title' in patch:out['title']=patch['title']
 return out

def main():
 p=argparse.ArgumentParser();p.add_argument('draft');p.add_argument('--patch',required=True);p.add_argument('--out',required=True);a=p.parse_args();result=patch_draft(json.loads(Path(a.draft).read_text()),json.loads(Path(a.patch).read_text()));Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
