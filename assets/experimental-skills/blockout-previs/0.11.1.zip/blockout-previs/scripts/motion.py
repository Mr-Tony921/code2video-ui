"""Deterministic sampled actor/attachment/camera transforms, mirrored by motion.js."""
import json,math
from pathlib import Path
POSES=json.loads((Path(__file__).resolve().parents[1]/'assets/human-poses.json').read_text())
def mix(a,b,u):return [x+(y-x)*u for x,y in zip(a,b)]
def plus(a,b):return [x+y for x,y in zip(a,b)]
def rotate(p,yaw):
 a=math.radians(yaw);c,s=math.cos(a),math.sin(a)
 return [p[0]*c+p[2]*s,p[1],-p[0]*s+p[2]*c]
def yaw_at(a,u):return a.get('yaw',0)+((a.get('end_yaw',a.get('yaw',0))-a.get('yaw',0)+180)%360-180)*u

def local_anchor(entity,actor,anchor,u):
 if anchor=='root':return [0,0,0]
 key={'left_hand':'lwrist','right_hand':'rwrist','head':'head','chest':'neck'}[anchor]
 if entity.get('detail','simple')=='articulated':
  a=POSES[actor.get('pose','stand')][key];b=POSES[actor.get('pose_to',actor.get('pose','stand'))][key]
  return [v*entity['size'][1] for v in mix(a,b,u)]
 h=entity['size'][1]
 return {'left_hand':[-.18*h,.65*h,.15*h],'right_hand':[.18*h,.65*h,.15*h],'head':[0,.9*h,0],'chest':[0,.65*h,0]}[anchor]

def actor_states(shot,entities,u):
 actors={a['id']:a for a in shot['actors']};cache={};visiting=set()
 def resolve(k):
  if k in cache:return cache[k]
  if k in visiting:raise ValueError('Cyclic attachment: '+k)
  if k not in actors:raise ValueError('Attachment/camera actor absent: '+k)
  visiting.add(k);a=actors[k];state={'position':mix(a['from'],a['to'],u),'yaw':yaw_at(a,u)};b=a.get('attachment')
  if b:
   parent=resolve(b['parent']);offset=b['offset'];local=b.get('space','world')=='local'
   if local:offset=rotate(plus(local_anchor(entities[b['parent']],actors[b['parent']],b.get('anchor','root'),u),offset),parent['yaw'])
   target=plus(parent['position'],offset);until=b.get('pickup_until',1)
   weight=min(1,u/until) if until>0 else 1
   # Acquisition is a bounded transition; afterwards the child follows the live parent.
   state['position']=mix(a['from'],target,weight)
   if local:state['yaw']=parent['yaw']+b.get('yaw_offset',0)
  cache[k]=state;visiting.remove(k);return state
 for k in actors:resolve(k)
 return cache

def camera_state(shot,entities,u,states=None):
 c=shot['camera'];rig=c.get('rig');states=states or actor_states(shot,entities,u)
 if rig:
  state=states[rig['subject']];pos=plus(state['position'],rotate(rig['offset'],state['yaw']))
  if rig.get('target'):
   target=rig['target'];look=plus(states[target]['position'],[0,entities[target]['size'][1]*.65,0])
  else:look=plus(state['position'],rotate(rig['look_offset'],state['yaw']))
  return {'pos':pos,'look':look}
 pos=mix(c['from'],c['to'],u);look=mix(c['look'],c.get('look_to',c['look']),u)
 if c['type']=='orbit':
  a=[x-y for x,y in zip(c['from'],c['look'])];b=[x-y for x,y in zip(c['to'],c.get('look_to',c['look']))]
  theta=math.atan2(a[0],a[2]);delta=(math.atan2(b[0],b[2])-theta+math.pi)%(2*math.pi)-math.pi;r=math.hypot(a[0],a[2])*(1-u)+math.hypot(b[0],b[2])*u
  pos=[look[0]+r*math.sin(theta+u*delta),pos[1],look[2]+r*math.cos(theta+u*delta)]
 return {'pos':pos,'look':look}
