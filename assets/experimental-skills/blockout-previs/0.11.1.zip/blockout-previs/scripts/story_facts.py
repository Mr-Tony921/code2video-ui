"""Portable factual review packets/receipts; no model API or semantic oracle."""
import copy
import hashlib
import json
import math
from pathlib import Path
from motion import actor_states,camera_state


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2))


def surface_candidates(stage, point):
    """Nearby horizontal support surfaces, not a collision/semantic verdict."""
    env = stage.get('environment', {})
    candidates = []
    ground = env.get('ground', {})
    gx, gy, gz = ground.get('at', [0, -.025, 0])
    gw, gd = ground.get('size', [55, 55])
    if abs(point[0]-gx) <= gw/2 and abs(point[2]-gz) <= gd/2:
        candidates.append({'surface': 'ground', 'kind': 'ground', 'top_y': gy, 'vertical_gap': point[1]-gy})
    for i, module in enumerate(env.get('modules', [])):
        kind = module['kind']
        if kind not in ['box', 'wall', 'table', 'chair', 'bench', 'stairs']: continue
        w, h, d = module['size'];mx, my, mz = module.get('at', [0, 0, 0])
        angle = math.radians(module.get('yaw', 0));c, s = math.cos(angle), math.sin(angle)
        dx, dz = point[0]-mx, point[2]-mz
        x, z = c*dx-s*dz, s*dx+c*dz
        if abs(x) > w/2+1e-6 or abs(z) > d/2+1e-6: continue
        if kind == 'stairs':
            n = min(20, max(2, int(module.get('steps', 8))))
            step = min(n-1, max(0, int((z+d/2)/d*n)))
            top = my+h*(step+1)/n
        else: top = my+h*(.45 if kind in ['chair','bench'] else 1)
        candidates.append({'surface': f'module:{i}', 'kind': kind, 'top_y': top, 'vertical_gap': point[1]-top})
    candidates.sort(key=lambda item: abs(item['vertical_gap']))
    return [{k:round(v,6) if isinstance(v,float) else v for k,v in item.items()} for item in candidates[:3]]


def annotated_shots(scene, poses):
    entities = {e['id']:e for e in scene['entities']}
    stages = {s['id']:s for s in scene['sets']}
    result = []
    for shot in scene['shots']:
        item = {k:copy.deepcopy(shot[k]) for k in ['id','set','duration','actors','events','camera','continuity','cut_reason','deferred_actions'] if k in shot}
        definitions={e['id']:e for e in scene['entities']}
        affected={a['id'] for a in shot['actors'] if a.get('attachment')}|{a['attachment']['parent'] for a in shot['actors'] if a.get('attachment')}
        rig=shot['camera'].get('rig',{});affected.update(v for k,v in rig.items() if k in ['subject','target'])
        if affected:
            item['actual_motion_samples']=[{'u':u,'actors':{k:{'position':[round(x,4) for x in v['position']],'yaw':round(v['yaw'],3)} for k,v in actor_states(shot,definitions,u).items() if k in affected},'camera':camera_state(shot,definitions,u) if rig else None} for u in [.25,.5,.75]]
        for actor in item.get('actors', []):
            if 'from' not in actor or 'to' not in actor: continue
            delta = [b-a for a,b in zip(actor['from'], actor['to'])]
            actor['measured_motion'] = {'delta_xyz': [round(x,6) for x in delta], 'travel_m': round(math.sqrt(sum(x*x for x in delta)),6)}
            entity = entities.get(actor['id'], {})
            if entity.get('kind') != 'person': continue
            samples = []
            for end in [False, True]:
                point = list(actor['to' if end else 'from']);pose = actor.get('pose_to' if end else 'pose', 'stand')
                anchor = 'bottom_center'
                if pose == 'sit' and entity.get('detail','simple') == 'articulated':
                    h = entity['size'][1];joint = poses['sit']['hip'];a = math.radians(actor.get('yaw',0));c,s=math.cos(a),math.sin(a)
                    point = [point[0]+h*(c*joint[0]+s*joint[2]),point[1]+h*joint[1],point[2]+h*(-s*joint[0]+c*joint[2])]
                    anchor = 'seated_pelvis_joint'
                samples.append({'at':'end' if end else 'start','anchor':anchor,'point':[round(x,6) for x in point], 'nearby_surfaces':surface_candidates(stages[shot['set']],point)})
            actor['environment_surface_samples'] = samples
        result.append(item)
    return result


def packet(job):
    scene = read(job / 'scene.json')
    skill = Path(__file__).resolve().parents[1]
    poses = read(skill / 'assets/human-poses.json')
    used = {a.get(k, 'stand') for s in scene['shots'] for a in s.get('actors', []) for k in ['pose', 'pose_to']}
    stages = []
    for stage in scene['sets']:
        environment = copy.deepcopy(stage.get('environment', {}))
        environment.pop('parts', None)  # authored modules suffice; expanded meshes duplicate them
        stages.append({'id': stage['id'], 'environment': environment, 'objects': stage.get('objects', [])})
    data = {
        'generator_sha256': digest(Path(__file__)),
        'scene_sha256': digest(job / 'scene.json'),
        'brief_sha256': digest(job / 'brief.json'),
        'original_brief': read(job / 'brief.json'),
        'actual_scene': {
            'coordinate_anchor': 'World Y is vertical, X/Z horizontal; actor positions are bottom center. Module at is bottom center; top=at.y+size.y; apply yaw to footprints.',
            'runtime_contract': {
                'source_sha256': {f: digest(skill / f) for f in ['assets/scene.js', 'assets/motion.js', 'scripts/motion.py', 'assets/human-poses.json', 'scripts/scenography.py']},
                'builtin_person': 'Default detail=simple is only a cylinder body (height 0.8H, width/depth 0.65 times size) and sphere head (diameter 0.2H, center Y=0.9H). No limbs, facial features or joint poses are implied. detail=oriented adds one optional +Z direction marker. detail=articulated adds torso and four segmented limbs; face_marker=true optionally adds neutral eye/nose markers. yaw rotates the proxy. These detail choices are optional; a missing limb/face/posture alone is not a story failure.',
                'pose_transform': 'Only detail=articulated applies the joint coordinates below, scaled by entity height, yaw and actor translation. Other detail levels translate/rotate their simple whole-body proxy and do NOT apply named joint poses. Do not claim a simple proxy visually performed a joint pose. Optional omitted acting belongs in downstream video prompts; core travel, location, object ownership and requested camera remain binding.',
                'used_pose_joints': {k: poses[k] for k in sorted(used) if k in poses},
                'furniture': {'chair_or_bench': 'Seat surface local Y=size[1]*0.45; seat footprint spans width/depth. Overall size[1] includes the backrest, not seat height.', 'table': 'Tabletop surface local Y=size[1].', 'box_or_wall': 'Top surface local Y=size[1].', 'stairs': 'Default 8 steps, options.steps clamped to 2..20. Local Z increases from -depth/2 to +depth/2; step i (zero-based) top Y=height*(i+1)/n. Apply module yaw/at to world coordinates.'},
                'scope': 'Definitions establish available geometry and pose semantics; actual screen visibility still needs images. Local hand/body attachments are evaluated every frame; this is not IK or physical contact solving. No gait, fingers or facial acting is implemented. Do not invent them as acceptance requirements.'
            },
            'measured_fact_scope': 'measured_motion is exact endpoint arithmetic. environment_surface_samples lists up to three nearby authored-module/ground horizontal surfaces beneath the X/Z projection, sorted by absolute vertical gap; gap=pointY-surfaceY. This is evidence, not automatic acceptance, and does not cover movable entity surfaces, repeated instances, arbitrary meshes, whole-path support or all collisions. Absence from this partial table is not proof that support is absent. A stairs surface is a step, not a flat landing merely because characters are close together. Seated samples use the pelvis joint, other poses bottom center.',
            'entities': scene['entities'],
            'stage_geometry': stages,
            'shots': annotated_shots(scene, poses),
        },
        'scope': 'Authored world trajectories and geometry only. Camera assistance/cutaways and screen visibility still require preview/image review. Descriptive beat/video_prompt prose is deliberately excluded.',
    }
    data['actual_scene']['runtime_contract'].update({
        'motion_and_carry': 'Unbound actors translate and rotate deterministically. Attached children are evaluated each frame from the live parent. space:local rotates offset and an optional body/hand anchor with the parent; articulated anchor joints follow the current pose. pickup_until is the acquisition fraction, not a whole-shot gap after acquisition; persistent binding has pickup_until:0. release preserves the last actual position. Subject-mounted cameras follow the named actor; a POV owner is intentionally outside the image, but other event participants stay subject to visibility checks.',
        'offscreen_arrivals': 'continuity_log records legitimate enter/start arrivals and persistent bindings for each shot. An offscreen character may enter the current stage from another location without a whole-shot time jump. Do not infer teleport solely because cut_reason is empty or continuity is continuous; inspect actual arrivals and adjacent endpoints.',
        'rough_contact': 'This is rough narrative previs. Small contact gaps or noncritical overlap alone are warnings; block only when they contradict a requested location/action/ownership, prevent required visibility, or violate an explicit metric constraint. An authored coarse floor footprint is not automatically the semantic entrance boundary of a station or room.'})
    data['actual_scene']['continuity_log'] = copy.deepcopy(scene.get('continuity_log', []))
    if read(job / 'job.json').get('mode') == 'user_edit':
        from edit_scope import gate as edit_gate
        scope = edit_gate(job)
        data['edit_scope'] = scope
        data['user_edit_request'] = read(job / 'edit-request.json')
        data['original_brief']['events'] = [e for e in data['original_brief']['events'] if e['id'] in scope['review_events']]
        data['actual_scene']['shots'] = [s for s in data['actual_scene']['shots'] if s['id'] in scope['review_shots']]
        data['actual_scene']['continuity_log'] = [s for s in data['actual_scene']['continuity_log'] if s['shot'] in scope['review_shots']]
        data['scope'] += ' Review only the user change and affected events/cuts. Other events inherit the archived baseline; do not add detail, camera taste or a new whole-film critique.'
    write(job / 'output/story-facts.json', data)
    return data


def validate_receipt(job, receipt):
    brief = read(job / 'brief.json')
    if receipt.get('scene_sha256') != digest(job / 'scene.json') or receipt.get('brief_sha256') != digest(job / 'brief.json'):
        raise ValueError('Factual review must bind the current scene_sha256 and brief_sha256')
    expected = {e['id'] for e in brief['events']}
    if read(job / 'job.json').get('mode') == 'user_edit':
        from edit_scope import gate as edit_gate
        expected = set(edit_gate(job)['review_events'])
    if not isinstance(receipt.get('critical_issues', []), list):
        raise ValueError('critical_issues must be a list')
    events = receipt.get('events', [])
    if not isinstance(events, list) or len(events) != len(expected) or {e.get('id') for e in events} != expected:
        raise ValueError('Factual review must cover every original event exactly once')
    for event in events:
        clauses = event.get('clauses')
        if not isinstance(clauses, list) or not clauses:
            raise ValueError('Every event requires original required clauses and actual evidence')
        for clause in clauses:
            if any(not isinstance(clause.get(k), str) or not clause[k].strip() for k in ['required', 'actual']) or type(clause.get('match')) is not bool:
                raise ValueError('Each clause needs nonempty required/actual text and boolean match')
        verdict = 'pass' if all(c['match'] for c in clauses) else 'blocker'
        if event.get('verdict') != verdict:
            raise ValueError('A factual mismatch cannot be downgraded to pass or appearance warning')


def record(job, path):
    receipt = read(path)
    write(job / 'output/story-review-attempt.json', receipt)
    validate_receipt(job, receipt)
    if receipt.get('critical_issues'):
        raise ValueError('Unresolved declared critical factual issues; repair or clear them with current evidence')
    receipt['record_type'] = 'model_or_human_declared_factual_review'
    receipt['machine_verified_semantic_truth'] = False
    if read(job / 'job.json').get('mode') == 'user_edit':
        from edit_scope import gate as edit_gate
        receipt['edit_scope'] = edit_gate(job)
    write(job / 'output/story-review.json', receipt)
    return gate(job, required=True)


def gate(job, required=False):
    path = job / 'output/story-review.json'
    if not path.exists():
        if required:
            raise ValueError('Required factual review is missing; run facts and record-facts before export')
        return {'factual_review_complete': False, 'required': False}
    receipt = read(path)
    validate_receipt(job, receipt)
    if receipt.get('critical_issues'):
        raise ValueError('Unresolved declared critical factual issues')
    if any(e.get('verdict') != 'pass' or any(c.get('match') is not True for c in e.get('clauses', [])) for e in receipt['events']):
        raise ValueError('Unresolved original event fact; repair within the same bounded job or fail')
    return {'factual_review_complete': True, 'required': required, 'declared_review_only': True}
