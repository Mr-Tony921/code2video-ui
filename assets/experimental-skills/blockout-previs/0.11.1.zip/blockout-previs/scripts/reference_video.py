"""Export a playable adjustment baseline without claiming instruction compliance."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from check import validate, verify_video

FATAL = {'schema', 'nonfinite', 'duplicate_entity', 'duplicate_set', 'duplicate_shot',
         'unknown_entity', 'unknown_set', 'duplicate_actor', 'unknown_actor', 'focus_absent',
         'duplicate_event','motion_reference'}
BASIC = {'duration', 'target_duration', 'scene_count', 'shot_count', 'human_required',
         'static_entity_absent', 'missing_event', 'event_actor_absent'}

def read(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2))

def technical_check(scene):
    try:
        check=validate(scene)
        errors=[e for e in check['errors'] if e['code'] in FATAL]
        return {'ok':not errors,'errors':errors,
                'nontechnical_findings':[e for e in check['errors'] if e['code'] not in FATAL]}
    except Exception as exc:
        return {'ok':False,'errors':[{'code':'structural_check_error','message':str(exc)}]}

def export(job,out,skill,width=640,height=360,fps=24,software=False,renderer_skill=None):
    from review import provenance
    started=time.monotonic();chosen=None;candidates=[];renderer_skill=renderer_skill or skill
    for relative in ['scene.json','last-renderable-scene.json']:
        path=job/relative
        if not path.exists():continue
        try:check=technical_check(read(path))
        except Exception as exc:check={'ok':False,'errors':[{'code':'parse','message':str(exc)}]}
        candidates.append({'source':relative,**check})
        if check['ok']:
            chosen=path;break
    if chosen is None:raise ValueError('No structurally renderable candidate remains; report technical failure without inventing a replacement story')
    if width<64 or height<64 or width>1920 or height>1920 or width%2 or height%2 or not 1<=fps<=60:
        raise ValueError('Use even dimensions 64..1920 and fps 1..60')
    scene=read(chosen);brief=read(job/'brief.json');out.mkdir(parents=True,exist_ok=True)
    source=out/'reference-scene.json';write(source,scene)
    request={'source':str(chosen),'source_sha256':digest(chosen),'exporter_skill':provenance(skill),'renderer_skill':provenance(renderer_skill),
             'job_skill':read(job/'job.json').get('skill'),'candidate_checks':candidates,
             'scope':'Technical playable reference only; does not promote quality or reset repair counters'}
    write(out/'reference-request.json',request)
    command=['node',str(renderer_skill/'scripts/render.mjs'),'--scene',str(source),'--out',str(out),
             '--mode','video','--timeout','600','--width',str(width),'--height',str(height),
             '--fps',str(fps),'--software',str(software).lower()]
    result=subprocess.run(command,capture_output=True,text=True,timeout=610)
    write(out/'export-process.json',{'returncode':result.returncode,'stdout':result.stdout[-4000:],'stderr':result.stderr[-2000:]})
    if result.returncode:raise RuntimeError('Reference render failed: '+result.stderr[-1200:])
    actual_timeline={**scene,'duration':sum(s['duration'] for s in scene['shots'])}
    video=verify_video(out/'preview.mp4',actual_timeline,fps,max_seconds=120,width=width,height=height)
    if not video['ok']:raise ValueError('Reference video failed decode/metadata checks: '+json.dumps(video))
    try:quality=validate(scene,brief,read(out/'geometry.json'))
    except Exception as exc:quality={'ok':False,'errors':[{'code':'quality_evaluation','message':str(exc)}],'warnings':[]}
    basic=[e for e in quality.get('errors',[]) if e['code'] in BASIC]
    advanced=[e for e in quality.get('errors',[]) if e['code'] not in BASIC]
    receipt={'status':'RENDERED_FOR_ADJUSTMENT','render_success':True,'quality_pass':False,
             'quality_status':'NOT_CERTIFIED', 'video':video,'source_sha256':digest(source),
             'profile':{'width':width,'height':height,'fps':fps,'software':software},
             'numeric_basic_requirements':{'passed':not basic,'issues':basic},
             'numeric_motion_camera_continuity':{'passed':not advanced,'issues':advanced},
             'quality_checks':quality,'semantic_review_required':True,
             'warning':'Playable does not mean instruction-compliant. Preserve known story/visibility issues and let the user decide whether to adjust or use downstream.',
             'export_seconds':time.monotonic()-started,'provenance':request}
    # Preserve any existing declared failures without treating them as technical render failures.
    for name in ['story-review.json','story-review-attempt.json','visual-review.json']:
        path=job/'output'/name
        if path.exists():receipt[name]=read(path)
    write(out/'reference-result.json',receipt)
    elapsed=0;shots=[]
    for shot in read(out/'effective-scene.json')['shots']:
        shots.append({**shot,'start':elapsed,'end':elapsed+shot['duration']});elapsed+=shot['duration']
    write(out/'shot-manifest.json',{'status':receipt['status'],'duration':elapsed,'shots':shots,
          'render_success':True,'quality_pass':False,'quality_report':'reference-result.json','provenance':request})
    return receipt

def main():
    ap=argparse.ArgumentParser();ap.add_argument('job');ap.add_argument('--out');ap.add_argument('--renderer-skill');ap.add_argument('--width',type=int,default=640);ap.add_argument('--height',type=int,default=360);ap.add_argument('--fps',type=int,default=24);ap.add_argument('--software',action='store_true');a=ap.parse_args()
    job=Path(a.job).resolve();out=Path(a.out).resolve() if a.out else job/'reference-output'
    print(json.dumps(export(job,out,Path(__file__).resolve().parents[1],a.width,a.height,a.fps,a.software,Path(a.renderer_skill).resolve() if a.renderer_skill else None),ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(json.dumps({'render_success':False,'error':type(exc).__name__,'message':str(exc)},ensure_ascii=False));raise SystemExit(1)
