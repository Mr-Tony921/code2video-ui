# Claude Code and other hosts

The same skill folder works as standard instructions plus local CLI tools. It does not require a particular harness, model API or agent framework.

For Claude Code, place the complete folder at `.claude/skills/blockout-previs/` in the server project, install its dependencies once, and invoke `/blockout-previs` with the story or follow-up edit request. Resolve scripts from the loaded skill directory, not from the job directory. Ordinary Read, Write/Edit, Bash and image-reading capabilities are sufficient. Keep outputs in a separate project folder. Do not add autonomous recurring `/loop` commands, recursive subagents or hooks that restart failed jobs.

Choose the workflow before acting: new film follows `SKILL.md`; changes to an accepted film follow [user-edits.md](user-edits.md). Keep the base-job and edit-folder paths in session notes so a resumed/compacted conversation continues the same bounded edit. Read `job.json` to recover counters; never reset them on context compaction or a tool error. Each new **user-requested** change can start a new scoped edit based on the latest accepted result. A failed self-check is not a new user request.

The caller manages model credentials, supported thinking settings and tool permissions. The package grants no blanket permission bypass and stores no credentials. Start with low planning for latency-sensitive trials; escalate a factual correction to high when supported. Do not spend a high-effort full-story critique on a small follow-up. Report actual settings, rather than assuming equal effort labels have equal computation across providers.

Local Claude Code integration was intentionally **not tested**, per the user's instruction; the server owner will verify it. CLI generation and bounded editing are tested separately and must not be described as a Claude Code end-to-end result.

Installation location and invocation follow the [official Claude Code skills documentation](https://code.claude.com/docs/en/skills). The core skill uses standard name/description frontmatter so other hosts can load it too.
