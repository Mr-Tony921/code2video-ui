# Interaction and subject-mounted camera · 0.10.11

Use this when a prompt needs visible body action, possession/contact, or a character's viewpoint. Keep background people simple. Read [blocking-first scope](action-scope.md) before planning or reviewing body action. For a principal actor whose requested proxy action must read as crouching, embracing or shaking hands, choose `detail:"articulated"`; it adds a few rigid primitives, not a detailed character rig. Face markers remain optional. A named pose on a simple cylinder is omitted acting, not evidence of that action. Never make every extra articulated just to satisfy a global appearance rule.

## Possession: attach to the live actor

A held object should use `carry`, not a separate parallel `move`. Independent endpoints can appear correct while the item drifts away between them. Prefer local named anchors for visible human holding:

```json
{"carry":{"prop":{"parent":"actor","space":"local","anchor":"right_hand","offset":[0,-0.15,0],"pickup_until":0.25}}}
```

- Anchors: `root`, `left_hand`, `right_hand`, `chest`, `head`. For articulated people, wrists/chest/head follow the actual interpolated joints. Simple people use approximate body anchors; do not claim visible hand contact when no limbs were built.
- `offset` is meters from the anchor to the child's **bottom center**. To place a 0.30m-high prop center at the wrist, use `[0,-0.15,0]`. Add an intentional small local offset for handles or broad objects; do not place every prop above the head.
- `space:"local"` rotates the offset with the parent's current yaw and rotates the prop by parent yaw plus optional `yaw_offset`. `space:"world"` preserves legacy world offsets; use it only when world alignment is intended.
- `pickup_until` is the fraction of the acquisition shot spent approaching the anchor (default 0.25 for local, 1 for legacy world). During pickup the child transitions from its existing place to the moving anchor. Afterwards it stays bound. Existing unchanged bindings have zero acquisition time in subsequent shots. Do not repeat pickups or change offsets every shot.
- Plan pickup while the holder is near the prop, preferably before travelling. Do not use a long pickup transition to fly an item across a room. `release:["prop"]` preserves its last actual world position; then `move` places it independently. Handovers switch parent during a short explicit transfer beat. A new parent needs to be within plausible reach.
- Preserve continuous facing across cuts when holding props: explicitly begin a turn at the previous yaw and use `end_yaw` to finish it. An instantaneous 180-degree heading change also moves a local hand anchor.

Generic brief checks: `{"type":"held_by","a":"prop","b":"actor","anchor":"right_hand"}` checks ownership and completed acquisition at the event time. `{"type":"contact_max","a":"actor","anchor":"right_hand","b":"prop","target_anchor":"center","value":0.35}` checks actual sampled world contact distance. These checks do not replace image review or implement inverse kinematics/physical grasping. Use exact bounds only when meaningful for the original request.

## Readable interaction in a few poses

Available poses: `stand`, `sit`, `crouch`, `kneel`, `reach`, `arms_up`, `lunge`, `lean`, `lean_back`, `embrace`, `embrace_low`, `handshake`, `guard`, `punch`, `kick`.

Use `pose` for a shot's start and `pose_to` for its end; a single pose-to transition is interpolated over that shot. For contact or action that should persist, follow a transition with a hold beat. Match the starting pose to the prior endpoint. Do not stretch one joint interpolation across a long approach or add a punch animation to a blocking-first fight. Use short transitions only when they aid the static interaction. The planner selects timings; the tool does not pad a short story to five minutes.

Embrace: approach within reach, face one another, use `embrace` and `embrace_low`, hold, then release before departing. Handshake: use `handshake` for a short right-hand contact hold, with no pumping cycle. See action scope for staging distances and limitations. Fighting uses stationary proxy limbs plus meaningful whole-body blocking; leave strikes/dodges/choreography to downstream generation. Pet care: kneel/crouch, reach toward the animal, place or acquire the relevant prop, then stand. Contact distance, ownership, order and visibility matter more than fingers or exact limb anatomy.

Joint names are generic posture primitives, not guarantees of physical contact. The model must stage the participants coherently. Pose omission stays a soft issue by default; if the requested action itself is absent, disclose that separately rather than claiming it happened because a caption says so. Do not invent a stricter pose requirement than the original request.

Default locomotion remains translation with static limbs. Do not add gait cycles, IK, physics or asset downloads. One or two readable pose transitions cost much less than modelling a complete performance. For animals or creatures use `kind:"box",asset:"quadruped"` with size `[width,height,length]`, or a few custom primitives; the forward direction is +Z. Scale is chosen by the prompt. It is a rough recognizable proxy, not anatomical animation.

## Character-relative views

Compact camera types additionally support `pov`, `shoulder`, `chase`. Supply `camera_subject` and optionally `camera_target` (another visible actor). Example:

```json
{"camera":"pov","camera_subject":"actor","camera_target":"partner","focus":["actor","partner"]}
```

The camera follows the subject's live position **and rotation every frame**. `pov` places the view near eye height and deliberately hides the viewing actor's own mesh; props remain visible. `shoulder` places the camera just behind one shoulder; `chase` follows farther behind. Do not describe an external tracking shot as first person.

Optional `camera_offset:[x,y,z]` and `camera_look_offset:[x,y,z]` are in the subject's yaw-local coordinates, in meters from its bottom center. Defaults are respectively `[0,0.9H,0.12]`, `[0.55,0.88H,-1.2]`, `[0,1.1H,-3.2]`, looking toward `[0,0.85H,3]`. A `camera_target` overrides the look offset and looks at that subject's body center. Use the target for a conversation; omit it when the viewer should look down their own path. Rotations are smooth through `end_yaw`; no noise or camera bob is added by default.

Mounted cameras are locked against automatic framing. Only the viewing actor is exempt from full-body on-screen checks (POV hidden or shoulder foreground); other required subjects still need visibility. This exception must not be used to excuse a missing partner or prop. Place a carried object below/aside the lens so it does not fill the entire frame. Inspect the actual first/middle/last views and the exact interaction, not just endpoint coordinates.

Other camera types remain valid. Choose them from the story: establish the place, approach in POV, reveal the partner over a shoulder, show an interaction in a readable two-shot. There is no requirement to add camera variety when the user requested a static or repeated view. These are proxy movement cues, not a guarantee that every downstream video model accepts the same conditioning channels.

`lean` bends the upper body toward local +Z (forward). `lean_back` bends away from local +Z for a backward dodge. Do not rotate the whole actor away from an opponent merely to disguise the wrong lean direction. Named poses are approximate; review action direction against local facing.

For POV, derive `focus` from what the viewer must see, not from the full inventory. An offscreen bag may remain held and numerically checked. Do not enlarge or raise every carried prop just to force it into the camera; this can obscure the target or cause a later crouching prop to intersect the floor. A prop explicitly required in view remains binding.
