# User follow-up edits

Use this branch when the user asks to adjust an existing playable previs. The target is their requested story progression, action, staging or camera change. Do not reopen modeling quality, beautify scenery, add faces/limbs, or review unrelated shots. A new user message is not permission to start independent whole-film retries.

## Limits and scope

- Preserve the accepted video, original brief, compact draft, scene and review receipts. Work in a new sibling edit folder. Do not overwrite the accepted base.
- One edit candidate, **at most one corrective candidate**. Use the same edit folder for both. No new folder or reset to bypass the limit. Invalid candidate submissions count too. If still blocked, export any technically renderable scoped candidate with `job.py reference EDIT`, preserve the original too, and label unresolved parts of the requested change. Do not automatically reset or remake.
- Start the edit clock when the user request arrives. Separately record first preview, final export, model/tool/queue time and correction count. The CLI timer starts at `start`, so the host adds preceding interpretation time. 600 seconds remains a soft telemetry target, never permission for endless checks or a reason to discard a good result.
- Read only the request, base contract, relevant draft fields, affected state and current diagnostics. Summarize once: requested difference, editable fields, direct dependencies, acceptance condition. Proceed without asking for approval for an ordinary requested tweak. Ask only if a missing detail materially changes the requested outcome.
- Preserve stable IDs, duration, event order and shot count in this local branch. Changing those structurally is a separately requested new plan, never an automatic response to a failed tweak.

## Declare and apply a local patch

Create `edit-request.json`. Preserve the actual user wording; the model translates it into a narrow field allowlist and records why each dependency is necessary. The tool checks that changes stay in this declaration; it cannot prove that the declaration accurately interprets the user.

```json
{
  "user_request": "最后一个镜头的人物终点向左挪一点，其他内容不变。",
  "targets": [{"path":"/shots/s05/move/A","reason":"用户要求调整该人物终点"}],
  "dependencies": [],
  "changed_event_ids": ["leave"],
  "brief_patch": {}
}
```

Paths index `shots`, `stages`, and `entities` by existing ID, then name the specific editable field. Do not allow an entire shot, stage or entity collection. Use JSON-pointer escaping for IDs containing `/` or `~`. A downstream compact destination may need an explicit dependency if the user change would otherwise reverse a path; record that exact field and causal reason. Carried props, subsequent start positions, headings and following cameras propagate through the existing compiler; do not manually reset their state.

If the user explicitly changes a previous requirement, put the corresponding change in `brief_patch`. It supports `story`, `requirements`, existing `events` (ID-based partial updates), `camera_constraints`, and `state_constraints`. Preserve unrelated requirements. `changed_event_ids` must identify events affected by changes to general prose/constraints. Do not weaken a requirement merely to pass a check.

```sh
python scripts/edit_scope.py start EDIT --base ACCEPTED_JOB --request edit-request.json
python scripts/edit_scope.py apply EDIT --patch local-patch.json
```

The patch uses the existing compact ID-based format, for example `{"shots":[{"id":"s05","move":{"A":[2,0,4]}}]}`. An explicit older `--base-skill ORIGINAL_SKILL_FOLDER` is needed when the accepted job used a different release. Inheritance is allowed only if the exact original source is available and render/compiler/check dependencies are unchanged. Do not silently migrate a scene to a different renderer.

## Focused acceptance and exit

1. Run `job.py check EDIT`. Full cheap numeric checks are useful regression protection; they do not authorize a new whole-film model critique.
2. If factual review is required, run `job.py facts EDIT`. Its packet lists only affected events/shots and the actual edit request. Review these literal facts once and `record-facts`. Unchanged events inherit the archived accepted receipt and are labeled as inherited, not newly reviewed.
3. Run `job.py preview EDIT` with the baseline resolution/fps/backend. `output/edit-scope.json` derives all changed compiled shots, including propagated actor/prop/camera states, and adds their immediate neighbors for cut checks. A global set change may legitimately affect many shots; do not hide that consequence.
4. Read the **scoped** `output/review/index.json`. Inspect its listed local continuity, event, detail and accepted-base/current comparison pages. Check the requested difference, actual movement, location, ownership, visibility and cut continuity. Do not request prettier assets or a new aesthetic direction. Record only the events listed in this index. The receipts explicitly identify inherited unchanged events.
5. If blocked, consolidate concrete failures once and apply one correction inside the frozen scope. Recheck only that affected scope. Do not oscillate between personal camera preferences or repeatedly ask another critic.
6. If clear, `record-review`, `render`, `package`, then stop. Exporting the whole MP4 and fully decoding it are technical operations; neither starts a new semantic review loop. Deliver the new video, changed fields/shot IDs, inherited scope, elapsed time, correction count and remaining warnings.

If the request makes no scene difference, report that directly and reuse the accepted video. If it cannot be satisfied locally, explain the concrete dependency/conflict and preserve the original; do not expand into an unsolicited remake. Readability of the required action is binding, while minor noncritical contact overlap and omitted body detail remain warnings.

## A playable base with quality issues
The edit tool also accepts a prior `reference-output` video that was fully decoded, even when its quality was not accepted. Known/unreviewed unchanged quality stays unresolved; scoped review cannot turn the whole film into quality_pass. Reuse its original scene/draft and renderer version. The new local candidate can be exported as RENDERED_FOR_ADJUSTMENT without forcing unrelated fixes. Deliver original and modified versions with the precise local result.
