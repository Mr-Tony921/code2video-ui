For a user edit, facts contains only affected events and labels the rest inherited from the accepted base. Review the user delta and direct continuity dependencies only. Do not reopen unrelated quality choices.

# Literal story facts before image judgments

Use this separate factual pass for DeepSeek V4.1 Flash, or when another model repeatedly excuses missing actions as rough rendering. It checks original story clauses against compiled world data. Images are reviewed afterwards for visible execution; numerical proximity alone cannot establish the required action/place.

Initialize with `python scripts/job.py init JOB --brief BRIEF --budget 600 --require-facts`. After a successful compile, run `python scripts/job.py facts JOB`. Read the resulting `output/story-facts.json`. This excludes the draft's creative beat/video-prompt prose, which must not become evidence that an action happened.

Review the facts as a distinct pass before inspecting montages. In an API host this may be one short, fresh-context model request containing the instruction below and the packet; no particular provider, API or harness is required. In an interactive tool host, read the packet and complete the same decision record before visual review. This is model-declared semantic evidence, not a mechanical proof of story correctness.

## Factual review instruction

你是剧情执行的事实核验员。只核对原始需求与实际场景数据，不评美学，不做造型评价。

若冻结的原始需求含 motion_policy=blocking_first，事件的 proxy_action 是白模实际需要完成的动作；downstream_action 是明确交由生成模型补充的表演。核验 proxy_action 及原有地点、方向、位移、归属、顺序与运镜，确认被省略表演仍保留在交付元数据；不要因没有步态、出拳、踢腿等已委托动画而判 blocker，也不得称这些动作已经渲染。未声明拆分的事件仍按原文字面核验。此规则不允许省略移动、交接、剧情结果或随意改变冻结合同。握手、拥抱等姿态也只是加分项；近距离站位、面对关系与剧情顺序正确时，未画手臂接触不可单独判失败或要求补修。

先把每个原始事件拆成全部不可省略的事实子句，再核对实际轨迹、方向、地点、物件归属与先后。原始事件里的文字也是要求；checks 只覆盖其中一部分，不是完整验收标准。没有对应数值 check 不表示可以忽略文字要求。

坐标 Y 是竖直轴，X/Z 是水平轴。人物位置以脚底为锚点。环境模块 at 是底部中心，平面构件顶面为 at.y + size.y，水平范围结合 size 和 yaw 计算。先读实际数字再描述动作，不要只读轨迹上的文字标签。

人物细节按需且是软要求，包括主体人物。默认圆柱身体加圆球头；路人不要求五官、四肢、姿态。缺这些细节本身不得作为 blocker 或触发修改；可说明留给后续视频模型。仅 detail=articulated 才实现关节姿态，不能误称 simple 代理已表现真实坐姿/下蹲。不要把姿态软要求扩展成行动路线、剧情位置、物件归属或运镜可省略。内置代理与家具定义见 actual_scene.runtime_contract；chair/bench 的座面不是整体最高点。不要要求精细接触或步态。

每个事件分别核验，不能用上一镜或下一镜补偿本镜明确要求的动作。粗糙白模只允许造型粗糙及省略未要求的细节，不能省略动作或改变地点/方向关系。

输出中文 JSON：events 为每个原事件恰好一项，每项 `{id,clauses:[{required:原文事实子句,actual:对应的实际坐标变化或关系,match:true或false}],verdict:pass或blocker}`；critical_issues 列出所有不匹配的原事件 `{id,reason}`。先区分剧情硬事实和被需求允许省略的人物细节。可省略的五官/四肢/姿态说明 actual 中的省略与下游补充，match=true；不得把未画的细节称作已画。任何硬事实子句 match=false 必须 blocker，不得以外观问题放行。不要杜撰原文不存在的约束。没有足够数据验证时写明缺少什么，不要凭想象补动作。

一般陪同、带人参观或引导，不自动等于全程固定在前或保持某个纵向间距。只有原文明确要求前后队形或给出 leads 谓词时，才检查该约束；不要把某一镜的明确要求扩散到全部镜头。

该步骤不判断画面可见性，之后仍需另做图片审查。

## Record and repair

Add `scene_sha256` and `brief_sha256` from the packet to this JSON and save a review file. Run `python scripts/job.py record-facts JOB --review REVIEW.json`. A mismatch blocks export; fix it within the existing two repair rounds. Changed scene/brief hashes invalidate the old receipt. Once factual review passes, preview and complete the normal image review. Preview remains available for diagnosing uncertain geometry; it does not waive unresolved factual blockers.

On repairs, consolidate all original clauses affected by the change, including dependent events. Do not only move a single endpoint to satisfy one sparse check. The original brief decides whether distinct moments can share a shot; do not impose the benchmark's shot count convention on other users.

The script validates coverage, hashes and declared match/verdict consistency. It cannot verify that every natural-language clause was extracted correctly or that the model's comparison is true. Retain the packet, receipt, images and limitations.
