Read [blocking-first action scope](action-scope.md) for the default performance/geometry split.

# Explicit scene format · v0.10.5

Advanced alternative to compact.md. Prefer compact plans for models: the compiler handles inherited state and reusable environment expansion. Schema version "1.0" is independent of skill release0.x.

Read scene.schema.json for authoritative field validation. Coordinates in meters,Y up,bottom anchors. Top level: version,title,duration,entities,sets,shots.

- entities: id,label,kind(person/box/sphere/cylinder),size,color; optional parts array of local primitive box/sphere/cylinder/cone with at,size,color,yaw. Explicit format requires already expanded parts; asset names are compact compiler inputs.
- sets: id,label,objects:[{id,position,yaw}], optional environment:{description,ground:{size:[width,depth],color,at},parts:[...]}. Expand modules with the standalone scenography.py functions or compact compiler; renderer reads expanded parts, not raw module names. No external assets/code.
- shots: id,set,duration,beat,description,video_prompt,continuity(continuous/time_jump),cut_reason,camera,actors,focus,context(optional),events.
- actors:[{id,from:[xyz],to:[xyz],yaw,end_yaw(optional)}]. Set objects remain visible; all other entities absent from actors are hidden. Authored endpoints must preserve carry and continuity explicitly.
- camera:{type,from,to,look,look_to(optional),fov,auto_frame,framing(optional)}. Vertical fov15..90. static/push/pull/truck/pan/follow/orbit. Orbit follows the shortest horizontal arc. Other positions/targets interpolate linearly.
- focus: primary subject IDs. context: large non-person subjects≥3m that may appear partially; still checked for actual visibility. Event subjects must belong to one of these. Never classify a person/small prop as context.
- events:[{id,at:0..1}]. Required IDs exactly once,in order,actual visual event at that time. Metadata cannot substitute for coordinates.

Design finite recognizable sets and eye-height compositions. Default auto_frame=true searches bounded horizontal camera-path translations≤24° /≤1.6× distance. It preserves height,look targets and movement; it does not pull every shot into a distant overhead view. Inspect effective-scene and camera-adjustments. For exact cameras use false and solve framing yourself.

Use environment gaps and real doorways; avoid placing story people inside solid vehicles/buildings. A vehicle's visible door panel is not an accessible interior. Describe an approach only when that is what the proxy shows. Do not claim a character boarded, stepped onto a platform or transferred ownership merely because two anchors are near each other.

All standard brief checks, visual review, soft elapsed-time target and repair limits also apply to this route. Never rewrite renderer code for one story.
