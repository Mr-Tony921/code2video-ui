# Technical profile · v0.10.5

The goal is a recognizable, editable film set with photography specified by the prompt. Rough gray geometry is sufficient; an unbounded floor with isolated symbols is not. These are defaults, not timing guarantees for unknown models/hardware.

| Item | Default / range | Enforcement |
|---|---|---|
| Film | User-selected, typically10–300 seconds; shot count follows story density | Brief duration / shot_count exactly checked; real briefs may vary shot lengths/count |
| Output | 640×360, 16:9, 24 fps;10s=240 frames,300s=7,200 frames | Full decode/frame count; same profile from preview to export |
| Codec | H.264, yuv420p, CRF22, ultrafast, 4 encoder threads, no audio | Renderer |
| Larger/portrait | Preview requested aspect first; 360×640 portrait or measured 960×540/1280×720 | Use explicit vertical fov for portrait; compact lens shorthand assumes 16:9 |
| Coordinates | Meters, Y-up, bottom-center anchors; yaw0=+Z,90=+X | Schema and sampled checks |
| Humans | kind:person defaults to cylinder + sphere; optional detail:oriented / articulated; optional face_marker | Detail is soft, including for main characters; no global face/limb/posture gate |
| Set detail | Usually100–500 expanded parts/set, cap1,800; finite floor and requested place cues; no mandatory layer count | Module count bounded; place recognition remains a visual judgment |
| Modules | Building/window/door/stairs/rail/furniture/tree/road/vehicle etc; arbitrary primitive composition | Generic components, no benchmark-specific scene recipes |
| Framing | wide/full/medium/close/insert as requested | No minimum scale variety unless explicitly requested |
| Camera | Vertical fov50° default; absolute height1.55m, wide2.3m; subject-derived distance | No default elevated12m-wide diagram |
| Lens shorthand | 36mm horizontal sensor,16:9; 24/35/50mm etc | Converted to vertical fov; do not set lens and fov together |
| Assistance | Horizontal angle≤24°, horizontal distance0.65–1.6× | Height, targets and endpoint displacement preserved; failure needs replan |
| Primary visibility | 11 times/shot;7 primitive samples or up to15 distributed actual component samples;≥ceil(2N/7) framed / ≥ceil(3N/7) visible points per sample,80% in-frame,50% visible | Approximate ray audit including real environment geometry |
| Large context | Non-person object≥3m; clipped bounds and15 screen rays | Partial view allowed, zero view rejected; people/small props cannot use this escape |
| Readability | Event person≥26px high; small required prop preferably≥20px short side | Person guard in scenic profile; sub12px prop detail flagged for review |
| Motion | Linear translation/yaw, short orbit, hard cuts | No collision solver, articulated contact, physics or motion blur |
| Continuity | Continuous same-set cut≤0.2m position gap | Facing/axis/ownership still reviewed in images |
| Soft time target |600s incl planning,API,queue,render,decode | Continue bounded work after target; report elapsed and within_target separately from pass/fail |
| Repairs | Initial compile +2 compile/patch attempts total | Invalid revisions count; no per-shot reset |
| Export reserve | max(25s,30s+0.3×duration×resolution/fps factor);120s at300s/360p/24fps | Do not begin aesthetic repairs late |

Environment decoration is **real occluding geometry**. Keep action lanes and camera corridors open; do not disable walls during shots or make them transparent to fake visibility. Use openings, view from within a room, or deliberately plan a different camera. Context subjects still participate in event predicates. Never move objects or weaken story requirements merely to satisfy framing.

All7 person samples being behind a pillar is a real blocker. A ray through a furniture gap is only approximate evidence; inspect the actual frame. Event pixel thresholds use the nearest sample among11 times/shot; exact event review images remain authoritative. Projected bounding boxes do not measure true silhouette or legibility.

Before generation, mentally compute each event's start/end coordinates and actual move length. Writing “walks3m” in beat/video_prompt does not move an entity: emit move. New carry bindings interpolate from the current position to the parent offset; detach with release before independent placement. A distance predicate alone does not establish boarding, transfer or arrival on a raised surface.

All phases share one measured start time with a soft600s target. Do not terminate or fail solely for exceeding it. Enable thinking for DeepSeek and record the caller-selected high/low/hybrid profile. Keep independent model/tool timeout protection distinct from the target. Measure total and model/render/queue time separately. If the host supports JSON output, request it and include an actual syntax example. A malformed response consumes the same bounded repair allowance; do not silently edit meaningful story data to force parsing.

Clean output contains no IDs, captions, grids or diagnostic overlays. Identity tints and chest markers are proxies. Supply final appearance, emotion and fine acting through video_prompt and separate references. Export individual shots for downstream models' own duration limits; the five-minute MP4 is a director's reference, not a promise that every generator accepts300s conditioning.


Camera/near-plane probes are checked against actual primitive volumes, independently of subject rays. Sphere/cylinder tests use their volumes; other shapes use conservative local boxes, so a cone tip may generate a conservative warning/blocker. This is sampled point/near-plane collision, not swept-volume collision at every frame. A–B–A tests cover three chosen shots on actual node transforms and rendered JPEGs; state mismatch blocks render, pixel mismatch is logged for inspection.

Compound/open assets are not solid boxes just because their aggregate bounds contain a center point. Enclosure diagnostics defer these assets to actual-component ray sampling. Blocking-object hit counts identify sampled occluders, not visible pixel area or exhaustive collision proof.

The camera solver and checker read the same `assets/render-profile.json`. Optional assistance stops at the first view satisfying the factual constraints, preserves the authored view when it already passes, and does not optimize a preferred composition.

Inclusive distance/motion bounds use an absolute1e-6m numerical tolerance to avoid false failures from decimal floating-point subtraction. This is a numerical boundary policy, not permission to omit movement or relax visibility/story requirements. Strict ordering remains strict.
