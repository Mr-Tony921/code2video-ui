# Delivery targets: video first, director workspace pending

## Shared core

Use one story/scene representation for cast IDs and labels, recognizable lightweight sets, shot timing, actor motion and poses, prop attachments and camera relationships. Keep generation and scoped natural-language edits reusable; separate terminal packaging and acceptance. Preserve the caller's latest edited project as the baseline when a future frontend round trip is implemented. Do not regenerate from an older model draft and silently discard manual changes.

## Video: implemented default

Continue the current Three.js video workflow and optimize instruction fidelity, playable-reference reliability and time to result. Initial generation allows at most two repairs; follow-up edits allow at most one repair of the requested fields and direct dependencies. Keep render_success separate from quality_pass and retain playable imperfect references. A video request does not require an interactive viewer, camera gizmos, director-specific metadata or a second export. Current measured benchmarks are video evidence only.

## 3D director workspace: agreed scope, not implemented

The intended terminal deliverable is an editable scene project with characters/names, objects, shots, time-dependent actor and camera state, and motion/attachment relationships. Business frontend owns 3D rendering, display, timeline controls, drag operations and the editor UI. Our eventual adapter only needs a small loading/time-scrubbing validation surface, plus data and integration guidance; do not expand it into a full web editor.

- Supply an initial overview pose per scene that makes its main content readable. This is a viewing aid, independent of the authored shooting camera; inspecting a scene must not alter its camera track.
- Supply timestamped camera position, orientation and field of view so the frontend can show a SLAM-like camera icon and historical position trail up to the current time. Keep shot/cut/location boundaries explicit; do not join unrelated shots into a continuous path. This is a visualization of authored camera motion, not visual SLAM estimation.
- Preserve stable entity IDs alongside user-facing names. Keep semantic motion/attachment relationships available for editing rather than supplying only baked position samples.
- Support scoped natural-language changes such as keeping a named actor stationary in a specified shot, using the latest saved baseline. Change only the requested fields and direct dependencies, inspect affected boundaries and retain the finite edit budget. Frontend dragging is outside this skill's responsibility.
- Scene reference images are optional layout inputs, not a promise of accurate single-image reconstruction. Image interpretation and the business asset/data format still require an agreed interface; do not assume every planning model accepts images.

Before implementing this target, settle the business project format, time/coordinate conventions, frontend round-trip contract and representative test cases. Existing scene JSON and time evaluators can be reused, but are not a verified standard-format frontend export. Current edit CLI requires a validated video baseline; do not describe it as a working scene-only edit API. A future scene-only route needs its own load/time-state/save-reload checks and must not require MP4 encoding to accept a project. Do not invent new CLI flags, output files, success metrics or frontend support in this release.

## Current experiment boundary

Continue video-oriented pass@1 experiments and report the existing two-layer results. Optimize the director target only after its requirements and test cases are supplied. Do not count old video results as director-project acceptance, rerun model benchmarks for this documentation-only change, or introduce additional self-check rounds for the reserved target.
