Optional handshake/hug/body detail is a bonus: it cannot alone block acceptance or require another revision. Preserve required close staging, direction, travel and relationships; report actual pose coverage separately from quality pass.

For new blocking_first briefs, apply [action scope](action-scope.md) before the literal-action rules below: judge proxy_action, preserve delegated performance in downstream prompts, and report it as omitted rather than seen. Unsplit legacy contracts retain their original requirements.

Video-first policy: a blocker below means quality_pass=false, not a ban on delivering a playable reference. After bounded corrections use job.py reference; preserve imperfect MP4s and their issues. Unresolved semantic quality does not justify an endless self-check loop.

For a follow-up user edit, the scoped protocol in [user-edits.md](user-edits.md) overrides the whole-film coverage below. Inspect only pages/events in the scoped index, including every baseline/current comparison page; unchanged evidence is inherited explicitly.

## Optional human detail
Default people are cylinder/sphere proxies. Face, limbs and pose detail are soft requirements for all roles; do not reject or spend a repair merely because these details are absent. Upgrade only a relevant main character when useful. Do not claim an omitted pose was visibly animated. Travel, event order, staging, ownership, requested camera and key visibility remain required.

# Review protocol · v0.10.5

Review the big picture first, then readable detail. A giant montage is an index, not sufficient evidence by itself. Do not claim to have viewed images unavailable to your host.

## Generated evidence

`preview` builds `output/review/index.json` and these images automatically; `job.py review JOB` rebuilds them without rendering. Each page has bounded size, labels and corresponding JSON IDs/timestamps:

1. `overview-*.jpg`: 20 shot middles/page, four columns. Read required story progression, geography, who has each prop, beginning/development/ending. Missing required causal steps are blockers even if distances pass.
2. `continuity-*.jpg`: five shots/page, start/middle/end in three columns. Inspect **all pages**; read left to right per row. Detect frozen action, exits, reversed movement, abrupt yaw, inconsistent scale and violations of explicitly requested shot structure. T is film time, u is normalized shot progress.
3. `events-*.jpg`: three events/page, before/exact/after in three columns. Offset is min(1 second, 10% of shot duration). All samples stay inside the shot: an event at u=1 has duplicate exact/after; it does **not** prove what happens in the next shot. Check adjacent cut separately. Match every required event to real on-screen evidence, not just its ID or narration.
4. `details-*.jpg`: contextual crops for non-person event props and small/partly occluded people, up to six/page. Labels show projected box size in the **original frame**. Cropping does not reveal lost detail or prove ownership, contact, visibility or identity. Read the full event frame alongside the crop. Sub-12px key/gift/handle: prefer a closer, isolated shot or mark unresolved readability.
5. `cuts-*.jpg`: previous last / next first frame pairs, five cuts/page. Consult for flagged direction, teleport, prop transfer or scene transition; all full continuity pages already show these endpoints. Different shots can intentionally change framing; do not force pixel identity across cuts.
6. After a repair, `compare-*.jpg`: affected shot start/middle/end, before/after side by side. Read `comparison.json` for changed cameras, actors, focus, events, entities and sets. Match shot ID and normalized time. If duration/event time changed, compare actual event frames as well; equal normalized time is not equal film time.

Original full-resolution `frames/NNN_[abc].jpg` and `event-frames/NNN[_before|_after].jpg` remain available. If your host downsamples a montage, open its page or original frame; do not infer fine details from unreadable thumbnails. Max default page dimension is 1280px for overview, 960×1110 for continuity. Portrait tiles are letterboxed; open originals when necessary.

## Instruction fidelity, not a new art direction

Review renderability and fulfillment of the original brief. Check its requested place, actors, required action/ownership, event order, camera type/viewpoint and explicit constraints. A requested static or single-shot clip is valid. Do not demand wide/medium/close variety, eye-level cameras, three depth layers, more elaborate acting, prettier light or a longer story unless the prompt asks for them. Scene geometry must still identify a requested place and must not hide a required event. Rough modeling and aesthetic preferences are warnings.

Inspect all event people/props at the original frame scale. A crop cannot restore lost information. Use audited coordinates for metric relationships and actual scene trajectories for motion; sampled pictures assess visibility and semantic identity. For cross-model comparison align by event ID and show the original Chinese brief beside the result. A model's self-review is not an independent human score.

## Fixed requirements versus creative choices

A blocker must identify the user/brief event, explicit camera constraint, or core scene-readability requirement it violates, with actual image evidence. Failure to achieve a self-invented embellishment is a warning unless it prevents a required fact being understood. Do not require a character to board a vehicle when the brief only asks them to approach it. Face direction, limbs and sitting/crouching/stunt posture details are optional; do not turn their absence into a blocker. Verify required world travel and staging independently of omitted acting. Do not demand facial acting, fingers, gait or rigged contact. Conversely, never downgrade a hidden required prop or wrong recipient to aesthetic preference.

Keep camera collision, subject occlusion and projected cropping as separate findings. Read camera_collision and determinism-validation instead of assuming good visibility implies a safe camera path. A–B–A samples inspect actual rendered transforms and images, but do not prove every time/state transition or a new browser session. Review event before/after ownership even when a carry label exists.

## Required review decisions

Assess six criteria: `story`, `staging`, `camera`, `continuity`, `props`, `orientation`. For each use `pass`, `warning`, or `blocker`.

- **Blocker:** required event absent/wrong order, wrong character/recipient, person described on platform but only beside it, hidden story-critical object, missing intended camera/subject motion, unresolved enclosure, wrong causal direction, technical checks fail.
- **Warning:** rough primitives, no expressions or detailed acting, minor noncritical overlap, imperfect composition, noncritical tiny context prop. A warning cannot waive a required story fact.
- **Uncertain:** open larger evidence, check coordinates, or mark review incomplete. Do not convert uncertainty into an invented pass.

For each required event, record its ID, actual `observed` action/location/order, `checks` for action/location/order/visibility/props, verdict and image evidence. Check values are pass/blocker/not_applicable; only order and props may be not_applicable. Any blocker check requires overall blocker and a corresponding critical issue. Do not substitute the intended prose for observed facts. A distance predicate is only a partial contract: “near platform” does not prove “on platform”; “near recipient” does not prove transfer; a camera move does not prove a character moved. Compare ownership before and after transfer using scene data and images. Check actual person chest direction for facing; the compiler derives travel yaw only for people, not all boxes/vehicles.

After repair, recheck the affected event, the shot before/after, and the global overview. Inspect at least the relevant compare pages and read numerical changes. Do not shrink focus lists, delete events, weaken the brief or substitute subtitles for missing action. Mark unresolved blockers and stop when the two repairs are exhausted, not merely when600s elapse.

## Record evidence through the standalone CLI

Copy `scene_sha256` from `output/review/index.json`, create a JSON file, then call:

```sh
python scripts/job.py record-review JOB --review review-input.json
```

Example (use actual event IDs and all actual required pages):

```json
{
  "scene_sha256": "COPY_FROM_CURRENT_INDEX",
  "status": "complete",
  "seen": ["review/overview-01.jpg", "review/continuity-01.jpg", "review/events-01.jpg", "review/details-01.jpg"],
  "criteria": {"story":"pass", "staging":"pass", "camera":"pass", "continuity":"pass", "props":"warning", "orientation":"pass"},
  "events": [{"id":"arrive", "observed":"The visitor moves into the doorway and stops beside the host.", "checks":{"action":"pass","location":"pass","order":"not_applicable","visibility":"pass","props":"not_applicable"}, "verdict":"pass", "evidence":["review/events-01.jpg"]}],
  "findings": [{"severity":"warning", "impact":"appearance_only", "non_blocking_because":"The required recipient, transfer and object identity remain visible.", "description":"Noncritical prop remains rough; recipient and transfer are readable.", "evidence":["review/details-01.jpg"]}]
}
```

For a complete review the CLI requires all overview/continuity/event/detail pages in `seen`, all six criteria, every required event exactly once, and before/after evidence after a visually previewed revision. `seen` is the reviewer's declaration; software cannot prove the reviewer actually looked. It validates paths, completeness and current scene/camera hashes. A blocker prevents quality acceptance; reference export still delivers a playable baseline with issues. A changed scene invalidates old review. The export must use the same resolution/fps/backend as the reviewed preview.

If image viewing is unavailable, use `status:"incomplete"`, `reason`, and the `seen` pages actually inspected (possibly empty). This is explicitly **PASS_WITH_WARNINGS / visual review incomplete**, never a fully accepted story. It permits delivery of a numerically checked reference when the user accepts this limitation; do not use this shortcut to skip available image tools or to hide known blockers.

## Motion and final acceptance

Three samples do not prove continuous motion. Read camera-motion validation and, when video viewing is available, inspect the final movement/cut at required events. If playback is unavailable, disclose that motion review was limited to deterministic trajectories, numerical audit and sampled stills. Do not claim to have watched the whole clip. The tool fully decodes all frames but does not assess their narrative meaning.

Final output stays conservative: validated video with model/human-declared visual review is `PASS_WITH_WARNINGS`, because full narrative/physics/art quality is not mechanically certified. Preserve the review record, pack index, relevant comparison pages, final scene, runtime profile and version provenance with delivery. Clean only technically invalid/partial MP4s after the outcome is recorded; preserve playable videos with quality issues; keep compact JSON diagnostics and review evidence needed to explain repairs.


## Prevent review drift

Provide the reviewer with original user/brief requirements, actual subject identities, audited event states, and labeled evidence pages. Keep creative video_prompt prose separate from the acceptance contract: it is not a source of new hard requirements. Numerical distances/travel refer to the precise schema anchors, not guessed edge clearance. Do not estimate meters from image perspective to contradict an audited value; instead identify a specific visual ambiguity (wrong side, hidden subject, unclear recipient) if it remains. A tracking camera can keep the subject at the same screen position while the background moves; that is not evidence that the subject did not move. Still images alone cannot certify or refute full continuous motion without the trajectory evidence.

Before returning a blocker, name its exact required event/constraint and evidence image. If the defect concerns an optional embellishment or an uncertain inference, mark a warning and inspect more relevant evidence if time remains. Review should reduce real failures, not keep creating new demands after each repair.

Close/insert shots may intentionally omit full bodies and environmental context. Judge identity and the required story fact, not a rule that every frame must show the whole set/person. Static head close-ups can provide framing for downstream expression; lack of proxy facial animation is not a blocker.

When a preview already fails automatic geometry or instruction checks, use those diagnostics and its evidence images for the next local repair; a separate aesthetic critic pass is unnecessary. After automatic checks pass, complete the required full-page instruction review before export. Do not skip an unresolved instruction blocker. Evidence citations may use a full supplied path; the CLI also records normalization of a unique bare filename, but never guesses a missing or ambiguous image.

Distinguish user-specified camera constraints from a model-chosen initial camera. Preserve the former strictly; do not turn an unspecified initial viewpoint into a newly invented requirement. For a visibility repair, prefer removing optional occluding decoration and preserve the requested movement. An allowed bounded camera adjustment is not itself a blocker unless it violates the original brief. Read effective-scene.json and the cutaway/camera audit rather than guessing what changed.

## Prevent false acceptance through warnings

Warnings may use only `impact:appearance_only` or `impact:noncritical_visibility_or_overlap`, plus a concrete `non_blocking_because`. Wrong order, missing leadership, wrong meeting place, wrong ownership or an unreadable required action cannot be excused as rough previs. If any required fact is uncertain, inspect the relevant page/data or record incomplete review; never invent a pass. For each event explicitly compare actual actor trajectories and ownership with its action, location and order. A checker passing a sparse distance predicate does not resolve other clauses in that event.

The review tool rejects contradictory declared verdicts and missing evidence fields. It cannot recognize every semantic error in free text: retain observations, numerical predicates and external acceptance limitations. A proposed repair from a critic is advisory and cannot create a new fixed camera constraint.

For general accompanying, hosting or guiding a tour, do not invent a permanent longitudinal lead/gap. Apply front/back ordering only where the original wording or explicit predicate requires it; an ordering specified for one event does not silently extend to other events.
